from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
import re
from selenium.webdriver.common.action_chains import ActionChains
from datetime import date
from datetime import datetime
from datetime import timedelta

import SP_Page
import locators
import Login_Page
import Common



driver = Login_Page.driver

def es():
    driver.find_element_by_xpath(locators.ES).click()


def EStop_nav():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle=driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    time.sleep(2)
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :"+str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-2):
        time.sleep(2)
        GH1[i].click()
        time.sleep(2)
        Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
        print(Topnav.text)
        listLegend1.append(Topnav.text)
        driver.find_element_by_xpath(locators.dropdown_wrapper2).click()
    # print(listLegend1)
    for i in listLegend1:
            listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    assert listLegend2==[['NQ'], ['All', '<$250K', '>$250K - $1M', '>$1M'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'Systems w/TPS', 'Cloud & Data Platform', 'Security', 'Watson Health', 'Cognitive Applications', 'Industry Platforms']],  "Not expected"
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    return listLegend2

def LEXPANDICON():
    action = ActionChains(driver)
    Chevron = driver.find_element_by_xpath("//div[@class='expand-icon']")
    action.move_to_element(Chevron).perform()
    tooltip = driver.find_element_by_class_name('tooltip').text

def Aggregated():
    #Click on Aggregated Tab
    rd=driver.find_element_by_xpath(locators.ap).click()
    time.sleep(20)
    #Breadcrumb
    # ap1=driver.find_element_by_xpath(locators.breadcrumb)
    # return ap1

# def LEXPANDICON_close():
#     action = ActionChains(driver)
#     Chevron = driver.find_element_by_xpath("//div[@class='expand-icon']")
#     action.move_to_element(Chevron).perform()
#     tooltip = driver.find_element_by_class_name('tooltip').text
#     assert "Collapse Sidebar" == tooltip, "Collapse Expand Slider Not present"
#     Chevron.click()

def APtop_nav():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle=driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    time.sleep(2)
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :"+str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-2):
    # for i in [0,2,3,4]:
        try:
            # print(i)
            time.sleep(2)
            GH1[i].click()
            time.sleep(2)
            Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
            print(Topnav.text)
            listLegend1.append(Topnav.text)
            driver.find_element_by_xpath(locators.dropdown_wrapper2).click()
        except(RuntimeError, TypeError, NameError, Exception):
            print("Top Nav failed for : "+str(i))
            print("Not Clickable")
            pass
    # print(listLegend1)
    for i in listLegend1:
            listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    assert listLegend2==[['NQ'], ['All', '<$250K', '>$250K - $1M', '>$1M'],  ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'Systems w/TPS', 'Cloud & Data Platform', 'Security', 'Watson Health', 'Cognitive Applications', 'Industry Platforms'], ['All', 'OTC S/390', 'WkstnZ', 'zLinux'], ['UNIT']],  "Not expected"
    return listLegend2

def Segmented_tab():
    #Click on Segmented Tab
    driver.find_element_by_xpath(locators.sp).click()
    time.sleep(20)

def SPtop_nav():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle=driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    time.sleep(2)
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :"+str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)):
        try:
            time.sleep(2)
            GH1[i].click()
            time.sleep(2)
            Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
            print(Topnav.text)
            listLegend1.append(Topnav.text)
            driver.find_element_by_xpath(locators.dropdown_wrapper2).click()
        except(RuntimeError, TypeError, NameError, Exception):
            print("Top Nav failed for : "+str(i))
            print("Not Clickable")
            pass
    # print(listLegend1)
    for i in listLegend1:
            listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    assert listLegend2 == [['NQ'], ['All', '<$250K', '>$250K - $1M', '>$1M'],  ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'Systems Hardware', 'Systems Software', 'C&DP', 'Security', 'Watson Health', 'Cognitive Apps', 'Indus Platforms Unit'], ['All', 'OTC S/390', 'WkstnZ', 'zLinux'], ['CHANNEL', 'JTC/RHS', 'JTC', 'RHS', 'DEAL SIZE', 'CLIENT SET', 'TIER']], "Not expected"
    return listLegend2

def transPipeOpen():
   transPipe = driver.find_element_by_xpath(locators.common_transPipeExpand)
   print(transPipe.text)
   transPipe.click()
   time.sleep(1)

def Roadmap():
    #Click on Roadmap Tab
    rd=driver.find_element_by_xpath(locators.rd).click()
    time.sleep(20)
    #Breadcrumb
    rd1=driver.find_element_by_xpath(locators.rd_b)
    return rd1

def RMtop_nav():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle = driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    # driver.find_element_by_xpath(locators.RMTab).click()
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :" + str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-4):
        try:
            time.sleep(2)
            GH1[i].click()
            time.sleep(2)
            Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
            print(Topnav.text)
            listLegend1.append(Topnav.text)
            driver.find_element_by_xpath(locators.dropdown_wrapper2).click()
        except(RuntimeError, TypeError, NameError, Exception):
            print("Top Nav failed for : "+str(i))
            print("Not Clickable")
            pass
    for i in listLegend1:
        listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    assert listLegend2 == [['NQ'], ['All', '<$250K', '>$250K - $1M', '>$1M'],  ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'Systems Hardware', 'Systems Software', 'C&DP', 'Security', 'Watson Health', 'Cognitive Apps', 'Indus Platforms Unit'], ['All', 'OTC S/390', 'WkstnZ', 'zLinux'], ['LIO'], ['BU', 'DEAL SIZE', 'CLIENT SET', 'TIER']],"not expected"
    return listLegend2

def KD_tab_Click():
    driver.find_element_by_xpath(locators.KD_tab).click()
    driver.implicitly_wait(20)
    time.sleep(2)

def kdtop_nav():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle = driver.find_element_by_xpath(locators.MoveElementkd)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :" + str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-8):
        try:
            time.sleep(2)
            GH1[i].click()
            time.sleep(2)
            Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
            print(Topnav.text)
            listLegend1.append(Topnav.text)
            driver.find_element_by_xpath(locators.dropdown_wrapper2).click()
        except(RuntimeError, TypeError, NameError, Exception):
            print("Top Nav failed for : "+str(i))
            print("Not Clickable")
            pass
    for i in listLegend1:
        listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    time.sleep(5)
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    assert listLegend2 == [['NQ'], ['All', '<$250K', '>$250K - $1M', '>$1M'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'Systems Hardware', 'Systems Software', 'C&DP', 'Security', 'Watson Health', 'Cognitive Apps', 'Indus Platforms Unit'], ['All', 'OTC S/390', 'WkstnZ', 'zLinux'], ['LIO'], ['CLIENT AGGREGATION', 'ALL LINE ITEMS'], ['By BU group', 'By BU Sub group', 'By Level 17', 'By WSR', 'By Dealsize', 'By SAQ', 'By SAQ Quadrant', 'By Market', 'By Branch Group (EBR)', 'By Branch (EBU)', 'By Branch Unit (ESU)', 'By Client Type', 'By Client Sub Type', 'By Client Set', 'By Channel', 'By Reporting Country', 'By Roadmap Status', 'By Close/Bill Week', 'By Close/Bill Month', 'By OI Source', 'By ISU Group', 'By ISU', 'By Geo', 'By Tier Group', 'By Tier']],  "not expected"
    return listLegend2

def MI_tab_Click():
    driver.find_element_by_xpath(locators.MI_tab).click()
    driver.implicitly_wait(20)
    time.sleep(2)

def Mitop_nav():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle = driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :" + str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-4):
        try:
            time.sleep(2)
            GH1[i].click()
            time.sleep(2)
            Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
            print(Topnav.text)
            listLegend1.append(Topnav.text)
            driver.find_element_by_xpath(locators.dropdown_wrapper2).click()
        except(RuntimeError, TypeError, NameError, Exception):
            print("Top Nav failed for : "+str(i))
            print("Not Clickable")
            pass
    for i in listLegend1:
        listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    time.sleep(3)
    driver.find_element_by_xpath(locators.common_GlobalFilterXicon).click()
    assert listLegend2 == [['NQ'], ['All', '<$250K', '>$250K - $1M', '>$1M'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'Systems Hardware', 'Systems Software', 'C&DP', 'Security', 'Watson Health', 'Cognitive Apps', 'Indus Platforms Unit'], ['All', 'OTC S/390', 'WkstnZ', 'zLinux'], ['LIO'], ['ALL LINE ITEMS'], ['Identifying (1)', 'Validated (4)', 'Qualifying (7)', 'Gaining Agreement (6)']], "is not expected"
    return listLegend2

def loop_view(): #lopping accross views opts and coming back to summary view. Checking with KPI's, failing for Dealsize,Channel Budget graph1 not mathcing as 0,for INDUSTRY SOLUTIONS - Budget and VP not matching as 0
    bp_res = ""
    vpqp_res=""
    vpG4_res=""
    driver.find_element_by_xpath(locators.filter_icon).click()
    driver.find_element_by_xpath(locators.sp_view2).click()
    lb=driver.find_elements_by_xpath(locators.sp_view_count)
    len(lb)
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    time.sleep(10)
    for i in range(len(lb)):
        driver.find_element_by_xpath(locators.sp).click()
        driver.find_element_by_xpath(locators.filter_icon).click()
        driver.find_element_by_xpath(locators.sp_view2).click()
        option=driver.find_element_by_xpath('(' + locators.sp_view_opt + ')' + "[" + str(i + 1) + "]").text
        print("View: "+option)
        time.sleep(3)
        driver.find_element_by_xpath('(' + locators.sp_view_opt_clk + ')'+"["+str(i+1)+"]").click()
        driver.find_element_by_xpath(locators.filter_icon_close).click()
        if option != "SOLUTIONS - Strategic Imperatives" and option != "JTC/RHS" and option != "JTC" and option != "RHS":
            time.sleep(5)
            Common.Graphs1()
            kpi = SP_Page.SP_KPI()
            bp = SP_Page.Budget_PPV()
            # print(kpi[0])
            # print(kpi[1])
            # print(bp[0][0])
            # print(bp[1][0])
            if (kpi[0]!=bp[0][0]) or (kpi[1]!=bp[1][0]):
                bp_res="Budget or PPV not matching for Graph1"
                print(bp_res)
            # SP_KPI()
            vpqp=SP_Page.VP_QP()
            # print(kpi[4])
            # print(vpqp[0])
            # print(kpi[5])
            # print(vpqp[1])
            if (kpi[4]!=vpqp[0]) or (kpi[5]!=vpqp[1]):
                vpqp_res="VP Graph2 or QP Graph3 not matching"
                print(vpqp_res)
            # SP_KPI()
            vpG4=SP_Page.VP_graph4()
            # print(kpi[4])
            # print(vpG4[0])
            if kpi[4]!=vpG4[0]:
                vpG4_res="VP not matching for Graph4"
                print(vpG4_res)
        elif option == "JTC/RHS":
            time.sleep(5)
            Common.Graphs1()
            # SP_KPI()
            # Common.sp_expand_showhide_colapase3()
        elif option == "JTC" or option == "RHS":
            time.sleep(5)
            Common.Graphs1()
            # SP_KPI2()
            # Common.sp_expand_showhide_colapase2(
        else:
            time.sleep(5)
            Common.Graphs1()
            print("At present Not checking for the view : SOLUTIONS - Strategic Imperatives")
            pass
            # SP_KPI()
    #     time.sleep(5)
    #     print(driver.find_element_by_xpath("(//*[@class='ng-value-label ng-star-inserted'])[3]").text) # after clicking get the text

    driver.find_element_by_xpath(locators.filter_icon).click()
    driver.find_element_by_xpath(locators.sp_view2).click()
    time.sleep(8)
    driver.find_element_by_xpath('(' + locators.sp_view_sum_clck+ ')'+"["+str(1)+"]").click()
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    time.sleep(10)
    print(bp_res,vpqp_res,vpG4_res)
    return bp_res,vpqp_res,vpG4_res


##---------------------------call code below-------------------------##


# Login_Page.open_ISD()
# es()
# EStop_nav()
# LEXPANDICON()
# Aggregated()
# # LEXPANDICON_close()
# APtop_nav()
# Segmented_tab()
# SPtop_nav()
# transPipeOpen()
# Roadmap()
# RMtop_nav()
# KD_tab_Click()
# kdtop_nav()
# MI_tab_Click()
# Mitop_nav()
# loop_view()