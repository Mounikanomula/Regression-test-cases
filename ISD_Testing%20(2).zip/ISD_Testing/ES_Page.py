from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
import re
from selenium.webdriver.common.action_chains import ActionChains
from datetime import date
from datetime import datetime
from datetime import timedelta
import locators
import Login_Page
import Common
import Constants

driver = Login_Page.driver

def es():
    driver.find_element_by_xpath(locators.ES).click()

#ISD LOGO
def ISDLOGO():
    print("IBM LOGO   :")
    Logo1=driver.find_element_by_class_name(locators.Logo)
    print(Logo1.text)
#    Logo2=driver.find_element_by_class_name(locators.Logo2)
#    print(Logo2.text)
#    assert "I B M   S A L E S" in Logo2.text,"Not in ISD"
    time.sleep(3)

#NEED HELP
def NEEDHELP():
    print("NEED HELP  :")
    driver.find_element_by_class_name(locators.Need_help).click()
    time.sleep(3)
    NH2=driver.find_element_by_class_name(locators.Need_help2)
    print(NH2.text)
    time.sleep(3)
    assert "https://w3.ibm.com/help/#/" in NH2.text,"Help Link missing"
    driver.find_element_by_xpath(locators.Need_help_close).click()
    time.sleep(3)

#PROFILE PAGE AccessHUB details
def Profile_Page_AH():
    print("PROFILE	   :")
    driver.find_element_by_id(locators.Prof_Pic).click()
    time.sleep(2)
    driver.find_element_by_xpath(locators.Prof_Pic_New).click()
    time.sleep(4)
    PP2=driver.find_element_by_class_name(locators.Prof_Page)
    print(PP2.text)
    PP3=driver.find_element_by_xpath(locators.Prof_Page_AH)
    print(PP3.text)
    assert "AccessHUB" in PP3.text,"Profile Page does not have Accesshub details"
    time.sleep(2)


#PRIVACY
def PRIVACY():
    print("PRIVACY	   :")
    driver.find_element_by_id(locators.Prof_Pic).click()
    time.sleep(5)
    driver.find_element_by_id(locators.Prof_Page_Prv).click()
    time.sleep(2)
    p_c2=driver.find_element_by_xpath(locators.Prv)
    print(p_c2.text)
    time.sleep(2)
    pp=driver.find_element_by_xpath(locators.Prv2)
    print(pp.text)
    assert "PrivacyQ@ca.ibm.com" in pp.text,"Discripency in Privacy Statement"
    driver.find_element_by_xpath(locators.Prv_Cls).click()
    time.sleep(2)


def ABOUTISD():
    print("ABOUT ISD  :")
    driver.find_element_by_id(locators.Prof_Pic).click()
    time.sleep(2)
    driver.find_element_by_xpath(locators.Prof_Pic_Abt).click()
    time.sleep(3)
    AISD2=driver.find_element_by_xpath(locators.Abt)
    print(AISD2.text)
    time.sleep(2)
    assert "About EO" in AISD2.text, "Discripency in About ISD"
    driver.find_element_by_xpath(locators.Abt_cls).click()
    time.sleep(2)

#Profile dropdown
def PROFILEINFO():
    print("PROFILE INFO:")
    PI1=driver.find_element_by_xpath(locators.PP_down).click()
    time.sleep(2)
    PI2=driver.find_element_by_xpath(locators.PP_Cur)
    print(PI2.text)
    time.sleep(2)
    PI3=driver.find_element_by_xpath(locators.PP_Oth)
    print(PI3.text)
    assert "OTHER PROFILES" in PI3.text,"Profile Details Missing"
    driver.find_element_by_id(locators.Default_Prof).click()
    time.sleep(2)

#Left Expand Icon
def LEXPANDICON():
    action = ActionChains(driver)
    Chevron = driver.find_element_by_xpath("//div[@class='expand-icon']")
    action.move_to_element(Chevron).perform()
    tooltip = driver.find_element_by_class_name('tooltip').text
    #
    # print("LEFT EXPAND SLIDER:")
    # time.sleep(2)
    # driver.find_element_by_xpath(locators.Left_Expand).click()
    # E2=driver.find_element_by_xpath(locators.Left_Expand_text)
    # print(E2.text)
    # time.sleep(3)
    assert "Expand Sidebar" == tooltip,"Left Expand Slider Not present"
    Chevron.click()

#Left Expand Icon close
def LEXPANDICON_close():
    action = ActionChains(driver)
    Chevron = driver.find_element_by_xpath("//div[@class='expand-icon']")
    action.move_to_element(Chevron).perform()
    tooltip = driver.find_element_by_class_name('tooltip').text
    assert "Collapse Sidebar" == tooltip, "Collapse Expand Slider Not present"
    Chevron.click()


def es_breadcrumb():
    # # clksomewhere=driver.find_element_by_xpath(locators.clksomewhere)
    # action = ActionChains(driver)
    # action.move_to_element(clksomewhere).perform()
    es1=driver.find_element_by_xpath(locators.breadcrumb)
    print(es1.text)
    return es1


def ES_KPI():
    esKPI=Common.KPI()
    del esKPI[1:13]
    print(esKPI)
    return esKPI

# Graph1

def Graph1():
    gh1 = driver.find_elements_by_xpath(locators.ES_Graph1)
    st = []

    for i in range(len(gh1)):
        ActionChains(driver).move_to_element(gh1[i]).perform()
        time.sleep(5)
        tp = (driver.find_element_by_xpath(locators.hover_text)).text
        print(tp)  # Getting the Raw details of Geo
        st.append(tp)
    print(st)          # Details in List format
    g1 = ""
    for x in st:
        g1 = g1 + x
    print(g1)
    return g1

def es_budget(g1):
    budget1 = re.findall(r'Budget : \$(.*)M', g1)
    budget_isd = []
    for i in budget1:
        i = str(i).replace('M', '')
        i = round(float(str(i).replace(",", "")))
        budget_isd.append(i)
    print("G1 Budget: "+str(budget_isd))   # Budget details in List format
    sum_budget_g1 = sum(budget_isd)
    print("G1 Sum Budget: "+str(sum_budget_g1))  # Sum of Budget for bars
    return [budget_isd,sum_budget_g1]

def es_ppv(g1):
    ppv1 = re.findall(r'PPV : \$(.*)M', g1)
    ppv_isd = []
    for i in ppv1:
        i = i.split()[0]
        i = str(i).replace('M', '')
        i = round(float(str(i).replace(",", "")))
        ppv_isd.append(i)
    print("G1 PPV: "+str(ppv_isd))   # PPV details in List format
    sum_ppv_g1 = sum(ppv_isd)
    print("G1 Sum PPV: "+str(sum_ppv_g1))  # Sum of PPV for bars
    return [ppv_isd,sum_ppv_g1]

def geo_check(g1):
    geo_check = ['North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa']
    geo = []
    for i in range(7):
        if geo_check[i] in str(g1):
            print(geo_check[i])
            geo.append(geo_check[i])
        else:
            print("Not in list " + geo_check[i])
    print("Geo : "+str(geo))  # Comparision of Actual Geo with ISD_Testing Geo

# assert (geo_check == geo), "Geo Mismatch"


def graph2(): # Giving error due to "N/A"
    gh2 = driver.find_elements_by_xpath(locators.ES_Graph2)
    st2 = []

    for i in range(len(gh2)):
        ActionChains(driver).move_to_element_with_offset(gh2[i],xoffset=10,yoffset=1).perform()
        time.sleep(10)
        #     driver.implicitly_wait(1000)
        tp2 = (driver.find_element_by_xpath("//*[name()='ngx-tooltip-content']")).text
        print(tp2)
        st2.append(tp2)
    print(st2)  # Details in list Format

    g2 = ""
    for x in st2:
        g2 = g2 + x
    print(g2)
    return g2

def G1_Budget_PPV():
    B = []
    P = []
    G=[]
    bud=""
    ppv=""
    geo=""
    ESKPI = ES_KPI()
    # print(ESKPI)
    for j in [1]:
    # for j in [2]:
    #     driver.find_element_by_xpath(locators.max1 + '[' + str(j + 1) + ']').click()
        driver.find_element_by_xpath(locators.max1 + '[' + str(j) + ']').click()
        driver.find_element_by_xpath(locators.showhide).click()
        tx = driver.find_elements_by_xpath(locators.firstrow) # gives the total number of Rows in the table
        print(len(tx))
        t = 0
        t2 = 0
        for i in range(len(tx)):
            tx = driver.find_element_by_xpath('(' + locators.firstrow + ')' + '[' + str(i + 1) + ']').text
            tx = tx.split('\n')
            tx1 = tx[1].replace(",", "")
            tx1 = float(tx1) if tx1 != "N/A" else 0  #Inline if Function
            t = t + tx1
            tx2 = tx[3].replace(",", "")
            tx2 = float(tx2) if tx2 != "N/A" else 0
            t2 = t2 + tx2
            tx3=tx[0]
            G.append(tx3)

        #     print("Budget Graph"+str(j+1)+" : "+str(t)) # give values in list
        print("Sum Budget Graph_" + str(j) + " : " + str(t))
        B.append(round(t))
        #     print("PPV Graph"+str(j+1)+" : "+str(t2)) # give values in list
        print("Sum PPV Graph_" + str(j) + " : " + str(t2))
        P.append(round(t2))
        print("Geo :"+str(G))
        driver.find_element_by_xpath(locators.showhide).click()
        driver.find_element_by_xpath(locators.min1).click()
    print(B, P,G)
    if ESKPI[0] != B[0]:
        bud = "Budget not matching for Graph1"
    if ESKPI[3] != P[0]:
        ppv = "PPV not matching for Graph1"
    if Constants.geo_List!=G:
        geo="Geo not matching"
    print(bud, ppv,geo)
    assert ((bud != "Budget not matching for Graph1") & (
                ppv != "PPV not matching for Graph1")& (
                geo != "Geo not matching")), "Budget or PPV or Geo_list not matching for Graph1"

# Budget & QTD Actuals in 2nd graph
def G2_Budget_QTD_Actuals():
    B = []
    Q = []
    bud=""
    qtd=""
    ESKPI = ES_KPI()
    # for j in range(2):
    for j in [2]:
        # driver.find_element_by_xpath(locators.max1 + '[' + str(j + 1) + ']').click()
        driver.find_element_by_xpath(locators.max1 + '[' + str(j) + ']').click()
        driver.find_element_by_xpath(locators.showhide).click()
        tx = driver.find_elements_by_xpath(locators.firstrow) # gives the total number of Rows in the table
        print(len(tx))
        t = 0
        t2 = 0
        for i in range(len(tx)):
            tx = driver.find_element_by_xpath('(' + locators.firstrow + ')' + '[' + str(i + 1) + ']').text
            tx = tx.split('\n')
            tx1 = tx[1].replace(",", "")
            tx1 = float(tx1) if tx1 != "N/A" else 0  #Inline if Function
            t = t + tx1
            tx2 = tx[3].replace(",", "")
            tx2 = float(tx2) if tx2 != "N/A" else 0
            t2 = t2 + tx2
        #     print("Budget Graph"+str(j+1)+" : "+str(t)) # give values in list
        print("Sum Budget Graph_" + str(j) + " : " + str(t))
        B.append(round(t))
        #     print("PPV Graph"+str(j+1)+" : "+str(t2)) # give values in list
        print("Sum QTD Actuals Graph_" + str(j) + " : " + str(t2))
        Q.append(round(t2))
        driver.find_element_by_xpath(locators.showhide).click()
        driver.find_element_by_xpath(locators.min1).click()
    print(B, Q)
    if ESKPI[0] != B[0]:
        bud = "Budget not matching for Graph2"
    if ESKPI[1] != Q[0]:
        qtd = "QTD Actuals not matching for Graph2"
    print(bud, qtd)
    assert ((bud != "Budget not matching for Graph2") & (
            qtd != "QTD Actuals not matching for Graph2")), "Budget or QTD Actuals not matching for Graph2"

def G3_Budget_WSR_WON():
    # Budget,WSR and WON in first 3-4 graphs
    B = []
    WS = []
    WN = []
    bud=""
    wsr=""
    won=""
    ESKPI = ES_KPI()
    for j in [3]:
        driver.find_element_by_xpath(locators.max1 + '[' + str(j) + ']').click()
        driver.find_element_by_xpath(locators.showhide).click()
        tx = driver.find_elements_by_xpath(locators.firstrow) # gives the total number of Rows in the table
        print(len(tx))
        t = 0
        t2 = 0
        t3 = 0
        for i in range(len(tx)):
            tx = driver.find_element_by_xpath('(' + locators.firstrow + ')' + '[' + str(i + 1) + ']').text
            tx = tx.split('\n')
            tx1 = tx[1].replace(",", "")
            tx1 = float(tx1) if tx1 != "N/A" else 0
            t = t + tx1
            tx2 = tx[3].replace(",", "")
            tx2 = float(tx2) if tx2 != "N/A" else 0
            t2 = t2 + tx2
            tx3 = tx[10].replace(",", "")
            tx3 = float(tx3) if tx3 != "N/A" else 0
            t3 = t3 + tx3
        #     print("Budget Graph"+str(j+1)+" : "+str(t)) # give values in list
        print("Sum Budget Graph_" + str(j) + " : " + str(t))
        B.append(round(t))
        #     print("PPV Graph"+str(j+1)+" : "+str(t2)) # give values in list
        print("Sum WSR Graph_" + str(j) + " : " + str(t2))
        WS.append(round(t2))
        print("Sum WON Graph_" + str(j) + " : " + str(t3))
        WN.append(round(t3))
        driver.find_element_by_xpath(locators.showhide).click()
        driver.find_element_by_xpath(locators.min1).click()
    print(B, WS, WN)
    if ESKPI[0] != B[0]:
        bud = "Budget not matching for Graph3"
    if ESKPI[2] != WS[0]:
        wsr = "WSR not matching for Graph3"
    # if ESKPI[7] != WN[0]:
    #     won = "WON not matching for Graph3"
    print(bud, wsr,won)
    assert ((bud != "Budget not matching for Graph3") & (
            wsr != "WSR not matching for Graph3")), "Budget or WSR not matching for Graph3"


def G4_Budget_WSR():
    B = []
    W = []
    bud=""
    wsr=""
    ESKPI = ES_KPI()
    # for j in range(2):
    for j in [4]:
        # driver.find_element_by_xpath(locators.max1 + '[' + str(j + 1) + ']').click()
        driver.find_element_by_xpath(locators.max1 + '[' + str(j) + ']').click()
        driver.find_element_by_xpath(locators.showhide).click()
        tx = driver.find_elements_by_xpath(locators.firstrow) # gives the total number of Rows in the table
        print(len(tx))
        t = 0
        t2 = 0
        # for i in range(len(tx)):
        tx = driver.find_element_by_xpath('(' + locators.firstrow + ')' + '[' + str(3) + ']').text
        tx = tx.split('\n')
        tx1 = tx[1].replace(",", "")
        tx1 = float(tx1) if tx1 != "N/A" else 0  #Inline if Function
            # t = t + tx1
            # tx2 = tx[4].replace(",", "")
            # tx2 = float(tx2) if tx2 != "N/A" else 0
            # t2 = t2 + tx2
        tx2 = driver.find_element_by_xpath('(' + locators.firstrow + ')' + '[' + str(3) + ']').text
        tx2 = tx2.split('\n')
        tx2 = tx[4].replace(",", "")
        tx2 = float(tx2) if tx2 != "N/A" else 0  # Inline if Function
        #     print("Budget Graph"+str(j+1)+" : "+str(t)) # give values in list
        print("Budget Graph_" + str(j) + " : " + str(tx1))
        B.append(round(tx1))
        #     print("PPV Graph"+str(j+1)+" : "+str(t2)) # give values in list
        print("WSR Graph_" + str(j) + " : " + str(tx2))
        W.append(round(tx2))
        driver.find_element_by_xpath(locators.showhide).click()
        driver.find_element_by_xpath(locators.min1).click()
    print(B, W)
    if ESKPI[0] != B[0]:
        bud = "Budget not matching for Graph4"
    if ESKPI[2] != W[0]:
        wsr = "WSR not matching for Graph4"
    print(bud, wsr)
    assert ((bud != "Budget not matching for Graph4") & (
            wsr != "WSR not matching for Graph4")), "Budget or WSR not matching for Graph4"




# Drilldown to EBR and Drill up one level at a time
def DrillDown_UP_one_level():
    GH1= driver.find_elements_by_xpath(locators.ES_Graph1)
    s=len(GH1)
    det=Common.getlist()
    print("Branch EBU "+str(det))
    P_ok=det[0]
    # print(P_ok)
    for i in P_ok:
        time.sleep(5)
        GH1= driver.find_elements_by_xpath(locators.ES_Graph1)
        print(i)
        ActionChains(driver).move_to_element(GH1[i]).perform()
        time.sleep(5)
        CL= driver.find_elements_by_xpath(locators.Drilldown)
        print(i)
        print(type(i))
        ActionChains(driver).click(CL[i]).perform()
        time.sleep(5)
        print("DrillDown to Market")
        det1=Common.getlist()
        print("Market: "+str(det1))
        P_ok1=det1[0]
        for j in P_ok1:
            time.sleep(5)
            DD1= driver.find_elements_by_xpath(locators.ES_Graph1_1)
            ActionChains(driver).move_to_element(DD1[j]).perform()
            time.sleep(5)
            CL= driver.find_elements_by_xpath(locators.Drilldown)
            print(j)
            print(type(j))
            ActionChains(driver).click(CL[j]).perform()
            time.sleep(5)
            print("DrillDown to EBR")
            break
        driver.find_element_by_xpath(locators.Drilup_updated).click()
        time.sleep(5)
        print("DrillUP to Market")
        break
    driver.find_element_by_xpath(locators.Drilup_updated).click()
    print("DrillUP to Geo")

# Drilldown to EBR and Drill up Top level
def DrillDown_UP_Top_level():
    driver.find_element_by_xpath(locators.ES).click()
    time.sleep(10)
    GH1= driver.find_elements_by_xpath(locators.ES_Graph1)
    s=len(GH1)
    det=Common.getlist()
    print("Geo "+str(det))
    P_ok=det[0]
    for i in P_ok:
        time.sleep(5)
        GH1= driver.find_elements_by_xpath(locators.ES_Graph1)
        ActionChains(driver).move_to_element(GH1[i]).perform()
        time.sleep(5)
        CL= driver.find_elements_by_xpath(locators.Drilldown)
        print(i)
        print(type(i))
        ActionChains(driver).click(CL[i]).perform()
        time.sleep(5)
        print("DrillDown to Market")
        det1=Common.getlist()
        print("Market: "+str(det1))
        P_ok1=det1[0]
        for j in P_ok1:
            time.sleep(5)
            DD1= driver.find_elements_by_xpath(locators.ES_Graph1_1)
            ActionChains(driver).move_to_element(DD1[j]).perform()
            time.sleep(5)
            CL= driver.find_elements_by_xpath(locators.Drilldown)
            print(j)
            print(type(j))
            ActionChains(driver).click(CL[j]).perform()
            time.sleep(5)
            print("DrillDown to EBR")
            break
        break
    driver.find_element_by_xpath(locators.DrillTop).click()
    print("DrillTOP to Geo")

def EStop_nav():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle=driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    time.sleep(2)
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :"+str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-1):
        time.sleep(2)
        GH1[i].click()
        time.sleep(2)
        Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
        print(Topnav.text)
        listLegend1.append(Topnav.text)
        driver.find_element_by_xpath(locators.dropdown_wrapper).click()
    # print(listLegend1)
    for i in listLegend1:
            listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    assert listLegend2==[['NQ'], ['Signings', 'Signings-ACV'], ['All', 'Americas', 'EMEA', 'Japan', 'APAC', 'INVALID', 'UNASSIGNED'], ['All', 'Systems w/TPS', 'Cloud & Data Platform', 'Security', 'Cognitive Applications','Watson Health']],  "Not expected"
    return listLegend2

# modify executive summary view checking
def MESChecking():
    time.sleep(2)
    driver.find_element_by_xpath(locators.MES_Icon).click()
    time.sleep(2)
    driver.find_element_by_xpath(locators.MES_Newfilter).click()
    time.sleep(2)
    MES= driver.find_element_by_xpath(locators.MES_breadcrumb).text
    print("Modify executive summary: "+MES)
    time.sleep(3)
    driver.find_element_by_xpath(locators.MES_cancel).click()
#        assert MES==('Executive Summary > Modify Executive Summary'), "Text is not matching"
#         print(MES)
    return MES

def ESGraphDate1():
    # driver.find_element_by_xpath("//*[@id='exe']").click()
    td = date.today()
    weeklydate = (td.weekday() - 2) % 7
    last_wednesday = td - timedelta(days=weeklydate)
    Wednesday = datetime.strftime(last_wednesday, '%b %d, %Y')
    print("Wednesday date :" + Wednesday)
    time.sleep(2)

    GH1 = driver.find_element_by_xpath(locators.GH1).text
    print("Graph1 title : " + str(GH1))
    time.sleep(2)
    GH1Date = driver.find_element_by_xpath(locators.GH1Date).text
    Gh1date = str(GH1Date).replace("Data as of ", "")
    assert Gh1date.find(Wednesday) == 0, "Date is not matching"
    print("Graph1date : " + Gh1date)

def ESGraphDate2():
    # td = date.today()
    # weeklydate = (td.weekday() - 2) % 7
    # last_wednesday = td - timedelta(days=weeklydate)
    # Wednesday = datetime.strftime(last_wednesday, '%b %d, %Y')
    # print("Wednesday date :" + Wednesday)
    time.sleep(2)
    GH2 = driver.find_element_by_xpath(locators.GH2).text
    print("Graph2 title : " + str(GH2))
    time.sleep(2)
    GH2Date = driver.find_element_by_xpath(locators.GH2Date).text
    Gh2date = str(GH2Date).replace("Data as of ", "")
    # assert Gh2date.find(Wednesday) == 0, "Date is not matching"
    print("Graph2 Date : " + GH2Date)

def ESGraphDate3():
    time.sleep(2)
    GH3 = driver.find_element_by_xpath(locators.GH3).text
    print("Graph3 title : " + GH3)
    time.sleep(2)
    GH3Date = driver.find_element_by_xpath(locators.GH3Date).text
    GH3Date1 =str(GH3Date).replace("Data as of ", "")
    print("Graph3 Date : " +GH3Date1)

def ESGraphDate4():
    time.sleep(2)
    GH4 = driver.find_element_by_xpath(locators.GH4).text
    print("Graph4 title : " + GH4)
    GH4Date = driver.find_element_by_xpath(locators.GH4Date).text
    GH4Date1 = str(GH4Date).replace("Data as of ", "")
    print("Graph4 Date : " + GH4Date1)

def Weekly_date(date):
    td = date.today()
    weeklydate = (td.weekday() - 2) % 7
    last_wednesday = td - timedelta(days=weeklydate)
    Wednesday = datetime.strftime(last_wednesday, '%b %d, %Y')
    # return  Wednesday
    print("Wednesday date :" + Wednesday)

def VP_KPI_DF_Grp():
    time.sleep(5)
    Vp_block = driver.find_element_by_xpath(locators.VP2)
    print(Vp_block.text)
    global VP_Val
    VP_Val=Common.es_kpi1(Vp_block)
    print(VP_Val)
    print("VP is " + str(VP_Val))
    time.sleep(3)
    Vp_block.click()
    time.sleep(3)
    Vp_group_default = driver.find_element_by_xpath(locators.Def_Grp)
    print(Vp_group_default.text)
    assert Vp_group_default.text == "By Sales Stage", "Default Group for VP is incorrect"
    # return VP_Val,Vp_group_default

def VP_KPI_vs_Summary_DealList():
    # print(VP_Val)
    time.sleep(5)
    Vp_Summary_header = driver.find_element_by_xpath(locators.Summary_deal_header_val)
    global Vp_Deal_value_2
    Vp_Deal_value_2 = Vp_Summary_header.text.replace(",", "")
    Vp_Deal_value_2 = re.findall(r'[0-9]+[.]?[0-9]+', Vp_Deal_value_2)
    Vp_Deal_value_2 = Vp_Deal_value_2[0]

    print("Summary header lineitem Value for VP click is " + str(Vp_Deal_value_2))
    diff = abs(float(VP_Val) - float(Vp_Deal_value_2))
    print("Difference of Kpi vs Deallist line item value is " + format(diff, '.2f'))
    assert diff<1,"Mismatch between VP KPI value and VP Click Deallist Line item Value"

def VP_KPI_Summary_DealList_vs_Sum_Detailed_List():
    time.sleep(5)
    Detailed_list = driver.find_elements_by_css_selector(locators.Detailed_list)
    summary = []
    for i in range(len(Detailed_list)):
        Detailed_list_value = Detailed_list[i].text
        Detailed_list_value = Detailed_list_value.replace(",", "")
        Detailed_list_value = re.findall(r'[0-9]+[.]?[0-9]+', Detailed_list_value)
        Detailed_list_value = Detailed_list_value[0]
        print(Detailed_list_value)
        summary.append(float(Detailed_list_value))

    # print(summary)
    sum_summary = sum(summary)
    print("All VP Deal list sum is " + str(sum_summary))

    diff_dealvSummaryLI = abs(float(sum_summary) - float(Vp_Deal_value_2))
    print("Difference of VP Deal listsum vs Deallist line item value is " + format(diff_dealvSummaryLI, '.2f'))
    time.sleep(3)
    Common.common_Close_dealList()
    assert diff_dealvSummaryLI < 1, "Mismatch between VP KPI Click Deallist Line item Value and Sum of Detailed Deal list"

def WSR_KPI_DF_Grp():
    time.sleep(5)
    WSR_block = driver.find_element_by_xpath(locators.WSR)
    print(WSR_block.text)
    global WSR_Val
    WSR_Val=Common.es_kpi1(WSR_block)
    print(WSR_Val)
    print("WSR is " + str(WSR_Val))
    time.sleep(3)
    WSR_block.click()
    time.sleep(3)
    WSR_group_default = driver.find_element_by_xpath(locators.Def_Grp)
    print(WSR_group_default.text)
    assert WSR_group_default.text == "By Roadmap Status", "Default Group for WSR is incorrect"
    # return VP_Val,Vp_group_default

def WSR_KPI_vs_Summary_DealList():
    # print(VP_Val)
    time.sleep(5)
    WSR_Summary_header = driver.find_element_by_xpath(locators.Summary_deal_header_val)
    global WSR_Deal_value_2
    WSR_Deal_value_2 = WSR_Summary_header.text.replace(",", "")
    WSR_Deal_value_2 = re.findall(r'[0-9]+[.]?[0-9]+', WSR_Deal_value_2)
    WSR_Deal_value_2 = WSR_Deal_value_2[0]

    print("Summary header lineitem Value for WSR click is " + str(WSR_Deal_value_2))
    diff = abs(float(WSR_Val) - float(WSR_Deal_value_2))
    print("Difference of WSR Kpi vs Deallist line item value is " + format(diff, '.2f'))
    assert diff<1,"Mismatch between WSR KPI value and WSR Click Deallist Line item Value"

def WSR_KPI_Summary_DealList_vs_Sum_Detailed_List():
    time.sleep(5)
    Detailed_list = driver.find_elements_by_css_selector(locators.Detailed_list)
    summary = []
    for i in range(len(Detailed_list)):
        Detailed_list_value = Detailed_list[i].text
        Detailed_list_value = Detailed_list_value.replace(",", "")
        Detailed_list_value = re.findall(r'[0-9]+[.]?[0-9]+', Detailed_list_value)
        Detailed_list_value = Detailed_list_value[0]
        print(Detailed_list_value)
        summary.append(float(Detailed_list_value))

    # print(summary)
    sum_summary = sum(summary)
    print("All WSR Deal list sum is " + str(sum_summary))

    diff_dealvSummaryLI = abs(float(sum_summary) - float(WSR_Deal_value_2))
    print("Difference of WSR Deal listsum vs Deallist line item value is " + format(diff_dealvSummaryLI, '.2f'))
    time.sleep(3)
    Common.common_Close_dealList()
    assert diff_dealvSummaryLI < 1, "Mismatch between WSR KPI Click Deallist Line item Value and Sum of Detailed Deal list"

def WON_KPI_DF_Grp():
    time.sleep(5)
    WON_block = driver.find_element_by_xpath(locators.WON2)
    print(WON_block.text)
    global WON_Val
    WON_Val=Common.es_kpi1(WON_block)
    print(WON_Val)
    print("WON is " + str(WON_Val))
    time.sleep(3)
    WON_block.click()
    time.sleep(3)
    WON_group_default = driver.find_element_by_xpath(locators.Def_Grp)
    print(WON_group_default.text)
    assert WON_group_default.text == "By Sales Stage", "Default Group for WON is incorrect"
    # return VP_Val,Vp_group_default

def WON_KPI_vs_Summary_DealList():
    # print(VP_Val)
    time.sleep(5)
    WON_Summary_header = driver.find_element_by_xpath(locators.Summary_deal_header_val)
    global WON_Deal_value_2
    WON_Deal_value_2 = WON_Summary_header.text.replace(",", "")
    WON_Deal_value_2 = re.findall(r'[0-9]+[.]?[0-9]+', WON_Deal_value_2)
    WON_Deal_value_2 = WON_Deal_value_2[0]

    print("Summary header lineitem Value for WON click is " + str(WON_Deal_value_2))
    diff = abs(float(WON_Val) - float(WON_Deal_value_2))
    print("Difference of WON Kpi vs Deallist line item value is " + format(diff, '.2f'))
    assert diff<1,"Mismatch between WON KPI value and WON Click Deallist Line item Value"

def WON_KPI_Summary_DealList_vs_Sum_Detailed_List():
    time.sleep(5)
    Detailed_list = driver.find_elements_by_css_selector(locators.Detailed_list)
    summary = []
    for i in range(len(Detailed_list)):
        Detailed_list_value = Detailed_list[i].text
        Detailed_list_value = Detailed_list_value.replace(",", "")
        Detailed_list_value = re.findall(r'[0-9]+[.]?[0-9]+', Detailed_list_value)
        Detailed_list_value = Detailed_list_value[0]
        print(Detailed_list_value)
        summary.append(float(Detailed_list_value))

    # print(summary)
    sum_summary = sum(summary)
    print("All WON Deal list sum is " + str(sum_summary))

    diff_dealvSummaryLI = abs(float(sum_summary) - float(WON_Deal_value_2))
    print("Difference of WON Deal listsum vs Deallist line item value is " + format(diff_dealvSummaryLI, '.2f'))
    time.sleep(3)
    Common.common_Close_dealList()
    assert diff_dealvSummaryLI < 1, "Mismatch between WON KPI Click Deallist Line item Value and Sum of Detailed Deal list"

def QP_KPI_DF_Grp():
    QP_block = driver.find_element_by_xpath(locators.QP2)
    print(QP_block.text)
    global QP_Val
    QP_Val=Common.es_kpi1(QP_block)
    print(QP_Val)
    print("QP is " + str(QP_Val))
    QP_block.click()
    time.sleep(3)
    QP_group_default = driver.find_element_by_xpath(locators.Def_Grp)
    print(QP_group_default.text)
    assert QP_group_default.text == "By Sales Stage", "Default Group for QP is incorrect"
    # return VP_Val,Vp_group_default

def QP_KPI_vs_Summary_DealList():
    # print(VP_Val)
    QP_Summary_header = driver.find_element_by_xpath(locators.Summary_deal_header_val)
    global QP_Deal_value_2
    QP_Deal_value_2 = QP_Summary_header.text.replace(",", "")
    QP_Deal_value_2 = re.findall(r'[0-9]+[.]?[0-9]+', QP_Deal_value_2)
    QP_Deal_value_2 = QP_Deal_value_2[0]

    print("Summary header lineitem Value for QP click is " + str(QP_Deal_value_2))
    diff = abs(float(QP_Val) - float(QP_Deal_value_2))
    print("Difference of QP Kpi vs Deallist line item value is " + format(diff, '.2f'))
    assert diff<1,"Mismatch between QP KPI value and QP Click Deallist Line item Value"

def QP_KPI_Summary_DealList_vs_Sum_Detailed_List():
    Detailed_list = driver.find_elements_by_css_selector(locators.Detailed_list)
    summary = []
    for i in range(len(Detailed_list)):
        Detailed_list_value = Detailed_list[i].text
        Detailed_list_value = Detailed_list_value.replace(",", "")
        Detailed_list_value = re.findall(r'[0-9]+[.]?[0-9]+', Detailed_list_value)
        Detailed_list_value = Detailed_list_value[0]
        print(Detailed_list_value)
        summary.append(float(Detailed_list_value))

    # print(summary)
    sum_summary = sum(summary)
    print("All QP Deal list sum is " + str(sum_summary))

    diff_dealvSummaryLI = abs(float(sum_summary) - float(QP_Deal_value_2))
    print("Difference of QP Deal listsum vs Deallist line item value is " + format(diff_dealvSummaryLI, '.2f'))
    time.sleep(3)
    Common.common_Close_dealList()
    assert diff_dealvSummaryLI < 1, "Mismatch between QP KPI Click Deallist Line item Value and Sum of Detailed Deal list"



##---------------------------call code below-------------------------##

#
# Login_Page.open_ISD()
# ISDLOGO()
# NEEDHELP()
# Profile_Page_AH()
# PRIVACY()
# ABOUTISD()
# PROFILEINFO()
# LEXPANDICON()
# LEXPANDICON_close()
# es_breadcrumb()
# ES_KPI()
## es_budget(Graph1()) #(ingore for now)
## es_ppv(Graph1()) #(ingore for now)
## geo_check(Graph1()) #(ingore for now)
## graph2()   # Giving error due to "N/A" #(ingore for now)
# G1_Budget_PPV()
# G2_Budget_QTD_Actuals()
# G3_Budget_WSR_WON()
# G4_Budget_WSR()
# DrillDown_UP_one_level()
# DrillDown_UP_Top_level()
# EStop_nav()
# MESChecking()
# ESGraphDate1()
# ESGraphDate2()
# ESGraphDate3()
# ESGraphDate4() # ignore for now
# #
# VP_KPI_DF_Grp()
# VP_KPI_vs_Summary_DealList()
# VP_KPI_Summary_DealList_vs_Sum_Detailed_List()

# WSR_KPI_DF_Grp()
# WSR_KPI_vs_Summary_DealList()
# WSR_KPI_Summary_DealList_vs_Sum_Detailed_List()

# WON_KPI_DF_Grp()
# WON_KPI_vs_Summary_DealList()
# WON_KPI_Summary_DealList_vs_Sum_Detailed_List()
#
# QP_KPI_DF_Grp()
# QP_KPI_vs_Summary_DealList()
# QP_KPI_Summary_DealList_vs_Sum_Detailed_List()