from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
import re
from selenium.webdriver.common.action_chains import ActionChains
from datetime import date
from datetime import datetime
from datetime import timedelta
import locators
import Login_Page
import Common
import Constants
import ES_Page
import AP_Page
import SP_Page
import RD_Page
import KD_Page
import MI_Page



driver = Login_Page.driver



def ES_IPE():
    ES_Page.es()
    ES_Page.es_breadcrumb()
    ES_Page.ES_KPI()
    ES_Page.es_budget()
    ES_Page.es_ppv()
    ES_Page.ESGraphDate1()
    ES_Page.ESGraphDate2()
    ES_Page.ESGraphDate3()
    ES_Page.ESGraphDate4()

def ES_Topnav_IPE():
        driver.find_element_by_xpath(locators.filter_icon).click()
        MoveEle = driver.find_element_by_xpath(locators.MoveElementSomewhere)
        action = ActionChains(driver)
        action.move_to_element(MoveEle).perform()
        time.sleep(2)
        GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
        topnavlength = len(GH1)
        print("Total Topnav :" + str(topnavlength))
        listLegend1 = []
        listLegend2 = []
        for i in range(len(GH1) - 1):
            time.sleep(2)
            GH1[i].click()
            time.sleep(2)
            Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
            print(Topnav.text)
            listLegend1.append(Topnav.text)
            driver.find_element_by_xpath(locators.dropdown_wrapper).click()
        # print(listLegend1)
        for i in listLegend1:
            listLegend2.append(i.split('\n'))
        print("Topnav Elements :" + str(listLegend2))
        driver.find_element_by_xpath(locators.filter_icon_close).click()
        assert listLegend2 == [['NQ'], ['Signings-ACV'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'Systems w/TPS', 'Cloud & Data Platform', 'Security', 'Cognitive Applications', 'Watson Health', 'Industry Platforms']], "Not expected"

        return listLegend2

def APtop_nav_IPE():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle=driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    time.sleep(2)
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :"+str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-2):
        time.sleep(2)
        GH1[i].click()
        time.sleep(2)
        Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
        print(Topnav.text)
        listLegend1.append(Topnav.text)
        driver.find_element_by_xpath(locators.dropdown_wrapper).click()
    # print(listLegend1)
    for i in listLegend1:
            listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    assert listLegend2==[['NQ'], ['Signings-ACV'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'Systems w/TPS', 'Cloud & Data Platform', 'Security', 'Cognitive Applications', 'Watson Health', 'Industry Platforms'], ['UNIT']]
    return listLegend2


def SPtop_nav_IPE():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle = driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    time.sleep(2)
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :" + str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-4):
        time.sleep(2)
        GH1[i].click()
        time.sleep(2)
        Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
        print(Topnav.text)
        listLegend1.append(Topnav.text)
        driver.find_element_by_xpath(locators.dropdown_wrapper).click()
    # print(listLegend1)
    for i in listLegend1:
        listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    time.sleep(5)
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    assert listLegend2 == [['NQ'], ['Signings-ACV'],
                           ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group',
                            'Latin America', 'Middle East & Africa', 'UNASSIGNED'],
                           ['All', 'Systems w/TPS', 'Cloud & Data Platform', 'Security',
                            'Cognitive Applications', 'Watson Health',
                            'Industry Platforms'],['SUMMARY','CLIENT SET', 'DEAL SIZE', 'CHANNEL', 'JTC/RHS', 'JTC', 'RHS']], "Not expected"
    return listLegend2


def RMtop_nav_IPE():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle = driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    # driver.find_element_by_xpath(locators.RMTab).click()
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :" + str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1) - 4):
        time.sleep(2)
        GH1[i].click()
        time.sleep(2)
        Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
        print(Topnav.text)
        listLegend1.append(Topnav.text)
        driver.find_element_by_xpath(locators.dropdown_wrapper).click()
    for i in listLegend1:
        listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    time.sleep(2)
    assert listLegend2 == [['NQ'], ['Signings-ACV'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'Systems w/TPS', 'Cloud & Data Platform', 'Security', 'Cognitive Applications', 'Watson Health', 'Industry Platforms'], ['LIO'], ['BU', 'CLIENT SEGMENT']], "not expected"

    return listLegend2

def kdtop_nav_IPE():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle = driver.find_element_by_xpath(locators.MoveElementkd)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :" + str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-8):
        time.sleep(2)
        GH1[i].click()
        time.sleep(2)
        Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
        print(Topnav.text)
        listLegend1.append(Topnav.text)
        driver.find_element_by_xpath(locators.dropdown_wrapper).click()
    for i in listLegend1:
        listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    time.sleep(5)
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    assert listLegend2 == [['NQ'], ['Signings-ACV'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'Systems w/TPS', 'Cloud & Data Platform', 'Security', 'Cognitive Applications', 'Watson Health', 'Industry Platforms'], ['LIO'], ['CLIENT AGGREGATION', 'ALL LINE ITEMS'], ['By BU group', 'By BU Sub group', 'By Level 17', 'By WSR', 'By Dealsize', 'By SAQ', 'By SAQ Quadrant', 'By Market', 'By Branch Group (EBR)', 'By Branch (EBU)', 'By Branch Unit (ESU)', 'By Client Type', 'By Client Sub Type', 'By Client Set', 'By Channel', 'By Reporting Country', 'By Roadmap Status', 'By Close/Bill Week', 'By Close/Bill Month', 'By OI Source', 'By ISU Group', 'By ISU', 'By Geo', 'By BP Comp. Name']],"not expected"
    return listLegend2

def Mitop_nav_IPE():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle = driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :" + str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-4):
        time.sleep(2)
        GH1[i].click()
        time.sleep(2)
        Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
        print(Topnav.text)
        listLegend1.append(Topnav.text)
        driver.find_element_by_xpath(locators.dropdown_wrapper).click()
    for i in listLegend1:
        listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    time.sleep(3)
    driver.find_element_by_xpath(locators.common_GlobalFilterXicon).click()
    assert listLegend2 == [['NQ'], ['Signings-ACV'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'Systems w/TPS', 'Cloud & Data Platform', 'Security', 'Cognitive Applications', 'Watson Health', 'Industry Platforms'], ['LIO'], ['ALL LINE ITEMS'], ['Identifying (1)', 'Validated (4)', 'Qualifying (7)', 'Gaining Agreement (6)']], "is not expected"
    return listLegend2

def Graphs_headers():
    time.sleep(5)

    Summary_headers = driver.find_elements_by_xpath(locators.Summary_headers)
    print('length is ', len(Summary_headers))

    for i in range(len(Summary_headers)):
        Summary_headers = driver.find_element_by_xpath("(" + "//h4[contains(@class,'text-center title')]" + ")" + "[" + str(i + 1) + "]")
        print(Summary_headers.text)
        time.sleep(2)
        assert len(Summary_headers.text) != 1, "Graphs are not loading and result is fail"

def BPOI_Seg_summary_Default():
    time.sleep(2)
    filter_clk = driver.find_element_by_xpath(locators.filter_icon)
    filter_clk.click()
    time.sleep(5)
    View_clk = driver.find_element_by_xpath(locators.View_GF)
    View_clk.click()
    View_dpdwn = driver.find_elements_by_xpath(locators.View_dropdown)
    sum=driver.find_element_by_xpath("(//div[@class='ng-dropdown-panel-items scroll-host']//div[@role='option'])[1]")
    sum.click()

    Summary_headers = driver.find_elements_by_xpath(locators.Summary_headers)
    print('length is ', len(Summary_headers))

    for i in range(len(Summary_headers)):
        Summary_headers = driver.find_element_by_xpath("(" + "//h4[@class='text-center title']" + ")" + "[" + str(i+1) + "]")
        print(Summary_headers.text)
        time.sleep(2)

    if (Summary_headers.text == "OI GROUP PPV vs Prior Week PPV"):
        print("Summary view contains OI GROUP PPV vs Prior Week PPV header and result is : True \n ")
        assert True

    else:
        print("Summary view doesnot contains OI GROUP PPV vs Prior Week PPV header and result is : False \n")
        assert False


def BPOI_seg_views():
    time.sleep(5)

    seg_clk = driver.find_element_by_xpath(locators.sp)
    seg_clk.click()
    filter_clk = driver.find_element_by_xpath(locators.filter_icon)
    filter_clk.click()
    time.sleep(5)
    View_clk = driver.find_element_by_xpath(locators.View_GF)
    View_clk.click()
    View_dpdwn = driver.find_elements_by_xpath(locators.View_dropdown)
    scroll_host = driver.find_element_by_xpath(locators.view_Scroll_host)
    scroll_host = scroll_host.text
    Actual_data = scroll_host.split("\n")
    print(Actual_data)
    Expected_scroll_data = ['BPOI','CLIENT SET', 'DEAL SIZE', 'CHANNEL', 'JTC/RHS', 'JTC', 'RHS']

    # assert list_scroll_data==data , "Data is not in order"
    if(Expected_scroll_data==Actual_data):
        print("Segmented pipeline views were matching and result is : True \n" )
        assert True

    else:
        print("Segmented Pipeline views are not matching and the result is  False \n")
        assert False

    driver.find_element_by_xpath(locators.filter_icon_close).click()

def BPOI_relatedgraphs():
    filter_clk = driver.find_element_by_xpath(locators.filter_icon)
    filter_clk.click()
    time.sleep(3)
    View_clk = driver.find_element_by_xpath(locators.View_GF)
    View_clk.click()
    assert View_clk!="True", "View is unable to click and Result is failed"

    scroll_host = driver.find_element_by_xpath(locators.view_Scroll_host)
    scroll_host = scroll_host.text
    print(scroll_host)
    View_dpdwn = driver.find_element_by_xpath(locators.View_dropdown)


    # if len(View_dpdwn) > 0 and View_dpdwn[1].is_displayed():
    View_dpdwn= View_dpdwn.click()

    Filter_close = driver.find_element_by_xpath(locators.filter_icon_close)
    Filter_close.click()
    time.sleep(5)
    Graphs_headers()
    time.sleep(5)
    filter_clk = driver.find_element_by_xpath(locators.filter_icon)
    filter_clk.click()
    time.sleep(5)
    driver.find_element_by_xpath("//*[@id='filterchevronDown-carbon']").click()
    time.sleep(1)
    driver.find_element_by_xpath("//*[@id='filterchevronDown-carbon']").click()
    Reset_btn_clk = driver.find_element_by_xpath("//button[@id='resetToDefault-btn']")
    Reset_btn_clk.click()
    time.sleep(2)
    Filter_close = driver.find_element_by_xpath(locators.filter_icon_close)
    Filter_close.click()


def BPOI_VP_KPI_clicks():
    time.sleep(2)
    SP_Page.SP_VP_KPI_DF_Grp()
    SP_Page.SP_VP_KPI_vs_Summary_DealList()
    SP_Page.SP_VP_KPI_Summary_DealList_vs_Sum_Detailed_List()
    time.sleep(2)
    print("\n")

def BPOI_KPI_QP_Deal_List():
    SP_Page.SP_QP_KPI_DF_Grp()
    SP_Page.SP_QP_KPI_vs_Summary_DealList()
    SP_Page.SP_QP_KPI_Summary_DealList_vs_Sum_Detailed_List()

def BPOI_KPI_Won_Deal_List():
    SP_Page.SP_WON_KPI_DF_Grp()
    SP_Page.SP_WON_KPI_vs_Summary_DealList()
    SP_Page.SP_WON_KPI_Summary_DealList_vs_Sum_Detailed_List()
    time.sleep(2)

def reset_Bpoi():
    filter_clk = driver.find_element_by_xpath(locators.filter_icon)
    filter_clk.click()
    Reset_btn_clk = driver.find_element_by_xpath(locators.Reset_Default)
    time.sleep(2)
    Filter_close = driver.find_element_by_xpath(locators.filter_icon_close)
    Filter_close.click()

def BPOI_inlinefilters():

    # Inline_filters_clk = driver.find_elements_by_xpath(locators.Inline_filters)
    Inline_filters_clk = driver.find_elements_by_xpath(locators.Inline_filter_options_click)
    print(len(Inline_filters_clk))

    for i in range(len(Inline_filters_clk)):
        Inline_all_clk = driver.find_element_by_xpath("(" + "//div[contains(@class,'dropDownPosition')]" + ")" + "[" + str(i+1) + "]")
        Inline_all_clk.click()
        assert Inline_all_clk.click()!=True , "Inline filters dropdown is not clickable result is Failed to click"
        time.sleep(2)
        scroll_host_options = driver.find_element_by_xpath(locators.Inline_Scroll_Host)
        print(scroll_host_options.text)
        scroll_host_options = scroll_host_options.text
        Actual_data = scroll_host_options.split("\n")
        print(Actual_data)
        Expected_scroll_data = ['QP', 'Sales Stage']
        if (Expected_scroll_data == Actual_data):
            print("Inline filters for Graphs were matching and result is : True \n")
            assert True

        else:
            print("Inline filters for Graphs were  not matching and the result is  False \n")
            assert False

def BPOI_Expand_graphs():
    Expandgraph = driver.find_elements_by_xpath(locators.Expand_graph_icon)
    for i in range(len(Expandgraph)):
        maximize = driver.find_element_by_xpath("(" + "(//*[@name='icon--maximize'])" + ")" + "[" + str(i+1) + "]")
        maximize.click()
        # assert maximize.click()!=True , "Expand Graph is not working as expeted unable to click"
        time.sleep(5)
        action = ActionChains(driver)

        Show_table = driver.find_element_by_xpath(locators.Show_tble_bpoi)
        action.move_to_element(Show_table).perform()
        time.sleep(2)

        Show_table.click()
        val = driver.find_element_by_xpath(locators.firstrow).text
        #     print(val)
        assert type(val) == str, "No Values"
        time.sleep(5)
        assert Show_table.click()!=True , "Data table is not clickable and Result is failed"

        Hide_Table = driver.find_element_by_xpath(locators.Show_tble_bpoi)
        time.sleep(5)
        minimize = driver.find_element_by_xpath(locators.min1)
        minimize = minimize.click()
        # assert minimize!=True, "Graph is not able to minimize and the result is failed"
        time.sleep(3)

def BPOI_Inlinefilters_loop_click():
    time.sleep(5)
    # driver.find_element_by_xpath(locators.Inline_filters).click()
    driver.find_element_by_xpath(locators.Inline_filter_options_click).click()
    Inline_filters_clk = driver.find_elements_by_xpath(locators.Inline_filter_options)
    driver.find_element_by_xpath(locators.Inline_arrow_graph1).click()
    print('lenght of inline filters is', len(Inline_filters_clk))

    for j in range(len(Inline_filters_clk)):
        print(j)
        time.sleep(4)
        # Inline = driver.find_element_by_xpath("(" + "//div[@class='ng-dropdown-panel-items scroll-host']//div[@role='option']" + ")" + "[" + str(j + 1) + "]")
        driver.find_element_by_xpath(locators.Inline_filter_options_click).click()
        Inline_all_clks = "(" + "//div[@class='ng-dropdown-panel-items scroll-host']//div[@role='option']" + ")" + "[" + str(j + 1) + "]"
        Inline_clk_option = driver.find_element_by_xpath(Inline_all_clks)
        Inline_clk_options = Inline_clk_option.text
        print('Followed View is  ', Inline_clk_options)
        clk_inline = Inline_clk_option.click()
        time.sleep(4)
        Legends_data = driver.find_element_by_xpath("//*[@class='legend-labels']")
        print("Legends data for (" + str(Inline_clk_options) + ")" , Legends_data.text)
        Expcted_legend_QP = "CW QP($M)"
        Expected_legend_SS = ['Won','Conditional Agreement','Qualified','Validated']

        if Inline_clk_options == "QP":
            if Legends_data.text!=Expcted_legend_QP :
                print("Legends data for (" + str(Legends_data.text) + ") is NOT matching with ("+str(Expcted_legend_QP)+")"  )
                assert False

        elif Inline_clk_options == "Sales Stage":
            if Legends_data.text.split("\n")!=Expected_legend_SS :
                print("Legends data for (" + str(Legends_data.text) + ") is NOT matching with ("+str(Expected_legend_SS)+")"  )
                assert False

        Header_inline_txt = driver.find_element_by_xpath(locators.Header_graph_1)
        Header_inline_txts = Header_inline_txt.text
        Header_inline_txt = Header_inline_txt.text.split("-")
        Header_inline_txt = Header_inline_txt[1]
        Header_inline_txt = str.strip(str(Header_inline_txt))
        print('Inline click header is ', Header_inline_txt)

        if(Inline_clk_options==Header_inline_txt):
            print("Inline filters are  in sync with Headers and result is passed")
            assert True
        else:
            print("Inline filters are  not in sync with Header and the result is Failed")
            assert False

        time.sleep(2)
        Expand_graph = driver.find_element_by_xpath(locators.Expand_graph_1)
        Expand_graph.click()
        Exapnd_graph_header = driver.find_element_by_xpath(locators.Expand_header_graph_1)
        Exapnd_graph_header = Exapnd_graph_header.text

        if(Header_inline_txts== Exapnd_graph_header):

            print("Default Graph header is equal to expand graph header and result is True \n")
            assert  True

        else:
            print("Default graph header is not equal to expand graph header and result is false \n")
            assert False

        action = ActionChains(driver)
        Show_table = driver.find_element_by_xpath("//button[@class='buttonShowHide ng-star-inserted']")
        action.move_to_element(Show_table).perform()
        time.sleep(2)
        Show_table.click()
        val = driver.find_element_by_xpath(locators.firstrow).text
        #     print(val)
        assert type(val) == str, "No Values"

        assert Show_table.click() != True, "Data table is not clickable and Result is failed"

        Hide_Table = driver.find_element_by_xpath(locators.Hide_table_clk)
        Hide_Table.click()

        # assert Hide_Table.click()!= True , "Hide Table is not able to click and result is failed"
        time.sleep(2)
        minimize = driver.find_element_by_xpath(locators.min1)
        minimize = minimize.click()
        # BPOI_VP_KPI_clicks()
        # BPOI_KPI_QP_Deal_List()
        # BPOI_KPI_Won_Deal_List()



def Inline_loop_Graphs_2():

    driver.find_element_by_xpath(locators.Inline_filter_options_clk_2).click()
    Inline_filters_clk = driver.find_elements_by_xpath(locators.Inline_filter_options)
    driver.find_element_by_xpath(locators.Inline_arrow_graph_2).click()
    print('lenght of inline filters is', len(Inline_filters_clk))

    for j in range(len(Inline_filters_clk)):
        print(j)
        time.sleep(4)
        driver.find_element_by_xpath(locators.Inline_click_2).click()
        time.sleep(2)
        Inline_all_clks = "(" + "//div[@class='ng-dropdown-panel-items scroll-host']//div[@role='option']" + ")" + "[" + str(j + 1) + "]"
        Inline_clk_option = driver.find_element_by_xpath(Inline_all_clks)
        Inline_clk_options2 = Inline_clk_option.text

        print('Followed View is  ', Inline_clk_options2)

        clk_inline = Inline_clk_option.click()
        time.sleep(2)
        Legends_data = driver.find_element_by_xpath("(//*[@class='legend-labels'])[2]")
        print("Legends data for (" + str(Inline_clk_options2) + ")", Legends_data.text)
        Expcted_legend_QP = "CW QP($M)"
        Expected_legend_SS = ['Won', 'Conditional Agreement', 'Qualified', 'Validated']

        if Inline_clk_options2 == "QP":
            if Legends_data.text != Expcted_legend_QP:
                print("Legends data for (" + str(Legends_data.text) + ") is NOT matching with (" + str(Expcted_legend_QP) + ")")
                assert False

        elif Inline_clk_options2 == "Sales Stage":
            if Legends_data.text.split("\n") != Expected_legend_SS:
                print("Legends data for (" + str(Legends_data.text) + ") is NOT matching with (" + str(Expected_legend_SS) + ")")
                assert False
        Header_inline_txt = driver.find_element_by_xpath(locators.Graph_header_2)
        Header_inline_txts = Header_inline_txt.text
        Header_inline_txt = Header_inline_txt.text.split("-")
        Header_inline_txt = Header_inline_txt[1]
        Header_inline_txt = str.strip(str(Header_inline_txt))
        print('Inline click header is ', Header_inline_txt)

        if (Inline_clk_options2 == Header_inline_txt):
            print("Inline filters are  in sync with Headers and result is passed")
            assert True
        else:
            print("Inline filters are  not in sync with Header and the result is Failed")
            assert False
        time.sleep(2)

        Expand_graph = driver.find_element_by_xpath(locators.Expand_graph_2)
        Expand_graph.click()
        Exapnd_graph_header = driver.find_element_by_xpath(locators.Header_graph_2)
        Exapnd_graph_header = Exapnd_graph_header.text

        if (Header_inline_txts == Exapnd_graph_header):

            print("Default Graph header is equal to expand graph header and result is True \n")
            assert True

        else:
            print("Default graph header is not equal to expand graph header and result is false \n")
            assert False

        action = ActionChains(driver)
        Show_table = driver.find_element_by_xpath(locators.Show_tble_bpoi)
        action.move_to_element(Show_table).perform()
        time.sleep(2)
        Show_table.click()
        val = driver.find_element_by_xpath(locators.firstrow).text
        #     print(val)
        assert type(val) == str, "No Values"

        assert Show_table.click() != True, "Data table is not clickable and Result is failed"

        Hide_Table = driver.find_element_by_xpath(locators.Show_tble_bpoi)
        Hide_Table.click()
        time.sleep(2)
        minimize = driver.find_element_by_xpath(locators.Expand_minimize)
        minimize = minimize.click()
        BPOI_VP_KPI_clicks()
        BPOI_KPI_QP_Deal_List()
        BPOI_KPI_Won_Deal_List()

def Inline_loop_Graphs_3():
    time.sleep(2)
    driver.find_element_by_xpath(locators.Inline_filter_options_clk_3).click()
    Inline_filters_clk = driver.find_elements_by_xpath(locators.Inline_filter_options)
    driver.find_element_by_xpath(locators.Inline_arrow_graph_3).click()
    print('lenght of inline filters is', len(Inline_filters_clk))

    for j in range(len(Inline_filters_clk)):

        time.sleep(2)
        driver.find_element_by_xpath(locators.Inline_filter_options_clk_3).click()
        # Inline = driver.find_element_by_xpath("(" + "//div[@class='ng-dropdown-panel-items scroll-host']//div[@role='option']" + ")" + "[" + str(j + 1) + "]")
        Inline_all_clks = "(" + "//div[@class='ng-dropdown-panel-items scroll-host']//div[@role='option']" + ")" + "[" + str(j + 1) + "]"
        Inline_clk_option = driver.find_element_by_xpath(Inline_all_clks)
        Inline_clk_options = Inline_clk_option.text

        print('Followed View is  ', Inline_clk_options)

        clk_inline = Inline_clk_option.click()
        time.sleep(2)
        Legends_data = driver.find_element_by_xpath("(//*[@class='legend-labels'])[3]")
        print("Legends data for (" + str(Inline_clk_options) + ")", Legends_data.text)
        Expcted_legend_QP = "CW QP($M)"
        Expected_legend_SS = ['Won', 'Conditional Agreement', 'Qualified', 'Validated']

        if Inline_clk_options == "QP":
            if Legends_data.text != Expcted_legend_QP:
                print("Legends data for (" + str(Legends_data.text) + ") is NOT matching with (" + str(Expcted_legend_QP) + ")")
                assert False

        elif Inline_clk_options == "Sales Stage":
            if Legends_data.text.split("\n") != Expected_legend_SS:
                print("Legends data for (" + str(Legends_data.text) + ") is NOT matching with (" + str(Expected_legend_SS) + ")")
                assert False
        Header_inline_txt = driver.find_element_by_xpath(locators.Graph_header_3)
        Header_inline_txts = Header_inline_txt.text
        Header_inline_txt = Header_inline_txt.text.split("-")
        Header_inline_txt = Header_inline_txt[1]
        Header_inline_txt = str.strip(str(Header_inline_txt))
        print('Inline click header is ', Header_inline_txt)

        if (Inline_clk_options == Header_inline_txt):
            print("Inline filters are  in sync with Headers and result is passed")
            assert True
        else:
            print("Inline filters are  not in sync with Header and the result is Failed")
            assert False

        # assert Header_inline_txt != Inline_all_clks, "Inline filter is not comparable to the Graphs header"
        # driver.find_element_by_xpath("//div[@class='dropDownPosition ng-star-inserted']").click()
        time.sleep(2)

        Expand_graph = driver.find_element_by_xpath(locators.Expand_graph_3)
        Expand_graph.click()
        Exapnd_graph_header = driver.find_element_by_xpath(locators.Expand_Graph_header)
        Exapnd_graph_header = Exapnd_graph_header.text

        if (Header_inline_txts == Exapnd_graph_header):

            print("Default Graph header is equal to expand graph header and result is True \n")
            assert True

        else:
            print("Default graph header is not equal to expand graph header and result is false \n")
            assert False

        action = ActionChains(driver)
        Show_table = driver.find_element_by_xpath(locators.Show_tble_bpoi)
        action.move_to_element(Show_table).perform()
        time.sleep(2)
        Show_table.click()
        time.sleep(5)
        val = driver.find_element_by_xpath(locators.firstrow).text
        #     print(val)
        assert type(val) == str, "No Values"
        assert Show_table.click() != True, "Data table is not clickable and Result is failed"

        Hide_Table = driver.find_element_by_xpath(locators.Show_tble_bpoi)
        Hide_Table.click()

        # assert Hide_Table.click()!= True , "Hide Table is not able to click and result is failed"
        time.sleep(5)
        minimize = driver.find_element_by_xpath(locators.Expand_minimize)
        minimize = minimize.click()
        time.sleep(2)
        BPOI_VP_KPI_clicks()
        BPOI_KPI_QP_Deal_List()
        BPOI_KPI_Won_Deal_List()

def Inline_loop_Graphs_4():
    driver.find_element_by_xpath(locators.Inline_filter_option_clk_4).click()
    Inline_filters_clk = driver.find_elements_by_xpath(locators.Inline_filter_options)
    driver.find_element_by_xpath(locators.Inline_arrow_graph_4).click()
    print('lenght of inline filters is', len(Inline_filters_clk))

    found = True
    for j in range(len(Inline_filters_clk)):

        time.sleep(2)
        driver.find_element_by_xpath(locators.Inline_filter_option_clk_4).click()
        # Inline = driver.find_element_by_xpath("(" + "//div[@class='ng-dropdown-panel-items scroll-host']//div[@role='option']" + ")" + "[" + str(j + 1) + "]")
        Inline_all_clks = "(" + "//div[@class='ng-dropdown-panel-items scroll-host']//div[@role='option']" + ")" + "[" + str(j + 1) + "]"
        Inline_clk_option = driver.find_element_by_xpath(Inline_all_clks)
        Inline_clk_options = Inline_clk_option.text

        print('Followed View is  ', Inline_clk_options)
        clk_inline = Inline_clk_option.click()
        time.sleep(2)
        Legends_data = driver.find_element_by_xpath("(//*[@class='legend-labels'])[4]")
        print("Legends data for (" + str(Inline_clk_options) + ")", Legends_data.text)
        Expcted_legend_QP = "CW QP($M)"
        Expected_legend_SS = ['Won', 'Conditional Agreement', 'Qualified', 'Validated']

        if Inline_clk_options == "QP":
            if Legends_data.text != Expcted_legend_QP:
                print("Legends data for (" + str(Legends_data.text) + ") is NOT matching with (" + str(Expcted_legend_QP) + ")")
                assert False

        elif Inline_clk_options == "Sales Stage":
            if Legends_data.text.split("\n") != Expected_legend_SS:
                print("Legends data for (" + str(Legends_data.text) + ") is NOT matching with (" + str(Expected_legend_SS) + ")")
                assert False
        Header_inline_txt = driver.find_element_by_xpath(locators.Header_4)
        Header_inline_txts = Header_inline_txt.text
        Header_inline_txt = Header_inline_txt.text.split("-")
        Header_inline_txt = Header_inline_txt[1]
        Header_inline_txt = str.strip(str(Header_inline_txt))
        print('Inline click header is ', Header_inline_txt)

        if (Inline_clk_options == Header_inline_txt):
            print("Inline filters are  in sync with Headers and result is passed ")
            assert True
        else:
            print("Inline filters are  not in sync with Header and the result is Failed")
            assert False

        # assert Header_inline_txt != Inline_all_clks, "Inline filter is not comparable to the Graphs header"
        # driver.find_element_by_xpath("//div[@class='dropDownPosition ng-star-inserted']").click()
        time.sleep(2)

        Expand_graph = driver.find_element_by_xpath(locators.Expand_Graph_4)
        Expand_graph.click()
        Exapnd_graph_header = driver.find_element_by_xpath(locators.Expand_graph_header_4)
        Exapnd_graph_header = Exapnd_graph_header.text

        if (Header_inline_txts == Exapnd_graph_header):

            print("Default Graph header is equal to expand graph header and result is True \n")
            assert True

        else:
            print("Default graph header is not equal to expand graph header and result is false \n")
            assert False

        action = ActionChains(driver)
        Show_table = driver.find_element_by_xpath(locators.Show_tble_bpoi)
        action.move_to_element(Show_table).perform()
        time.sleep(2)
        Show_table.click()
        time.sleep(5)
        val = driver.find_element_by_xpath(locators.firstrow).text
        #     print(val)
        assert type(val) == str, "No Values"
        assert Show_table.click() != True, "Data table is not clickable and Result is failed"

        Hide_Table = driver.find_element_by_xpath(locators.Show_tble_bpoi)
        Hide_Table.click()

        # assert Hide_Table.click()!= True , "Hide Table is not able to click and result is failed"
        time.sleep(5)
        minimize = driver.find_element_by_xpath(locators.Expand_minimize)
        minimize = minimize.click()
        time.sleep(2)

def BPOI_Globalfilters():
    print("---------------- To Test Global filters for all Inline Graphs selections-----------------------------\n")
    filter_clk = driver.find_element_by_xpath(locators.filter_icon)
    filter_clk.click()
    time.sleep(4)
    View_clk = driver.find_element_by_xpath(locators.View_GF)
    print('View is ', View_clk.text)
    time.sleep(2)
    View_clk.click()
    View_clk.click()
    Reset_btn_clk = driver.find_element_by_xpath(locators.Reset_Default)

    if(Reset_btn_clk.is_enabled()):
        Reset_btn_clk.click()
        assert Reset_btn_clk!= True, "Reset button is not clickable and result is Failed"
        time.sleep(2)
    else:
        print("Global filter button is opened ")

    time.sleep(2)

    Filter_close = driver.find_element_by_xpath(locators.filter_icon_close)
    Filter_close.click()

    Headers_default = driver.find_elements_by_xpath(locators.Graph_headers)
    print('length of headers is' , len(Headers_default))

    label_list1 = []
    for i in range(len(Headers_default)):
        label_headers = driver.find_element_by_xpath("(" + "//h4[@class='text-center title']" + ")" + "[" + str(i + 1) + "]")
        assert len(label_headers.text) != 1, "Graphs are not loading and result is fail"
        Label_options = label_headers.text
        print(label_headers.text)
        Lables_final = label_list1.append(Label_options)
        time.sleep(2)
    print(label_list1)
    time.sleep(3)
    filter_clk.click()
    time.sleep(4)
    Page_specific = driver.find_element_by_xpath(locators.Page_specific_arrow)
    Page_specific.click()
    time.sleep(2)
    Page_specific.click()
    View_clk = driver.find_element_by_xpath(locators.View_GF)
    View_clk.click()
    BPOI_relatedgraphs()
    time.sleep(2)
    filter_clk.click()
    driver.find_element_by_xpath(locators.Page_specific_arrow).click()
    time.sleep(2)
    Reset_btn_clk = driver.find_element_by_xpath(locators.Reset_Default)
    driver.find_element_by_xpath(locators.Page_specific_arrow).click()
    Reset_btn_clk.click()
    time.sleep(4)
    label_list2 = []
    for i in range(len(Headers_default)):
        label_headers = driver.find_element_by_xpath("(" + "//h4[@class='text-center title']" + ")" + "[" + str(i + 1) + "]")
        assert len(label_headers.text) != 1, "Graphs are not loading and result is fail"
        Label_options = label_headers.text
        print(label_headers.text)
        Lables_final = label_list2.append(Label_options)

        time.sleep(2)
    print(label_list2)
    time.sleep(3)
    Filter_close = driver.find_element_by_xpath(locators.filter_icon_close)
    Filter_close.click()
    if(label_list1==label_list2):
        print("\n Summary to BPOI and BPOI to summary reset of headers is working as expected and result is Passed\n")
        assert  True
    else:
        print("\n Summary to BPOI and BPOI to summary reset of headers text is not valid and result is Failed\n")
        assert False


def opportunity_iden_group():
    View_default = driver.find_element_by_xpath(locators.View_GF)
    print('Default view is', View_default.text)
    Default_opp_iden_view = driver.find_element_by_xpath(locators.Opp_iden_label)
    # print(Default_opp_iden_view.text)
    opp_iden_txt = driver.find_element_by_xpath(locators.opp_iden_txt)
    opp_iden_text = opp_iden_txt.text

    if (View_default.text=="SUMMARY"):

        assert Default_opp_iden_view!=True, "Summary view doesnot contain Opp_identifier group view filter and result is failed"
    else:
        print("For Default view=summary Opp identifier Group view filter is not visible and Result is Failed")

def BPOI_GF_views_reset():

    print("--------------------------To check Reset to default option is clickable for the views seection ------------------------\n")
    filter_clk = driver.find_element_by_xpath("//*[@class='new-filter-icon']")
    filter_clk.click()
    time.sleep(2)
    Page_specific = driver.find_element_by_xpath(locators.Page_specific_arrow)
    Page_specific.click()
    time.sleep(2)
    Page_specific.click()
    Filter_global_txt = driver.find_element_by_xpath("(//span[text()='Global (Common) Filters'])[2]")
    View_default = driver.find_element_by_xpath(locators.View_GF)
    print('Default view is', View_default.text)
    View_default.click()
    driver.find_element_by_xpath(locators.View_arrow_clk).click()
    Default_opp_iden_view = driver.find_element_by_xpath(locators.Opp_iden_label)

    opp_iden_txt = driver.find_element_by_xpath(locators.opp_iden_txt)
    opp_iden_text = opp_iden_txt.text

    Reset_btn_clk = driver.find_element_by_xpath(locators.Reset_Default)

    if (Reset_btn_clk.is_enabled()):
        Reset_btn_clk.click()
        assert Reset_btn_clk != True, "Reset button is not clickable and result is Failed"
        time.sleep(2)
    else:
        print("Global filter button is opened ")

    time.sleep(2)


def BPOI_view_reset_bp():
    print("---------------------------To test opportunity identifier group filter after resetting of BPOI view--------------------------------------------")
    # BPOI_GF_views_reset()

    Opp_identifier_check = driver.find_element_by_xpath(locators.opp_iden_txt)
    Opp_identifier_check.click()
    Opp_iden_clk= driver.find_elements_by_xpath(locators.view_Scroll_host)
    driver.find_element_by_xpath(locators.Opp_ident_arrow_clk).click()
    print(len(Opp_iden_clk))
    for i in range(2,3):
        driver.find_element_by_xpath(locators.opp_iden_txt).click()

        clk_Opp_views = "(" + "//div[@class='ng-dropdown-panel-items scroll-host']//div[@role='option']" + ")" + "[" + str(i+1) + "]"
        opp_views_clk = driver.find_element_by_xpath(clk_Opp_views)
        opp_views_clks = opp_views_clk.text
        print('Followed opp_identifier is  ', opp_views_clks)

        clk_opp_iden = opp_views_clk.click()
        driver.find_element_by_xpath(locators.Opp_ident_arrow_clk).click()
        BPOI_relatedgraphs()
        filter_clk = driver.find_element_by_xpath(locators.filter_icon)
        filter_clk.click()
        Reset_btn_clk = driver.find_element_by_xpath(locators.Reset_Default)
        driver.find_element_by_xpath(locators.Page_specific_arrow).click()
        time.sleep(2)
        driver.find_element_by_xpath(locators.Page_specific_arrow).click()
        if (Reset_btn_clk.is_enabled()):
            Reset_btn_clk.click()
            assert True

        else:
            print("Reset to default button is not enabled and result is failed")
            assert False

        opp_iden_txt = driver.find_element_by_xpath(locators.Opp_iden_label)

        if(opp_iden_txt.is_displayed()):
            print("For Default view=summary Opp identifier Group view filter is  visible and Result is True" + str(opp_iden_txt.text))
            assert True
        else:
            print("For Default view=summary Opp identifier Group view filter is  not visible and Result is Failed" + str(opp_iden_txt.text))
            assert False

def barclicks():
    time.sleep(5)
    Barclick = driver.find_elements_by_xpath(locators.BPOI_bar_clks)
    print(len(Barclick))

    for i in range(len(Barclick)):
        barstr = "(" + "//*[@class='ng-tns-c69-5']//*[@class='bar my-classpointer myClass']" + ")" + "[" + str(i+1) + "]"
        allbars = driver.find_element_by_xpath(barstr)
        Summary_headers1 = driver.find_element_by_xpath(locators.Summary_headers)
        print(Summary_headers1.text)
        Summary_headers1 = Summary_headers1.text.split(" ")
        Summary_headers_result = Summary_headers1[0]
        print(Summary_headers_result)

        action = ActionChains(driver)
        action.move_to_element(allbars).perform()
        allbars.click()
        Bars_group_default = driver.find_element_by_xpath(locators.Bpoi_default_bar_clk)
        print(Bars_group_default.text)

        Bars_group_default = Bars_group_default.text.split(" ")
        Bars_group_default_result = Bars_group_default[1]
        print(Bars_group_default_result)
        time.sleep(1)

        # if(Bars_group_default=="By Sales Stage"):
        #     print("Graph bar clicks is relevant to the default view and the result is True:: ("+Summary_headers_result+") +" " + ("+Bars_group_default_result +") ")
        #     assert True
        # #
        # else:
        #     print("Graph bar clicks is not relevant to the default view and the result is Failed:: (" + Summary_headers_result + ") +" " + (" + Bars_group_default_result + ") ")
        #     assert False

        Close_icon = driver.find_element_by_xpath(locators.Bar_close_icon)
        Close_icon.click()

def Global_filter_BP_oppidentifer_option():
    print("------------------- To check VP and QP KPI values Opp identifer dropdown (BP) then changing views from summary to BPOI and Comparing KPI which should be Equal-------------")
    time.sleep(2)
    filter_clk = driver.find_element_by_xpath("//*[@class='new-filter-icon']")

    filter_clk.click()
    click_somehwere = driver.find_element_by_xpath(locators.Page_specific_arrow)
    click_somehwere.click()
    time.sleep(2)
    click_somehwere.click()
    time.sleep(2)
    View_clk = driver.find_element_by_xpath(locators.View_GF)
    View_clk.click()
    assert View_clk != "True", "View is unable to click and Result is failed"

    scroll_host = driver.find_element_by_xpath(locators.view_Scroll_host)
    scroll_host = scroll_host.text
    print(scroll_host)
    View_dpdwn = driver.find_element_by_xpath(locators.View_dropdown)

    View_dpdwn = View_dpdwn.click()

        # Filter_close = driver.find_element_by_xpath(locators.filter_icon_close)
        # Filter_close.click()
    Opp_identifier_check = driver.find_element_by_xpath(locators.opp_iden_txt)
    Opp_identifier_check.click()

    Opp_iden_clk = driver.find_elements_by_xpath(locators.view_Scroll_host)

    print(len(Opp_iden_clk))

    Bp_opp_clk = driver.find_element_by_xpath(locators.Opp_iden_BP_clk)
    Bp_opp_clk.click()
    driver.find_element_by_xpath(locators.Opp_ident_arrow_clk).click()
    time.sleep(3)

    driver.find_element_by_xpath(locators.View_arrow_clk).click()
    # View_clk.click()


    view_option_bpoi = driver.find_element_by_xpath(locators.opp_ident_option_1)
    view_option_bpoi.click()
    time.sleep(2)

    driver.find_element_by_xpath(locators.View_arrow_clk).click()
    Filter_close = driver.find_element_by_xpath(locators.filter_icon_close)
    Filter_close.click()

    # view_option_summary = driver.find_element_by_xpath(locators.opp_ident_option_1)


    # if (Reset_btn_clk.is_enabled()):
    #     Reset_btn_clk.click()
    #     assert Reset_btn_clk != True, "Reset button is not clickable and result is Failed"
    #     time.sleep(2)
    # else:
    #     print("Global filter button is opened ")
    # time.sleep(4)

def Vp_comparision_BP_vs_BPOI():
    # Filter_close = driver.find_element_by_xpath("(//carbon-icon[@name='close'])[2]")
    time.sleep(2)
    filter_clk = driver.find_element_by_xpath("//*[@class='new-filter-icon']")

    filter_clk.click()
    click_somehwere = driver.find_element_by_xpath(locators.Page_specific_arrow)
    click_somehwere.click()
    time.sleep(2)
    click_somehwere.click()
    time.sleep(2)

    View_clk = driver.find_element_by_xpath(locators.View_GF)
    View_clk.click()
    assert View_clk != "True", "View is unable to click and Result is failed"

    scroll_host = driver.find_element_by_xpath(locators.view_Scroll_host)
    scroll_host = scroll_host.text
    print(scroll_host)
    View_dpdwn = driver.find_element_by_xpath(locators.View_dropdown)


    View_dpdwn = View_dpdwn.click()

    Filter_close = driver.find_element_by_xpath(locators.filter_icon_close)


    Opp_identifier_check = driver.find_element_by_xpath(locators.opp_iden_txt)
    Opp_identifier_check.click()

    Opp_iden_clk = driver.find_elements_by_xpath(locators.view_Scroll_host)

    print(len(Opp_iden_clk))

    Bp_opp_clk = driver.find_element_by_xpath(locators.Opp_iden_BP_clk)
    Bp_opp_clk.click()
    driver.find_element_by_xpath(locators.Opp_ident_arrow_clk).click()
    time.sleep(3)
    Filter_close.click()

    # driver.find_element_by_xpath(locators.View_arrow_clk).click()
    # View_clk.click()


    # view_option_bpoi = driver.find_element_by_xpath(locators.opp_ident_option_1)
    # view_option_bpoi.click()
    # time.sleep(2)

    # driver.find_element_by_xpath(locators.View_arrow_clk).click()

    # add = []
    # Vp_text = driver.find_element_by_xpath(locators.Vp_KPI_txt)
    VP_bp_tiles_check = driver.find_element_by_xpath(locators.Vp_KPI_val_BPOI)
    QP_bp_tiles_check = driver.find_element_by_xpath(locators.Qp_KPI_val_BPOI)

    Vp_Deal_value_substr = VP_bp_tiles_check.text
    print("Vp text is " + str(Vp_Deal_value_substr))

    Vp_Deal_value_1 = VP_bp_tiles_check.text.replace(",", "")
    Vp_Deal_value_1 = re.findall(r'[0-9]+[.]?[0-9]', Vp_Deal_value_1)

    Vp_Deal_value_1 = Vp_Deal_value_1[0]
    print(Vp_Deal_value_1)

    Qp_Deal_value_substr = QP_bp_tiles_check.text
    print("Qp text is " + str(Qp_Deal_value_substr))

    Qp_Deal_value_1 = QP_bp_tiles_check.text.replace(",", "")
    Qp_Deal_value_1 = re.findall(r'[0-9]+[.]?[0-9]', Qp_Deal_value_1)
    Qp_Deal_value_1 = Qp_Deal_value_1[0]
    print(Qp_Deal_value_1)
    time.sleep(5)
    filter_clk = driver.find_element_by_xpath("//*[@class='new-filter-icon']")
    filter_clk.click()
    time.sleep(4)
    # click_somehwere = driver.find_element_by_xpath("(//carbon-icon[@name='icon--chevron--down'])[2]")
    click_somehwere.click()
    time.sleep(2)
    click_somehwere.click()
    Reset_btn_clk = driver.find_element_by_xpath(locators.Reset_Default)
    time.sleep(3)
    Reset_btn_clk.click()

    # BPOI_relatedgraphs()

    VP_bpoi_tiles_check = driver.find_element_by_xpath(locators.Vp_KPI_val_BPOI)
    QP_bpoi_tiles_check = driver.find_element_by_xpath(locators.Qp_KPI_val_BPOI)

    Vp_Deal_value_substr = VP_bpoi_tiles_check.text
    print("Vp BPOI text is " + str(Vp_Deal_value_substr))

    Vp_bpoi_Deal_value_1 = VP_bpoi_tiles_check.text.replace(",", "")
    Vp_bpoi_Deal_value_1 = re.findall(r'[0-9]+[.]?[0-9]', Vp_bpoi_Deal_value_1)
    Vp_bpoi_Deal_value_1 = Vp_bpoi_Deal_value_1[0]
    print(Vp_bpoi_Deal_value_1)

    Qp_bpoi_Deal_value_substr = QP_bpoi_tiles_check.text
    print("Qp BPOI text is " + str(Qp_bpoi_Deal_value_substr))

    Qp_bpoi_Deal_value_1 = QP_bpoi_tiles_check.text.replace(",", "")
    Qp_bpoi_Deal_value_1 = re.findall(r'[0-9]+[.]?[0-9]', Qp_bpoi_Deal_value_1)
    Qp_bpoi_Deal_value_1 = Qp_bpoi_Deal_value_1[0]
    print(Qp_bpoi_Deal_value_1)
    Filter_close.click()
    time.sleep(3)
    if(Vp_Deal_value_1==Vp_bpoi_Deal_value_1 and Qp_Deal_value_1==Qp_bpoi_Deal_value_1):
        print("Vp value for "+str(Vp_Deal_value_1)+" and vp BPOI value "+str(Vp_bpoi_Deal_value_1)+"  and Qp bp value "+str(Qp_Deal_value_1)+" and Qp BPOI value "+str(Qp_bpoi_Deal_value_1)+" is matching and result is passed")
        assert True

    else:
        print("Vp value for " + str(Vp_Deal_value_1) + " and vp BPOI value " + str(Vp_bpoi_Deal_value_1) + "  and Qp bp value " + str(Qp_Deal_value_1) + " and Qp BPOI value " + str(Qp_bpoi_Deal_value_1) + " is not matching and result is Failed")
        assert False

    time.sleep(5)

def Reset_Bpoi():
    Filter_close = driver.find_element_by_xpath(locators.filter_icon_close)
    Filter_close.click()
    time.sleep(2)
    filter_clk = driver.find_element_by_xpath("//*[@class='new-filter-icon']")
    filter_clk.click()
    time.sleep(4)
    click_somehwere = driver.find_element_by_xpath(locators.Page_specific_arrow)
    click_somehwere.click()
    time.sleep(2)
    Reset_btn_clk = driver.find_element_by_xpath(locators.Reset_Default)
    time.sleep(3)
    Reset_btn_clk.click()
    time.sleep(2)
    Filter_close = driver.find_element_by_xpath(locators.filter_icon_close)
    Filter_close.click()

# def BPOI_loop_view(): #lopping accross views opts and coming back to summary view. Checking with KPI's, failing for Dealsize,Channel Budget graph1 not mathcing as 0,for INDUSTRY SOLUTIONS - Budget and VP not matching as 0
#     bp_res = ""
#     vpqp_res=""
#     vpG4_res=""
#     bpoi=""
#     driver.find_element_by_xpath(locators.filter_icon).click()
#     driver.find_element_by_xpath(locators.sp_view).click()
#     lb=driver.find_elements_by_xpath(locators.sp_view_count)
#     len(lb)
#     driver.find_element_by_xpath(locators.filter_icon_close).click()
#     time.sleep(10)
#     for i in range(len(lb)):
#         driver.find_element_by_xpath(locators.sp).click()
#         driver.find_element_by_xpath(locators.filter_icon).click()
#         driver.find_element_by_xpath(locators.sp_view).click()
#         option=driver.find_element_by_xpath('(' + locators.sp_view_opt + ')' + "[" + str(i + 1) + "]").text
#         print("View: "+option)
#         driver.find_element_by_xpath('(' + locators.sp_view_opt_clk + ')'+"["+str(i+1)+"]").click()
#         driver.find_element_by_xpath(locators.filter_icon_close).click()
#         time.sleep(5)
#         Common.Graphs()
#         kpi = SP_Page.SP_KPI()
#         if option!="BPOI":
#             bp=SP_Page.Budget_PPV()
#             # print(kpi[0])
#             # print(kpi[1])
#             # print(bp[0][0])
#             # print(bp[1][0])
#             if (kpi[0]!=bp[0][0]) or (kpi[1]!=bp[1][0]):
#                 bp_res="Budget or PPV not matching for Graph1"
#                 print(bp_res)
#             # SP_KPI()
#             vpqp=SP_Page.VP_QP()
#             # print(kpi[4])
#             # print(vpqp[0])
#             # print(kpi[5])
#             # print(vpqp[1])
#             if (kpi[4]!=vpqp[0]) or (kpi[5]!=vpqp[1]):
#                 vpqp_res="VP Graph2 or QP Graph3 not matching"
#                 print(vpqp_res)
#             # SP_KPI()
#             vpG4=SP_Page.VP_graph4()
#             # print(kpi[4])
#             # print(vpG4[0])
#             if kpi[4]!=vpG4[0]:
#                 vpG4_res="VP not matching for Graph4"
#                 print(vpG4_res)
#         else:
#             vp = BPOI_VP()
#             # print(kpi[0])
#             print('KPI data is' , kpi[4])
#             # print(bp[0][0])
#             # print(bp[1][0])
#             if (kpi[4] != round(vp[0])):
#                 bpoi = "BPOI_VP not matching for Graph"
#                 print(bpoi)
#             if (kpi[4] != round(vp[1])):
#                 bpoi = "BPOI_VP not matching for Graph"
#                 print(bpoi)
#             if (kpi[4] != round(vp[2])):
#                 bpoi = "BPOI_VP not matching for Graph"
#                 print(bpoi)
#             if (kpi[4] != round(vp[3])):
#                 bpoi = "BPOI_VP not matching for Graph"
#                 print(bpoi)
#             # print("At present Not checking for the view : BPOI")
#             pass
#
#     driver.find_element_by_xpath(locators.filter_icon).click()
#     driver.find_element_by_xpath(locators.sp_view).click()
#     driver.find_element_by_xpath('(' + locators.sp_view_sum_clck + ')' + "[" + str(1) + "]").click()
#     driver.find_element_by_xpath(locators.filter_icon_close).click()
#     time.sleep(5)
#     print(bp_res, vpqp_res, vpG4_res, bpoi)
#     return bp_res, vpqp_res, vpG4_res, bpoi
#             # SP_KPI()
#     #     time.sleep(5)
#     #     print(driver.find_element_by_xpath("(//*[@class='ng-value-label ng-star-inserted'])[3]").text) # after clicking get the text


def BPOI_loop_view(): #lopping accross views opts and coming back to summary view. Checking with KPI's, failing for Dealsize,Channel Budget graph1 not mathcing as 0,for INDUSTRY SOLUTIONS - Budget and VP not matching as 0
    bp_res = ""
    vpqp_res=""
    vpG4_res=""
    bpoi=""
    driver.find_element_by_xpath(locators.filter_icon).click()
    driver.find_element_by_xpath(locators.sp_view).click()
    lb=driver.find_elements_by_xpath(locators.sp_view_count)
    len(lb)
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    time.sleep(10)
    for i in range(len(lb)):
        driver.find_element_by_xpath(locators.sp).click()
        driver.find_element_by_xpath(locators.filter_icon).click()
        driver.find_element_by_xpath(locators.sp_view).click()
        option=driver.find_element_by_xpath('(' + locators.sp_view_opt + ')' + "[" + str(i + 1) + "]").text
        print("View: "+option)
        driver.find_element_by_xpath('(' + locators.sp_view_opt_clk + ')'+"["+str(i+1)+"]").click()
        driver.find_element_by_xpath(locators.filter_icon_close).click()
        if option!="BPOI" and option!="JTC/RHS" and option!="JTC" and option!="RHS":
            time.sleep(5)
            Common.Graphs1()
            kpi = SP_Page.SP_KPI()
            bp=SP_Page.Budget_PPV()
            if (kpi[1]!=bp[1][0]):
                bp_res="PPV not matching for Graph1"
                print(bp_res)
            vpqp=SP_Page.VP_QP()
            if (kpi[4]!=vpqp[0]) or (kpi[5]!=vpqp[1]):
                vpqp_res="VP Graph2 or QP Graph3 not matching"
                print(vpqp_res)
            vpG4=SP_Page.VP_graph4()
            if kpi[4]!=vpG4[0]:
                vpG4_res="VP not matching for Graph4"
                print(vpG4_res)
        elif option=="JTC/RHS":
            time.sleep(5)
            Common.Graphs1()
        elif option=="JTC" or option=="RHS":
            time.sleep(5)
            Common.Graphs1()
        else:
            vp = BPOI_VP()
            kpi = SP_Page.SP_KPI()
            # print(kpi[0])
            print('KPI data is' , kpi[4])
            # print(bp[0][0])
            # print(bp[1][0])
            if (kpi[4] != round(vp[0])):
                bpoi = "BPOI_VP not matching for Graph"
                print(bpoi)
            if (kpi[4] != round(vp[1])):
                bpoi = "BPOI_VP not matching for Graph"
                print(bpoi)
            if (kpi[4] != round(vp[2])):
                bpoi = "BPOI_VP not matching for Graph"
                print(bpoi)
            if (kpi[4] != round(vp[3])):
                bpoi = "BPOI_VP not matching for Graph"
                print(bpoi)
            # print("At present Not checking for the view : BPOI")
            pass

    driver.find_element_by_xpath(locators.filter_icon).click()
    driver.find_element_by_xpath(locators.sp_view).click()
    driver.find_element_by_xpath('(' + locators.sp_view_sum_clck + ')' + "[" + str(1) + "]").click()
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    time.sleep(5)
    print(bp_res, vpqp_res, vpG4_res, bpoi)
    return bp_res, vpqp_res, vpG4_res, bpoi



def BPOI_VP():
    # B = []
    time.sleep(5)
    V = []
    for j in range(4):
        driver.find_element_by_xpath(locators.max1 + '[' + str(j + 1) + ']').click()
        driver.find_element_by_xpath(locators.sp_showhide).click()
        tx = driver.find_elements_by_xpath(locators.firstrow) # gives the total number of Rows in the table
        # print(len(tx))
        t = 0
        t2 = 0
        for i in range(len(tx)):
            tx = driver.find_element_by_xpath('(' + locators.firstrow + ')' + '[' + str(i + 1) + ']').text
            tx = tx.split('\n')
            tx1 = tx[1].replace(",", "")
            tx1 = float(tx1) if tx1 != "N/A" else 0  #Inline if Function
            t = t + tx1
            # tx2 = tx[3].replace(",", "")
            # tx2 = float(tx2) if tx2 != "N/A" else 0
            # t2 = t2 + tx2
        #     print("Budget Graph"+str(j+1)+" : "+str(t)) # give values in list
        print("Sum VP Graph_" + str(j + 1) + " : " + str(t))
        V.append(round(t))
        #     print("PPV Graph"+str(j+1)+" : "+str(t2)) # give values in list
        # print("Sum PPV Graph_" + str(j + 1) + " : " + str(t2))
        # P.append(round(t2))
        driver.find_element_by_xpath(locators.sp_showhide).click()
        driver.find_element_by_xpath(locators.min1).click()
    print(V)
    return V




# #
# Login_Page.open_ISD()
# SP_Page.Segmented_tab()
# # # SPtop_nav_IPE()
# # RD_Page.Roadmap()
# # RMtop_nav_IPE()
# time.sleep(5)
# KD_Page.Deal_mangmnt()
# time.sleep(2)
# KD_Page.KD_tab_Click()
# kdtop_nav_IPE()
# MI_Page.MI_tab_Click()
# Mitop_nav_IPE()

# Common.Graphs()
# BPOI_loop_view()
# SPtop_nav_IPE()
# SP_Page.Segmented_bc()
# Graphs_headers()
# BPOI_Seg_summary_Default()
# BPOI_seg_views()
# BPOI_relatedgraphs()
# BPOI_inlinefilters()
# BPOI_Expand_graphs()
# BPOI_Inlinefilters_loop_click()
# Inline_loop_Graphs_2()
# Inline_loop_Graphs_3()
# Inline_loop_Graphs_4()
# BPOI_Globalfilters()
# BPOI_GF_views_reset()
# BPOI_view_reset_bp()
# barclicks()
# Global_filter_BP_oppidentifer_option()
# Vp_comparision_BP_vs_BPOI()
# Reset_Bpoi()


