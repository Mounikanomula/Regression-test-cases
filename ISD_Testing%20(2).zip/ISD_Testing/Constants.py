
geo_List = ['Americas', 'EMEA', 'Japan', 'APAC']
geo_List1 = ['Americas', 'EMEA', 'Japan', 'APAC', 'UNASSIGNED', 'INVALID']
geo_List2 = ['Americas', 'EMEA', 'Japan', 'APAC']
geo_List3 = ['North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Gr...', 'Latin America', 'Middle East & Af...', 'UNASSIGNED']
bU_List = ['Systems Hardware', 'Systems Software', 'C&DP', 'Security', 'Acoustic', 'WCE Supply Chain', 'WCE Mkt&Comm Legacy', 'Collaboration Solns', 'Talent Solns', 'Watson Health', 'Watson IoT', 'Watson Education', 'Wtsn Media & Weather', 'Indus Platforms Unit']
bU_List_UT = ['Cloud & Data Pla...', 'Systems w/TPS', 'Security', 'Cognitive Applic...', 'Watson Health', 'Industry Platfor...']
AP_Track_ChartTitles = ['QP TRACK', 'CP TRACK', 'WON TRACK']
AP_Track_Legend = ['QP ($M)', 'CP ($M)', 'WON ($M)']
SP_SI_ChartTitles = ["STRATEGIC IMPERATIVES - Cov%","STRATEGIC IMPERATIVES - VP as % of Total VP","STRATEGIC IMPERATIVES - VP","STRATEGIC IMPERATIVES - QP"]
SP_SI_ChartTitlesPPV = ["STRATEGIC IMPERATIVES - PPV","STRATEGIC IMPERATIVES - VP as % of Total VP","STRATEGIC IMPERATIVES - VP","STRATEGIC IMPERATIVES - QP"]
SP_SI_KPI_Labels = ["BUDGET","PPV","COV%","B/(W) OBJ","VP","VP Penetration of Total VP %","WON (Pipeline)"]
SP_IndSol_KPI_Labels = ['BUDGET', 'PPV', 'COV%', 'B/(W) OBJ', 'VP', 'QP', 'WON (Pipeline)']
RM_Track_ChartTitles = ['WON(Roadmap) TRACK', 'SOLID TRACK', 'AT RISK TRACK', 'KEY STRETCH TRACK', 'STRETCH TRACK', 'SOLID+AT RISK TRACK', 'WSR+KS TRACK']
RM_Track_Legend = ['WON ($M)', 'SOLID ($M)', 'AT RISK ($M)', 'KEY STRETCH ($M)', 'STRETCH ($M)', 'SOLID+AT RISK ($M)', 'WSR+KS ($M)']
KD_Modal_filter_Sliders = ['Value ($M)', 'Total Oppty Value ($M)', 'Completion %', 'Priced GP%']
KD_LongLists = ["Oppty No", "Opp Desc", "Detail Key", "LI STC", "OPPTY STC"]
#--------------------------------------- Constants for CnC Profiles -----------------------------------------------------------------------------------------------------------

geo_List_TopNav = ['All', 'Americas', 'EMEA', 'Japan', 'APAC', 'UNASSIGNED', 'INVALID']
bu_List_TopNav = ['All', 'Systems Hardware', 'Systems Software', 'C&DP', 'Security', 'Watson Health', 'Cognitive Apps', 'Indus Platforms Unit']
CloudnSecSign_DealSize_TopNav = ['All', '<$50K', '$50K - $100K', '$100K - $250K', '$250K - $500K', '$500K - $1M', '$1M - $5M', '$5M - $10M', '>$10M']
# CloudnSecSign_Lvl17_TopNav = ['All', 'Cloud Object Storage', 'GTS Security Svcs', 'IBM Cloud Infrastructure',
#                                 'Security', 'VMWare Services'], ['IBM C&DP', 'IBM Security']
CloudnSecSign_Lvl17_TopNav = ['All', 'GBS Security Svcs', 'GTS Security Svcs', 'Public Cloud IaaS', 'Security Transformation Services']
# lvl17_List=['Cloud Object Sto...', 'GBS Security Svc...', 'GTS Security Svc...', 'IBM Cloud Infras...', 'Security Transfo...', 'VMWare Services']
lvl17_List= [' Public Cloud Iaa... ',' Security Transfo... ']
# BU_Lvl10_All_TopNav = ['All', 'Cloud Platform', 'Data and AI', 'Integration C&DP', 'Security SW', 'Security Services', 'GHHS', 'Imaging', 'Life Sciences', 'Oncology & Genomics', 'Payer', 'Provider', 'Simpler', 'WH Platform', 'IBM Sterling', 'Open Marketplace', 'Talent Mgmnt Solns', 'Wat Media', 'Watson IoT', 'Weather', 'Industry Platform']
BU_Lvl10_All_TopNav = ['All', 'AI Applications', 'Blockchain Solutions', 'Cloud & Data Platform Top (AUO)', 'Core Industry Platforms', 'Data and AI', 'Integration', 'Public Cloud Platform', 'Red Hat', 'Red Hat Marketplace Operated by IBM', 'Security Services', 'Security Software', 'Talent Management Solutions', 'UNK - Cognitive Applications', 'Watson Health Unit', 'Watson Media', 'Weather']
# BU_lvl17_All_TopNav = ['All', 'AI Solutions & Apps Market', 'AI Tools & Runtimes Market', 'Acquisitions: Middleware', 'Blockchain', 'Blockchain Platform Market',
#                      'CAI Security', 'CAS Advise', 'CAS Build', 'CAS Manage', 'CAS Move', 'Cell', 'Cloud Data Services Segment', 'Cloud Dedicated',
#                      'Cloud Expert Services', 'Cloud Garage', 'Cloud Integration & Development Market', 'Cloud Integration Services Market',
#                      'Cloud Management & Platform Market', 'Cloud Object Storage', 'Cloud Premium Support', 'Cloud Public Segment', 'Cognitive Business Decision Support',
#                      'Cognitive Process Re-engineering', 'Cognitive Process Services', 'Cognitive Talent Management', 'Core Platforms', 'Data & AI Platform Market',
#                      'Data and AI Top Market', 'Developer Services Bundles on IBM Cloud', 'Digital Business Automation Market', 'Enterprise Asset Management - IoT',
#                      'Enterprise Video Platform', 'Facilities Management - IoT', 'GBS Digital Strategy', 'Government Portfolio', 'Hybrid Cloud Integration Top',
#                      'Hybrid Data Management Market', 'IBM BladeCenter', 'IBM Cloud infrastructure', 'IBM Logo Services', 'IBM Z', 'Industrial IoT Platform',
#                      'IoT Top Market - not for Sellers', 'Multicloud Services', 'Multiscreen Video Technology', 'Multivendor Services', 'Next Gen EA & Mobile',
#                      'Oncology and Genomics', 'Payer Portfolio', 'Power System i/p', 'Promontory Financial Services', 'Provider Portfolio', 'PureFlex & Flex System',
#                      'SW Storage', 'SYSTEM Z', 'Sec Resilient', 'Security Digital Trust', 'Security Software Top Market', 'Security Threat Management',
#                      'Security Transformation Services', 'Simpler Services', 'Software and Systems Engineering - IoT', 'Storage Hardware', 'Traditional Services',
#                      'Unified Governance & Integration Market', 'VMWare Services', 'WFSS Other', 'Watson Content Market', 'Watson Foundation for Health',
#                      'Watson Health Imaging', 'Watson Health Solutions Life Sciences', 'Watson Supply Chain', 'Weather Solutions', 'iX']

BU_lvl17_All_TopNav = ['All', 'AI Applications Market', 'AI Applications Top Market (AUO)', 'AIX / IBM i Market', 'Application Development and Deployment', 'Application Platforms TPS', 'Asset Management', 'Blockchain', 'Blockchain Platform Market', 'CAI Security', 'CAI Security Top (AUO)', 'CAS Advise, Move & Build', 'CAS Manage', 'Cloud & Data Platform Top Market (AUO)', 'Cloud Application Innovation Top (AUO)', 'Cloud Integration & Development Market', 'Cloud Management Market', 'Cloud Platform Market', 'Cognitive Business Decision Support', 'Cognitive Infrastructure Market', 'Cognitive Process Re-engineering', 'Cognitive Process Services (BPO)', 'Cognitive Process Transformation Top (AUO)', 'Cognitive Talent Management', 'Core Industry Platforms Market', 'Data and AI Top Market (AUO)', 'Digital Business Automation Market', 'Enterprise Linux Market', 'Enterprise Strategy', 'Enterprise Strategy & iX Top (AUO)', 'Enterprise Video Platform', 'Facilities Management', 'Financial Services (PFG)', 'GBS Top Service Line Market (AUO)', 'GTS Multicloud Services', 'GTS Top Market (AUO)', 'Government Health and Human Services (GHHS)', 'Hybrid Cloud Integration Top Market (AUO)', 'IBM Logo Services', 'Imaging', 'Industrial IoT Platform', 'Information Architecture Market', 'Infrastructure', 'Life Sciences', 'Modern Data Protection Market', 'Multiscreen Video Technology', 'Multivendor Services', 'Next Generation Enterprise Applications', 'Oncology & Genomics', 'PaaS Foundation & aaS Offerings Market - Private Cloud', 'PaaS, Virtualization and Linux Foundation', 'Payer', 'Product Engineering', 'Provider', 'Public Cloud Consumption Market', 'Public Cloud IaaS', 'Public Cloud PaaS', 'Red Hat Marketplace', 'Red Hat Marketplace Top Market (AUO)', 'Red Hat Top Market (AUO)', 'Security Digital Trust', 'Security Software Top Market (AUO)', 'Security Threat Management', 'Security Transformation Services', 'Security Transformation Services', 'Storage Networking Market', 'Storage Operations / Services Market', 'Storage for AI & Big Data Market', 'Storage for Hybrid Multicloud Market', 'Storage for Z Systems Market', 'Supply Chain', 'System Software HW', 'System Software TPS', 'Systems Top Market (AUO)', 'The Weather Company Top Market (AUO)', 'Total System x Top Market (AUO)', 'Traditional Distributed External Storage Market', 'Traditional Services', 'Transformation Services', 'UNK - Cognitive Applications', 'UNK - Cognitive Systems', 'UNK - Data and AI', 'UNK - Integration', 'UNK - Mainframe HW', 'UNK - Storage', 'Watson Content Market', 'Watson Health Platform', 'Watson Media Solutions', 'Weather Business Solutions Market', 'Weather Solutions', 'iX', 'zTPS Operations / Services Market']

# BU_Lvl15_All_GraphAxis = ['AI Solutions & A...', 'AI Tools & Runti...', 'Blockchain Platf...', 'Cloud Data Servi...', 'Cloud Dedicated', 'Cloud Integratio...',
#                           'Cloud Management...', 'Cloud Premium Su...', 'Cloud Public Seg...', 'Cognitive Talent...', 'Data & AI Platfo...', 'Data and AI Top ...',
#                           'Digital Business...', 'Enterprise Asset...', 'Facilities Manag...', 'Government Portf...', 'Hybrid Cloud Int...', 'Hybrid Data Mana...',
#                           'Industrial IoT P...', 'IoT Top Market -...', 'Oncology and Gen...', 'Payer Portfolio', 'Promontory Finan...', 'Provider Portfol...',
#                           'Sec Resilient', 'Security Digital...', 'Security Threat ...', 'Software and Sys...', 'Unassigned', 'Unified Governan...', 'Watson Health Im...',
#                           'Watson Health So...', 'Watson Supply Ch...', 'Weather Solution...']

BU_Lvl15_All_GraphAxis = ['All', ' AI Applications ... ', ' Asset Management ', ' Blockchain Platf... ',
                          ' Cloud Integratio... ', ' Cloud Management... ', ' Cloud Platform M... ',
                          ' Cognitive Talent... ', ' Collaboration ', ' Core Industry Pl... ', ' Data and AI Top ... ',
                          ' Digital Business... ', ' Facilities Manag... ',
                          ' Government Healt... ', ' Hybrid Cloud Int... ', ' Imaging ', ' Industrial IoT P... ',
                          ' Information Arch... ', ' IoT Top Market ', ' Life Sciences ',
                          ' Oncology & Genom... ', ' Open Marketplace... ', ' Payer ', ' Product Engineer... ',
                          ' Provider ', ' Public Cloud Paa... ', ' Security Digital... ',
                          ' Security Softwar... ', ' Security Threat ... ', ' Supply Chain Sui... ',
                          ' Watson Media Sol... ', ' Weather Business... ', ' Weather Solution... ']

CnC_SW_AllBU_TopNav = ['All', 'Systems w/TPS', 'Cloud & Data Platform', 'Security', 'Watson Health', 'Cognitive Applications', 'Industry Platforms']
CnC_CogApp_AllBU_TopNav = ['All', 'Cognitive Apps']
CnC_CDPSecCogAppsBUTopNav = ['All', 'Cloud DB Svcs', 'Cloud Dev Svc', 'Cloud Infrastru Svcs', 'Cloud Public', 'Data and AI', 'Integration C&DP', 'Security SW', 'Security Services',
                     'Talent Mgmnt Solns', 'WCE Supply Chain', 'Wat Media', 'Watson IoT', 'Weather']

#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
GIMD_Sector_list = ['Communications', 'Distribution', 'FSS: Insurance', 'FSS: NALASIA', 'FSS: US&E', 'Industrial', 'Public']
SP_SI_KPI_Labels_GIMD = ['PPV', 'PPV Penetration of Total PPV %', 'VP', 'VP Penetration of Total VP %', 'WON (Pipeline)', 'WON Penetration of Total WON %']

SP_SI_ChartTitles_Buyer = ["BUYER GROUP - VP", "BUYER GROUP - QP", "BUYER GROUP - Sales Stage"]
SP_SI_KPI_Labels_Buyer = ["VP","QP","WON (Pipeline)"]

SP_SI_KPI_Labels_NOBUDGET = ["PPV","PPV Penetration of Total PPV %","VP","VP Penetration of Total VP %","WON (Pipeline)", "WON Penetration of Total WON %"]
SP_SI_ChartTitles2 = ['STRATEGIC IMPERATIVES - PPV', 'STRATEGIC IMPERATIVES - VP as % of Total VP', 'STRATEGIC IMPERATIVES - VP', 'STRATEGIC IMPERATIVES - QP']
SP_SI_ChartTitlesPPV = ['STRATEGIC IMPERATIVES - PPV', 'STRATEGIC IMPERATIVES - VP as % of Total VP', 'STRATEGIC IMPERATIVES - VP', 'STRATEGIC IMPERATIVES - QP']

#-------------------------------------------------------------------------------------------------------------------------------
EBU_List = ['N/A', 'CA Commercial', 'CA E&C Quebec EBU', 'CA Entrp Atlantic & Ontar EBU', 'CA Entrp Caribbean North EBU', 'CA Entrp West EBU', 'CA IA - Air Canada', 'CA IA - Royal Bank of Canada', 'CA IA - ScotiaBank', 'CA IA - Toronto Dominion Bank', 'CA Industry - Communications', 'CA Industry - Federal', 'CA Industry - Financial Serv', 'CA Industry - Govt of Ontario', 'Canada Default']

EBU_List2 = ['CA Commercial', 'CA E&C Quebec EB...', 'CA Entrp Atlanti...', 'CA Entrp Caribbe...', 'CA Entrp West EB...', 'CA IA - Air Cana...', 'CA IA - Royal Ba...', 'CA IA - ScotiaBa...', 'CA IA - Toronto ...', 'CA Industry - Co...', 'CA Industry - Fe...', 'CA Industry - Fi...', 'CA Industry - Go...', 'Canada Default']

SP_SI_KPI_Labels1 =['PPV', 'PPV Penetration of Total PPV %', 'VP', 'VP Penetration of Total VP %', 'WON (Pipeline)', 'WON Penetration of Total WON %']

EBU_List3 = ['', 'CA Commercial', 'CA E&C Quebec EB...', 'CA Entrp Atlanti...', 'CA Entrp Caribbe...', 'CA Entrp West EB...', 'CA IA - Air Cana...', 'CA IA - Royal Ba...', 'CA IA - ScotiaBa...', 'CA IA - Toronto ...', 'CA Industry - Co...', 'CA Industry - Fe...', 'CA Industry - Fi...', 'CA Industry - Go...', 'Canada Default']

#############CX################

Cx_Breadcrumb_geo = "Net Promoter Score / NPS / GEO VIEW /"
Cx_Breadcrumb_market= "Net Promoter Score / NPS / MARKET VIEW /"
Cx_KPI_Relat = ['NPS', 'PROMOTERS', 'PASSIVES', 'DETRACTORS', 'STRATEGIC PARTNERSHIP SHARE']
Cx_KPI_Sales= ['NPS', 'PROMOTERS', 'PASSIVES', 'DETRACTORS', 'REFERRAL SHARE']
Cx_deal_headers_Global= ['Customer Name', 'Geo', 'Likelihood to Recommend', 'Market', 'Client type', 'Client Sub Type', 'Link to Medallia']
CX_deal_header_survey_Global= ['Customer Name', 'Geo', 'Market', 'Likelihood to Recommend', 'Business Unit Group', 'Business Unit Sub Group', 'Client type', 'Client Sub Type', '']
Cx_deal_header_survery_uits= ['Customer Name', 'Geo', 'Market', 'Likelihood to Recommend', 'Business Unit Sub Group', 'Level 17', 'Client type', 'Client Sub Type', '']

Cx_Gf_Rel =['Survey Type :', 'Period :', 'View :', 'Geo :', 'Client Type :', 'Client Sub Type :']
CX_Gf_Sales= ['Period :', 'View :', 'Bu Subgroup :']