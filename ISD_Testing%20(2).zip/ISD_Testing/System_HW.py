from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
import re
from selenium.webdriver.common.action_chains import ActionChains
from datetime import date
from datetime import datetime
from datetime import timedelta
import locators
import Login_Page
import Common
import Constants
import RD_Page
import AP_Page
import SP_Page
import KD_Page
import RD_Page
import MI_Page

driver = Login_Page.driver

def EStop_nav():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle=driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    time.sleep(2)
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :"+str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-1):
        time.sleep(2)
        GH1[i].click()
        time.sleep(2)
        Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
        print(Topnav.text)
        listLegend1.append(Topnav.text)
        driver.find_element_by_xpath(locators.dropdown_wrapper2).click()
    # print(listLegend1)
    for i in listLegend1:
            listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    assert listLegend2==[['NQ'], ['All', '<$50K', '$50K - $100K', '$100K - $250K', '$250K - $500K', '$500K - $1M', '$1M - $5M', '$5M - $10M', '>$10M', 'UNASSIGNED'], ['All', 'Americas', 'EMEA', 'Japan', 'APAC', 'UNASSIGNED', 'INVALID'], ['All', 'Cognitive Systems', 'Mainframe HW', 'Mainframe TPS', 'Storage', 'Systems Top (AUO)'], ['Total Summary']],  "Not expected"
    return listLegend2

# Total Summary View Check
def TotalSummaryViewCheck():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEleTS = driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEleTS).perform()
    time.sleep(1)
    driver.find_element_by_xpath(locators.dropdown_wrapperViewType).click()
    time.sleep(1)
    driver.find_element_by_xpath(locators.totalSummarySelection).click()
    driver.find_element_by_xpath("//div[@class='filter-header']/span/carbon-icon[@name='close']").click()
    time.sleep(3)
    graph = Common.Graphs1()
    assert graph == ['GEO COV% (WSR)'], "ES Total Summary Graphs Missing"


# Transaction only check
def TransactionOnlyViewCheck():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEleTO = driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEleTO).perform()
    time.sleep(1)
    driver.find_element_by_xpath(locators.dropdown_wrapperViewType).click()
    time.sleep(1)
    driver.find_element_by_xpath(locators.transactionalOnlySelection).click()
    driver.find_element_by_xpath("//div[@class='filter-header']/span/carbon-icon[@name='close']").click()


# Aggregated Pipeline
def APtop_nav():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle=driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    time.sleep(2)
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :"+str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-2):
        time.sleep(2)
        GH1[i].click()
        time.sleep(2)
        Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
        print(Topnav.text)
        listLegend1.append(Topnav.text)
        driver.find_element_by_xpath(locators.dropdown_wrapper2).click()
    # print(listLegend1)
    for i in listLegend1:
            listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    assert listLegend2==[['NQ'], ['All', '<$50K', '$50K - $100K', '$100K - $250K', '$250K - $500K', '$500K - $1M', '$1M - $5M', '$5M - $10M', '>$10M', 'UNASSIGNED'], ['All', 'Americas', 'EMEA', 'Japan', 'APAC', 'UNASSIGNED', 'INVALID'], ['All', 'Cognitive Systems', 'Mainframe HW', 'Mainframe TPS', 'Storage', 'Systems Top (AUO)'], ['UNIT']],  "Not expected"
    return listLegend2

#segmented Pipeline

def SPtop_nav():
    time.sleep(2)
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle=driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    time.sleep(2)
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :"+str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)):
        time.sleep(2)
        GH1[i].click()#segPipe_KPI_Labels()
        time.sleep(2)
        Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
        print(Topnav.text)
        listLegend1.append(Topnav.text)
        driver.find_element_by_xpath(locators.dropdown_wrapper2).click()
    # print(listLegend1)
    for i in listLegend1:
            listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    assert listLegend2 ==  [['NQ'], ['All', '<$50K', '$50K - $100K', '$100K - $250K', '$250K - $500K', '$500K - $1M', '$1M - $5M', '$5M - $10M', '>$10M', 'UNASSIGNED'], ['All', 'Americas', 'EMEA', 'Japan', 'APAC', 'UNASSIGNED', 'INVALID'], ['All', 'Cognitive Systems', 'Mainframe HW', 'Mainframe TPS', 'Storage', 'Systems Top (AUO)'], ['CLIENT SET', 'DEAL SIZE', 'CHANNEL', 'JTC/RHS', 'JTC', 'RHS', 'SOLUTIONS - Strategic Imperatives', 'OI GROUP']], "Not expected"
    return listLegend2
#Roadmap
def RMtop_nav():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle = driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    # driver.find_element_by_xpath(locators.RMTab).click()
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :" + str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-4):
        time.sleep(2)
        GH1[i].click()
        time.sleep(2)
        Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
        print(Topnav.text)
        listLegend1.append(Topnav.text)
        driver.find_element_by_xpath(locators.dropdown_wrapper2).click()
    for i in listLegend1:
        listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    assert listLegend2==[['NQ'], ['All', '<$50K', '$50K - $100K', '$100K - $250K', '$250K - $500K', '$500K - $1M', '$1M - $5M', '$5M - $10M', '>$10M', 'UNASSIGNED'], ['All', 'Americas', 'EMEA', 'Japan', 'APAC', 'UNASSIGNED', 'INVALID'], ['All', 'Cognitive Systems', 'Mainframe HW', 'Mainframe TPS', 'Storage', 'Systems Top (AUO)'], ['LIO'], ['Total Summary'], ['BU SUBGROUP', 'CLIENT SEGMENT', 'DEAL SIZE', 'LOAD']],"not expected"
    return listLegend2


def RoadmapAllView():
    spview=driver.find_element_by_xpath(locators.filter_icon)
    time.sleep(5)
    spview.click()
    driver.find_element_by_xpath(locators.filter_icon)
    MoveEle = driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    element = "//*[@class='ng-dropdown-panel-items scroll-host']//div[@role='option']"
    time.sleep(5)
    arrow = driver.find_element_by_xpath(locators.bread_view)
    arrow.click()
    GH1 = driver.find_elements_by_xpath(element)
    print(type(GH1))
    print(len(GH1))
    list_GHOne = []
    for i in range(len(GH1)-1):
        abc = driver.find_element_by_xpath("("+element+")"+"["+str(i+1)+"]")
        list_GHOne.append(abc.text)
        print(abc.text)
        abc.click()
        time.sleep(2)
        RD_Page.RD_Graphs()
        time.sleep(2)
        arrow.click()
        time.sleep(2)
    print("Roadmap views"+str(list_GHOne))
    time.sleep(2)
    driver.find_element_by_xpath("(" + element + ")" + "[" + str(1) + "]").click()
    time.sleep(2)
    driver.find_element_by_xpath(locators.filter_icon_close).click()

def kdtop_nav():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle = driver.find_element_by_xpath(locators.MoveElementkd)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :" + str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-8):
        time.sleep(2)
        GH1[i].click()
        time.sleep(2)
        Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
        print(Topnav.text)
        listLegend1.append(Topnav.text)
        driver.find_element_by_xpath(locators.dropdown_wrapper2).click()
    for i in listLegend1:
        listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    time.sleep(5)
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    assert listLegend2 == [['NQ'], ['All', '<$50K', '$50K - $100K', '$100K - $250K', '$250K - $500K', '$500K - $1M', '$1M - $5M', '$5M - $10M', '>$10M', 'UNASSIGNED'], ['All', 'Americas', 'EMEA', 'Japan', 'APAC', 'UNASSIGNED', 'INVALID'], ['All', 'Cognitive Systems', 'Mainframe HW', 'Mainframe TPS', 'Storage', 'Systems Top (AUO)'], ['LIO'], ['CLIENT AGGREGATION', 'ALL LINE ITEMS'], ['By BU Sub group', 'By Level 17', 'By WSR', 'By Dealsize', 'By SAQ', 'By SAQ Quadrant', 'By Market', 'By Branch Group (EBR)', 'By Branch (EBU)', 'By Branch Unit (ESU)', 'By Client Type', 'By Client Sub Type', 'By Client Set', 'By Channel', 'By Reporting Country', 'By Roadmap Status', 'By Close/Bill Week', 'By Close/Bill Month', 'By OI Source', 'By ISU Group', 'By ISU', 'By Geo']],"not expected"
    return listLegend2

def Mitop_nav():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle = driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :" + str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-4):
        time.sleep(2)
        GH1[i].click()
        time.sleep(2)
        Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
        print(Topnav.text)
        listLegend1.append(Topnav.text)
        driver.find_element_by_xpath(locators.dropdown_wrapper2).click()
    for i in listLegend1:
        listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    time.sleep(3)
    driver.find_element_by_xpath(locators.common_GlobalFilterXicon).click()
    assert listLegend2 == [['NQ'], ['All', '<$50K', '$50K - $100K', '$100K - $250K', '$250K - $500K', '$500K - $1M', '$1M - $5M', '$5M - $10M', '>$10M', 'UNASSIGNED'], ['All', 'Americas', 'EMEA', 'Japan', 'APAC', 'UNASSIGNED', 'INVALID'], ['All', 'Cognitive Systems', 'Mainframe HW', 'Mainframe TPS', 'Storage', 'Systems Top (AUO)'], ['LIO'], ['ALL LINE ITEMS'], ['Identifying (1)', 'Validated (4)', 'Qualifying (7)', 'Gaining Agreement (6)']], "is not expected"
    return listLegend2


#
# Login_Page.open_ISD()
# # EStop_nav()
# time.sleep(2)
# # AP_Page.Aggregated()
# # APtop_nav()
# # time.sleep(2)
# # SP_Page.Segmented_tab()
# # SPtop_nav()
# time.sleep(5)
# RD_Page.Trans_pip()
# # RD_Page.Roadmap()
# # RMtop_nav()
# # KD_Page.KD_tab_Click()
# # kdtop_nav()
# MI_Page.MI_tab_Click()
# Mitop_nav()