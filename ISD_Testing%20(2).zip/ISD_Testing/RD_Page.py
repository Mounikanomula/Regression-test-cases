from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
import re
from selenium.webdriver.common.action_chains import ActionChains
from datetime import date
from datetime import datetime
from datetime import timedelta
import locators
import Login_Page
import Common
import Constants

driver = Login_Page.driver
def Trans_pip():
    time.sleep(2)
    driver.find_element_by_xpath(locators.tp).click() #Click on Transacational Pipeline Tab

def Roadmap():
    #Click on Roadmap Tab
    rd=driver.find_element_by_xpath(locators.rd).click()
    time.sleep(20)
    #Breadcrumb
    rd1=driver.find_element_by_xpath(locators.rd_b)
    return rd1

def RD_KPI():
    RDKPI=Common.KPI()
    unwanted=[3,4,5,6,7]
    for i in sorted(unwanted,reverse=True):   # if sorted reverse is not used list out of index error
        del RDKPI[i]
    del RDKPI[8:len(RDKPI)]
    print(RDKPI)
    return RDKPI

def RD_Graphs():
    graph = Common.Graphs()
    track = driver.find_element_by_xpath(locators.Track).text
    gh = driver.find_elements_by_xpath(locators.Graphs1)
    len(gh)
    g1 = []
    for i in range(len(gh)):
        g = driver.find_element_by_xpath('('+locators.Graphs1+')' + '[' + str(i + 1) + ']').text
        g1.append(g)
    print(g1)
    for i in g1:
        graph.append(i)
    graph.insert(2, track)
    print(graph)
    return graph

def rM_VPTrack_Inline_Clicks():
    # ------- default view (vp track) ------------------
    print("Chart Title:", driver.find_element_by_xpath(locators.rM_Track_Chart_Title).text)
    print("Legend:", driver.find_element_by_xpath(locators.rM_Track_Legend).text)
    rMPipe_VPTrack_Tooltip()

    # -------- inline clicks and corresponding views ------------
    arrow_Click = driver.find_element_by_xpath(locators.rM_Track_Chart_Inline_Click)
    arrow_Click.click()
    agg_Chart_Inline = driver.find_elements_by_xpath(locators.agg_Chart_Inlines)
    print("Element Size:", len(agg_Chart_Inline))
    for i in range(len(agg_Chart_Inline)):
        dropItem = driver.find_element_by_xpath("(" + locators.agg_Chart_Inlines + ")" + "[" + str(i + 1) + "]")
        print("Dropdown Item:", dropItem.text)
        dropItem.click()
        time.sleep(1)
        print(driver.find_element_by_xpath(locators.agg_Track_Chart_Title).text)
        print("Chart Title", driver.find_element_by_xpath(locators.agg_Track_Chart_Title).text)
        print("Legend:", driver.find_element_by_xpath(locators.rM_Track_Legend).text)
        legendIndi = driver.find_element_by_xpath(locators.agg_Track_Legend_Indi)
        print("Related Legend:", legendIndi.text)
        time.sleep(1)
        rMPipe_VPTrack_Tooltip()
        arrow_Click.click()
        time.sleep(1)
    arrow_Click.click()
    driver.find_element_by_xpath(locators.rM_Track_Chart_Inline_Click).click()
    driver.find_element_by_xpath(locators.rM_Track_Inline_setToWSR).click()
    time.sleep(1)

def rMPipe_VPTrack_Tooltip():
    moveOnLine = driver.find_elements_by_xpath(locators.agg_VPTrack_MoveOnLine)
    print("Element Size:", len(moveOnLine))
    for i in moveOnLine:
        ActionChains(driver).move_to_element(i).perform()
        driver.implicitly_wait(2)
#        time.sleep(1)
        rMPipe_VPTrack_Tooltip_label()

def rMPipe_VPTrack_Tooltip_label():
    lineLabel = driver.find_elements_by_xpath(locators.Tracks_Tooltip)
#    print(len(lineLabel)) --- uncomment this line for debugging purpose, if you may like.
    size = len(lineLabel)
    tooltip = lineLabel[size-1]
    print(tooltip.text)

def rM_Track_Chart_Title_Legend():
    print("Chart Title:", driver.find_element_by_xpath(locators.rM_Track_Chart_Title).text)

    arrow_Click = driver.find_element_by_xpath(locators.rM_Track_Chart_Inline_Click)
    arrow_Click.click()
    agg_Chart_Inline = driver.find_elements_by_xpath(locators.agg_Chart_Inlines)
    print("Element Size:", len(agg_Chart_Inline))
    lst_ChartTitle = []
    lst_ChartLegend = []
    for i in range(1, len(agg_Chart_Inline)):
        dropItem = driver.find_element_by_xpath("(" + locators.agg_Chart_Inlines + ")" + "[" + str(i) + "]")
        print("Dropdown Item:", dropItem.text)
        dropItem.click()
        time.sleep(1)
        chartTitle = driver.find_element_by_xpath(locators.agg_Track_Chart_Title)
        print("Chart Title", driver.find_element_by_xpath(locators.agg_Track_Chart_Title).text)
        lst_ChartTitle.append(chartTitle.text)
        chartLegend = driver.find_element_by_xpath(locators.agg_Track_Legend_Indi)
        print("Chart Legend", driver.find_element_by_xpath(locators.agg_Track_Legend_Indi).text)
        lst_ChartLegend.append(chartLegend.text)
        arrow_Click.click()
    print(lst_ChartTitle)
    print(lst_ChartLegend)
#    return lst_ChartTitle, lst_ChartLegend
    assert lst_ChartTitle == Constants.RM_Track_ChartTitles, "Chart Titles not as expected"
    assert lst_ChartLegend == Constants.RM_Track_Legend, "Chart legend not as expected"
    arrow_Click.click()
# ++++
def RMtop_nav():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle = driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    # driver.find_element_by_xpath(locators.RMTab).click()
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :" + str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-4):
        time.sleep(2)
        GH1[i].click()
        time.sleep(2)
        Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
        print(Topnav.text)
        listLegend1.append(Topnav.text)
        driver.find_element_by_xpath(locators.dropdown_wrapper).click()
    for i in listLegend1:
        listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    assert listLegend2== [['NQ'], ['Signings', 'Signings-ACV'], ['All', 'Americas', 'EMEA', 'Japan', 'APAC', 'INVALID', 'UNASSIGNED'], ['All', 'Systems w/TPS', 'Cloud & Data Platform', 'Security', 'Cognitive Applications','Watson Health'], ['LIO'], ['BU', 'CLIENT SEGMENT']],"not expected"
    return listLegend2

def RMBudgetcomparison():  # WeeklyBuildWSRBudgetComparision
    # BudgetKPI=driver.find_element_by_xpath(locators.RMBudgetKPI).text
    BudgetKPI = driver.find_element_by_xpath(locators.common_KPI_Budget_Val).text
    BudgetKPI=BudgetKPI.replace("$","").replace(",","").replace("M","")
    print("Budger kpi :"+BudgetKPI)
    time.sleep(2)
    RMExpand=driver.find_element_by_xpath(locators.RMTrendExpandGraph)
    RMExpand.click()
    time.sleep(2)
    driver.find_element_by_xpath(locators.RMTrendgraph_showtable).click()
    time.sleep(2)
    Budget=driver.find_element_by_xpath(locators.RMTrendbudgetCellvalue).text
    Budget=Budget.replace(",","")
    # print(type(Budget))
    Chart_title=driver.find_element_by_xpath(locators.RMGT4).text
    RMBudget=round(float(Budget))
    print(Chart_title +" Budget Value:" +str(RMBudget))
    time.sleep(2)
    driver.find_element_by_xpath(locators.RMTrendexpandtable_hidebutton).click()
    time.sleep(2)
    driver.find_element_by_xpath("(//*[@class='expandOrCollapseGraphIcons ng-star-inserted'])[4]").click()
    time.sleep(2)
    assert int(RMBudget)==int(BudgetKPI),("Graph: "+ Chart_title +"and Budget KPI value is not matching")

def Wkly_Build_WSR_KPI(): # Check the Cummulative WSR value, last row WSR value with WSR KPI
    WSRKPI = driver.find_element_by_xpath(locators.common_KPI_WSR_Val).text
    WSRKPI=WSRKPI.replace("$","").replace(",","").replace("M","")
    print("WSR KPI :"+WSRKPI)
    time.sleep(2)
    driver.find_element_by_xpath(locators.max1 + '[' + str(4) + ']').click()
    driver.find_element_by_xpath(locators.showhide).click()
    tx = driver.find_elements_by_xpath(locators.firstrow) # gives the total number of Rows in the table
    print(len(tx))
    tx = driver.find_element_by_xpath('(' + locators.firstrow + ')' + '[' + str(len(tx)) + ']').text
    tx = tx.split('\n')
    tx1 = tx[3].replace(",", "")
    WKLY_WSR = float(tx1) if tx1 != "N/A" else 0
    time.sleep(2)
    Chart_title = driver.find_element_by_xpath(locators.RMGT4).text
    print(Chart_title + " WSR Value:" + str(round(WKLY_WSR)))
    driver.find_element_by_xpath(locators.showhide).click()
    driver.find_element_by_xpath(locators.min1).click()
    assert int(round(WKLY_WSR)) == int(WSRKPI), ("Graph: "+ Chart_title +"and WSR KPI value is not matching")


def Wkly_Build_Inline_Clicks():
    # ------- default view (Wkly_Build) ------------------
    print("Chart Title:", driver.find_element_by_xpath(locators.RMGT4).text)
    print("Legend:", driver.find_element_by_xpath(locators.Wkly_Build_Legend).text)

    # -------- inline clicks and corresponding views ------------
    arrow_Click = driver.find_element_by_xpath(locators.Wkly_Build_Chart_Inline_Click)
    arrow_Click.click()
    agg_Chart_Inline = driver.find_elements_by_xpath(locators.agg_Chart_Inlines)
    print("Element Size:", len(agg_Chart_Inline))
    for i in range(len(agg_Chart_Inline)):
        dropItem = driver.find_element_by_xpath("(" + locators.agg_Chart_Inlines + ")" + "[" + str(i + 1) + "]")
        print("Dropdown Item:", dropItem.text)
        dropItem.click()
        time.sleep(1)
        print(driver.find_element_by_xpath(locators.RMGT4).text)
        print("Chart Title", driver.find_element_by_xpath(locators.RMGT4).text)
        print("Legend:", driver.find_element_by_xpath(locators.Wkly_Build_Legend).text)
        # legendIndi = driver.find_element_by_xpath(locators.agg_Track_Legend_Indi)
        # print("Related Legend:", legendIndi.text)
        time.sleep(1)
        RMBudgetcomparison()
        Wkly_Build_WSR_KPI()
        arrow_Click.click()
        time.sleep(1)
    arrow_Click.click()
    driver.find_element_by_xpath(locators.Wkly_Build_Chart_Inline_Click).click()
    driver.find_element_by_xpath(locators.Wkly_Build_Inline_setToWSR).click()
    time.sleep(1)



def RoadmapAllView():
    spview=driver.find_element_by_xpath(locators.filter_icon)
    time.sleep(5)
    spview.click()
    driver.find_element_by_xpath(locators.filter_icon)
    MoveEle = driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    element = "//*[@class='ng-dropdown-panel-items scroll-host']//div[@role='option']"
    time.sleep(5)
    arrow = driver.find_element_by_xpath(locators.bread_view)
    arrow.click()
    GH1 = driver.find_elements_by_xpath(element)
    print(type(GH1))
    print(len(GH1))
    list_GHOne = []
    for i in range(len(GH1)):
        abc = driver.find_element_by_xpath("("+element+")"+"["+str(i+1)+"]")
        list_GHOne.append(abc.text)
        print(abc.text)
        abc.click()
        time.sleep(2)
        RD_Graphs()
        time.sleep(2)
        arrow.click()
        time.sleep(2)
    print("Roadmap views"+str(list_GHOne))
    time.sleep(2)
    driver.find_element_by_xpath("(" + element + ")" + "[" + str(1) + "]").click()
    time.sleep(2)
    driver.find_element_by_xpath(locators.filter_icon_close).click()

def RM_ChartTitle():
        title1 = "//*[@class='text-center title']"
        abc = driver.find_elements_by_xpath(title1)
        print(len(abc))
        lstTitle1 = []
        for k in range(len(abc)):
            xyz  = driver.find_element_by_xpath("("+title1+")"+"["+str(k+1)+"]")
            print(xyz.text)
            lstTitle1.append(xyz.text)
        print("Graph Loaded :"+str(lstTitle1))
        # driver.find_element_by_xpath(locators.CloseGlobalfilter).click()

def RM_TrendLegends1():
    # driver.find_element_by_xpath(locators.RMTab).click()
    Element=driver.find_elements_by_xpath(locators.RMLegend)
    Legends =len(Element)
    print("Total Legends : " + str(Legends))
    listLegends=[]
    for i in range(len(Element)):
        time.sleep(2)
        legend=driver.find_element_by_xpath("("+locators.RMLegend+")"+"["+str(i+1)+"]")
        print(legend.text)
        listLegends.append(legend.text)
        time.sleep(5)
    print("WSR Legneds :"+str(listLegends))
    assert listLegends == ['Act/WON', 'SOLID', 'AT RISK'], "Not as expected"
    return  listLegends

def RM_TrendLegends2():
    driver.find_element_by_xpath("//*[text()='ROADMAP TREND']//..//*[@class='ng-arrow-wrapper']").click()
    time.sleep(5)
    WSRK=driver.find_element_by_xpath("(" + locators.agg_Chart_Inlines + ")" + "[" + str(1) + "]")
    WSRKeystretch= WSRK.text
    print("WSR KEY +STRETCH :" + str(WSRKeystretch))
    driver.find_element_by_xpath("(" + locators.agg_Chart_Inlines + ")" + "[" + str(1) + "]").click()
    WSRKS = "//*[@class='roadmapTempGraph']//*[@class='legend']"
    wsrlegend=driver.find_elements_by_xpath(WSRKS)
    listLegend =[]
    for j in range(len(wsrlegend)):
        time.sleep(2)
        legend1 = driver.find_element_by_xpath("("+WSRKS+")" + "["+str(j+1)+"]")
        print(legend1.text)
        listLegend.append(legend1.text)
        time.sleep(5)
    print("WSR + KSlegends : "+ str(listLegend))
    assert listLegend == ['Act/WON', 'SOLID', 'AT RISK', 'KEY STRETCH'], "Not as expected"
    return listLegend

def RM_TrendLegends3():
    driver.find_element_by_xpath("//*[text()='ROADMAP TREND']//..//*[@class='ng-arrow-wrapper']").click()
    time.sleep(5)
    WSRS=driver.find_element_by_xpath("//*[text()='WSR+KS+STRETCH']")
    WSRStretch= WSRS.text
    print("WSR KEY +STRETCH :" + str(WSRStretch))
    WSRSTRETCH = "//*[@class='roadmapTempGraph']//*[@class='legend']"
    driver.find_element_by_xpath("//*[text()='WSR+KS+STRETCH']").click()
    WSRSTRETCHlegend=driver.find_elements_by_xpath(WSRSTRETCH)
    listLegend1 =[]
    for K in range(len(WSRSTRETCHlegend)):
        time.sleep(2)
        legend2 = driver.find_element_by_xpath("("+WSRSTRETCH+")" + "["+str(K+1)+"]")
        print(legend2.text)
        listLegend1.append(legend2.text)
        time.sleep(5)
    print("WSR + KS + STRETCH : "+ str(listLegend1))
    assert listLegend1 == ['Act/WON', 'SOLID', 'AT RISK', 'KEY STRETCH', 'STRETCH'], "Not as expected"
    return listLegend1

def RMDateGraph1():
        GH1 = driver.find_element_by_xpath(locators.RMGT1).text
        print("Graph title : " + GH1)
        GH1Date = driver.find_element_by_xpath(locators.RMGraphDate1).text
        print("Graph title : " + GH1Date)

def RMDateGraph2():
        td = date.today()
        weeklydate = (td.weekday() - 2) % 7
        last_wednesday = td - timedelta(days=weeklydate)
        Wednesday = datetime.strftime(last_wednesday, '%b %d, %Y')
        print("Wednesday date :" + Wednesday)
        time.sleep(5)
        GH2 = driver.find_element_by_xpath(locators.RMGT2).text
        print("Graph title : " + GH2)
        GH2Date = driver.find_element_by_xpath(locators.RMGraphDate2).text
        print("Graph title : " + GH2Date)

def RMDateGraph3():
        td = date.today()
        weeklydate = (td.weekday() - 2) % 7
        last_wednesday = td - timedelta(days=weeklydate)
        Wednesday = datetime.strftime(last_wednesday, '%b %d, %Y')
        print("Wednesday date :" + Wednesday)
        time.sleep(5)
        GH3 = driver.find_element_by_xpath(locators.RMGT3).text
        print("Graph title : " + GH3)
        GH3Date = driver.find_element_by_xpath(locators.RMGraphDate3).text
        Gh3date = str(GH3Date).replace("Data as of ", "")
        print("Graph3 title : " + GH3Date)
        assert Gh3date.find(Wednesday) == 0, "Date is not matching"

def RMDateGraph4():
        td = date.today()
        weeklydate = (td.weekday() - 2) % 7
        last_wednesday = td - timedelta(days=weeklydate)
        Wednesday = datetime.strftime(last_wednesday, '%b %d, %Y')
        print("Wednesday date :" + Wednesday)
        time.sleep(5)
        GH4 = driver.find_element_by_xpath(locators.RMGT4).text
        print("Graph title : " + GH4)
        # GH4Date = driver.find_element_by_xpath(locators.RMGraphDate4).text
        GH4Date = driver.find_element_by_xpath(locators.RMGraphDate4).text
        Gh4date = str(GH4Date).replace("Data as of ", "")
        print("Graph4 Date : " + Gh4date)
        # assert Gh4date.find(Wednesday) == 0, "Date is not matching"



# ++++
def RD_WON_KPI_DF_Grp():
    RD_WON_block = driver.find_element_by_xpath(locators.rd_WON)
    print(RD_WON_block.text)
    global RD_WON_Val
    RD_WON_Val=Common.es_kpi1(RD_WON_block)
    print(RD_WON_Val)
    print("RD_WON is " + str(RD_WON_Val))
    time.sleep(5)
    RD_WON_block.click()
    time.sleep(5)
    RD_WON_group_default = driver.find_element_by_xpath(locators.Def_Grp)
    print(RD_WON_group_default.text)
    assert RD_WON_group_default.text == "By Roadmap Status", "Default Group for RD_WON is incorrect"
    # return VP_Val,Vp_group_default

def RD_WON_KPI_vs_Summary_DealList():
    # print(VP_Val)
    RD_WON_Summary_header = driver.find_element_by_xpath(locators.Summary_deal_header_val)
    global RD_WON_Deal_value_2
    RD_WON_Deal_value_2 = RD_WON_Summary_header.text.replace(",", "")
    RD_WON_Deal_value_2 = re.findall(r'[0-9]+[.]?[0-9]+', RD_WON_Deal_value_2)
    RD_WON_Deal_value_2 = RD_WON_Deal_value_2[0]

    print("Summary header lineitem Value for RD_WON click is " + str(RD_WON_Deal_value_2))
    diff = abs(float(RD_WON_Val) - float(RD_WON_Deal_value_2))
    print("Difference of RD_WON Kpi vs Deallist line item value is " + format(diff, '.2f'))
    assert diff<1,"Mismatch between RD_WON KPI value and RD_WON Click Deallist Line item Value"

def RD_WON_KPI_Summary_DealList_vs_Sum_Detailed_List():
    Detailed_list = driver.find_elements_by_css_selector(locators.Detailed_list)
    summary = []
    for i in range(len(Detailed_list)):
        Detailed_list_value = Detailed_list[i].text
        Detailed_list_value = Detailed_list_value.replace(",", "")
        Detailed_list_value = re.findall(r'[0-9]+[.]?[0-9]+', Detailed_list_value)
        Detailed_list_value = Detailed_list_value[0]
        print(Detailed_list_value)
        summary.append(float(Detailed_list_value))

    # print(summary)
    sum_summary = sum(summary)
    print("All RD_WON Deal list sum is " + str(sum_summary))

    diff_dealvSummaryLI = abs(float(sum_summary) - float(RD_WON_Deal_value_2))
    print("Difference of RD_WON Deal listsum vs Deallist line item value is " + format(diff_dealvSummaryLI, '.2f'))
    time.sleep(3)
    Common.common_Close_dealList()
    assert diff_dealvSummaryLI < 1, "Mismatch between RD_WON KPI Click Deallist Line item Value and Sum of Detailed Deal list"

def RD_STR_KPI_DF_Grp():
    RD_STR_block = driver.find_element_by_xpath(locators.rd_STR)
    print(RD_STR_block.text)
    global RD_STR_Val
    RD_STR_Val=Common.es_kpi1(RD_STR_block)
    print(RD_STR_Val)
    print("RD_STR is " + str(RD_STR_Val))
    RD_STR_block.click()
    time.sleep(3)
    RD_STR_group_default = driver.find_element_by_xpath(locators.Def_Grp)
    print(RD_STR_group_default.text)
    assert RD_STR_group_default.text == "By Roadmap Status", "Default Group for RD_STR is incorrect"
    # return VP_Val,Vp_group_default

def RD_STR_KPI_vs_Summary_DealList():
    # print(VP_Val)
    RD_STR_Summary_header = driver.find_element_by_xpath(locators.Summary_deal_header_val)
    global RD_STR_Deal_value_2
    RD_STR_Deal_value_2 = RD_STR_Summary_header.text.replace(",", "")
    RD_STR_Deal_value_2 = re.findall(r'[0-9]+[.]?[0-9]+', RD_STR_Deal_value_2)
    RD_STR_Deal_value_2 = RD_STR_Deal_value_2[0]

    print("Summary header lineitem Value for RD_STR click is " + str(RD_STR_Deal_value_2))
    diff = abs(float(RD_STR_Val) - float(RD_STR_Deal_value_2))
    print("Difference of RD_STR Kpi vs Deallist line item value is " + format(diff, '.2f'))
    assert diff<1,"Mismatch between RD_STR KPI value and RD_STR Click Deallist Line item Value"

def RD_STR_KPI_Summary_DealList_vs_Sum_Detailed_List():
    Detailed_list = driver.find_elements_by_css_selector(locators.Detailed_list)
    summary = []
    for i in range(len(Detailed_list)):
        Detailed_list_value = Detailed_list[i].text
        Detailed_list_value = Detailed_list_value.replace(",", "")
        Detailed_list_value = re.findall(r'[0-9]+[.]?[0-9]+', Detailed_list_value)
        Detailed_list_value = Detailed_list_value[0]
        print(Detailed_list_value)
        summary.append(float(Detailed_list_value))

    # print(summary)
    sum_summary = sum(summary)
    print("All RD_STR Deal list sum is " + str(sum_summary))

    diff_dealvSummaryLI = abs(float(sum_summary) - float(RD_STR_Deal_value_2))
    print("Difference of RD_STR Deal listsum vs Deallist line item value is " + format(diff_dealvSummaryLI, '.2f'))
    time.sleep(3)
    Common.common_Close_dealList()
    assert diff_dealvSummaryLI < 1, "Mismatch between RD_STR KPI Click Deallist Line item Value and Sum of Detailed Deal list"

def RD_WKS_KPI_DF_Grp():
    RD_WKS_block = driver.find_element_by_xpath(locators.rd_WKS)
    print(RD_WKS_block.text)
    global RD_WKS_Val
    RD_WKS_Val=Common.es_kpi1(RD_WKS_block)
    print(RD_WKS_Val)
    print("RD_WKS is " + str(RD_WKS_Val))
    RD_WKS_block.click()
    time.sleep(3)
    RD_WKS_group_default = driver.find_element_by_xpath(locators.Def_Grp)
    print(RD_WKS_group_default.text)
    assert RD_WKS_group_default.text == "By Roadmap Status", "Default Group for RD_WKS is incorrect"
    # return VP_Val,Vp_group_default

def RD_WKS_KPI_vs_Summary_DealList():
    # print(VP_Val)
    RD_WKS_Summary_header = driver.find_element_by_xpath(locators.Summary_deal_header_val)
    global RD_WKS_Deal_value_2
    RD_WKS_Deal_value_2 = RD_WKS_Summary_header.text.replace(",", "")
    RD_WKS_Deal_value_2 = re.findall(r'[0-9]+[.]?[0-9]+', RD_WKS_Deal_value_2)
    RD_WKS_Deal_value_2 = RD_WKS_Deal_value_2[0]

    print("Summary header lineitem Value for RD_WKS click is " + str(RD_WKS_Deal_value_2))
    diff = abs(float(RD_WKS_Val) - float(RD_WKS_Deal_value_2))
    print("Difference of RD_WKS Kpi vs Deallist line item value is " + format(diff, '.2f'))
    assert diff<1,"Mismatch between RD_WKS KPI value and RD_WKS Click Deallist Line item Value"

def RD_WKS_KPI_Summary_DealList_vs_Sum_Detailed_List():
    Detailed_list = driver.find_elements_by_css_selector(locators.Detailed_list)
    summary = []
    for i in range(len(Detailed_list)):
        Detailed_list_value = Detailed_list[i].text
        Detailed_list_value = Detailed_list_value.replace(",", "")
        Detailed_list_value = re.findall(r'[0-9]+[.]?[0-9]+', Detailed_list_value)
        Detailed_list_value = Detailed_list_value[0]
        print(Detailed_list_value)
        summary.append(float(Detailed_list_value))

    # print(summary)
    sum_summary = sum(summary)
    print("All RD_WKS Deal list sum is " + str(sum_summary))

    diff_dealvSummaryLI = abs(float(sum_summary) - float(RD_WKS_Deal_value_2))
    print("Difference of RD_WKS Deal listsum vs Deallist line item value is " + format(diff_dealvSummaryLI, '.2f'))
    time.sleep(3)
    Common.common_Close_dealList()
    assert diff_dealvSummaryLI < 1, "Mismatch between RD_WKS KPI Click Deallist Line item Value and Sum of Detailed Deal list"


def RD_WKS_ST_KPI_DF_Grp():
    RD_WKS_ST_block = driver.find_element_by_xpath(locators.RD_WKS_ST)
    print(RD_WKS_ST_block.text)
    global RD_WKS_ST_Val
    RD_WKS_ST_Val=Common.es_kpi1(RD_WKS_ST_block)
    print(RD_WKS_ST_Val)
    print("RD_WKS_ST is " + str(RD_WKS_ST_Val))
    RD_WKS_ST_block.click()
    time.sleep(3)
    RD_WKS_ST_group_default = driver.find_element_by_xpath(locators.Def_Grp)
    print(RD_WKS_ST_group_default.text)
    assert RD_WKS_ST_group_default.text == "By Roadmap Status", "Default Group for RD_WKS_ST is incorrect"
    # return VP_Val,Vp_group_default

def RD_WKS_ST_KPI_vs_Summary_DealList():
    # print(VP_Val)
    RD_WKS_ST_Summary_header = driver.find_element_by_xpath(locators.Summary_deal_header_val)
    global RD_WKS_ST_Deal_value_2
    RD_WKS_ST_Deal_value_2 = RD_WKS_ST_Summary_header.text.replace(",", "")
    RD_WKS_ST_Deal_value_2 = re.findall(r'[0-9]+[.]?[0-9]+', RD_WKS_ST_Deal_value_2)
    RD_WKS_ST_Deal_value_2 = RD_WKS_ST_Deal_value_2[0]

    print("Summary header lineitem Value for RD_WKS click is " + str(RD_WKS_ST_Deal_value_2))
    diff = abs(float(RD_WKS_ST_Val) - float(RD_WKS_ST_Deal_value_2))
    print("Difference of RD_WKS_ST Kpi vs Deallist line item value is " + format(diff, '.2f'))
    assert diff<1,"Mismatch between RD_WKS_ST KPI value and RD_WKS_ST Click Deallist Line item Value"

def RD_WKS_ST_KPI_Summary_DealList_vs_Sum_Detailed_List():
    Detailed_list = driver.find_elements_by_css_selector(locators.Detailed_list)
    summary = []
    for i in range(len(Detailed_list)):
        Detailed_list_value = Detailed_list[i].text
        Detailed_list_value = Detailed_list_value.replace(",", "")
        Detailed_list_value = re.findall(r'[0-9]+[.]?[0-9]+', Detailed_list_value)
        Detailed_list_value = Detailed_list_value[0]
        print(Detailed_list_value)
        summary.append(float(Detailed_list_value))

    # print(summary)
    sum_summary = sum(summary)
    print("All RD_WKS_ST Deal list sum is " + str(sum_summary))

    diff_dealvSummaryLI = abs(float(sum_summary) - float(RD_WKS_ST_Deal_value_2))
    print("Difference of RD_WKS_ST Deal listsum vs Deallist line item value is " + format(diff_dealvSummaryLI, '.2f'))
    time.sleep(3)
    Common.common_Close_dealList()
    assert diff_dealvSummaryLI < 1, "Mismatch between RD_WKS_ST KPI Click Deallist Line item Value and Sum of Detailed Deal list"





##---------------------------call code below-------------------------##

# Login_Page.open_ISD()
# Roadmap()
# RD_KPI()
# RD_Graphs()
# Common.expand_showhide_colapase()
# rM_VPTrack_Inline_Clicks()
# rM_Track_Chart_Title_Legend()
#
# RMtop_nav()
# RMBudgetcomparison() # Weekly Build Graph
# Wkly_Build_WSR_KPI()
# Wkly_Build_Inline_Clicks()
# RoadmapAllView()
## RM_ChartTitle() ignore
## RM_TrendLegends1() ignore
## RM_TrendLegends2()ignore
## RM_TrendLegends3()ignore
# RMDateGraph1()
# RMDateGraph2()
# RMDateGraph3()
# RMDateGraph4()
# #
# RD_WON_KPI_DF_Grp()
# RD_WON_KPI_vs_Summary_DealList()
# RD_WON_KPI_Summary_DealList_vs_Sum_Detailed_List()
#
# RD_STR_KPI_DF_Grp()
# RD_STR_KPI_vs_Summary_DealList()
# RD_STR_KPI_Summary_DealList_vs_Sum_Detailed_List()
#
# RD_WKS_KPI_DF_Grp()
# RD_WKS_KPI_vs_Summary_DealList()
# RD_WKS_KPI_Summary_DealList_vs_Sum_Detailed_List()
# #
# RD_WKS_ST_KPI_DF_Grp()
# RD_WKS_ST_KPI_vs_Summary_DealList()
# RD_WKS_ST_KPI_Summary_DealList_vs_Sum_Detailed_List()
