from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
import re
from selenium.webdriver.common.action_chains import ActionChains
from datetime import date
from datetime import datetime
from datetime import timedelta
import locators
import Login_Page
import Common
import ES_Page
import AP_Page

driver = Login_Page.driver
def Segmented_tab():
    #Click on Segmented Tab
    time.sleep(2)
    driver.find_element_by_xpath(locators.sp).click()
    time.sleep(20)

def Segmented_bc():
    #Breadcrumb
    sp1=driver.find_element_by_xpath(locators.sp_b)
    return sp1

def SP_KPI():
    SPKPI=Common.KPI()
    # del SPKPI[5]
    del SPKPI[7:len(SPKPI)]
    print(SPKPI)
    return SPKPI

def SP_KPI2():
    SPKPI=Common.KPI()
    # del SPKPI[6]
    del SPKPI[4:8]
    del SPKPI[7:len(SPKPI)]
    print(SPKPI)
    return SPKPI

# Budget & PPV  for 3 graphs Summary view
def Budget_PPV_Sumy():
    B = []
    P = []
    for j in range(3):
        driver.find_element_by_xpath(locators.max1 + '[' + str(j + 1) + ']').click()
        driver.find_element_by_xpath(locators.sp_showhide).click()
        tx = driver.find_elements_by_xpath(locators.firstrow) # gives the total number of Rows in the table
        # print(len(tx))
        kpi=SP_KPI()
        t = 0
        t2 = 0
        b=""
        p=""
        for i in range(len(tx)):
            tx = driver.find_element_by_xpath('(' + locators.firstrow + ')' + '[' + str(i + 1) + ']').text
            tx = tx.split('\n')
            tx1 = tx[1].replace(",", "")
            tx1 = float(tx1) if tx1 != "N/A" else 0  #Inline if Function
            t = t + tx1
            tx2 = tx[3].replace(",", "")
            tx2 = float(tx2) if tx2 != "N/A" else 0
            t2 = t2 + tx2
        #     print("Budget Graph"+str(j+1)+" : "+str(t)) # give values in list
        print("Sum Budget Graph_" + str(j + 1) + " : " + str(t))

        #     print("PPV Graph"+str(j+1)+" : "+str(t2)) # give values in list
        print("Sum PPV Graph_" + str(j + 1) + " : " + str(t2))
        # P.append(round(t2))
        if (kpi[0] != round(t)):
            b = "Budget not matching for Graph"+ str(j + 1)

        if (kpi[1] != round(t2)):
            p = "PPV not matching for Graph" + str(j + 1)
        B.append(b)
        P.append(p)
        driver.find_element_by_xpath(locators.sp_showhide).click()
        driver.find_element_by_xpath(locators.min1).click()
    print(B, P)
    return B,P

def Budget_PPV():
    B = []
    P = []
    for j in range(1):
        driver.find_element_by_xpath(locators.max1 + '[' + str(j + 1) + ']').click()
        driver.find_element_by_xpath(locators.sp_showhide).click()
        tx = driver.find_elements_by_xpath(locators.firstrow) # gives the total number of Rows in the table
        # print(len(tx))
        t = 0
        t2 = 0
        for i in range(len(tx)):
            tx = driver.find_element_by_xpath('(' + locators.firstrow + ')' + '[' + str(i + 1) + ']').text
            tx = tx.split('\n')
            tx1 = tx[1].replace(",", "")
            tx1 = float(tx1) if tx1 != "N/A" else 0  #Inline if Function
            t = t + tx1
            tx2 = tx[3].replace(",", "")
            tx2 = float(tx2) if tx2 != "N/A" else 0
            t2 = t2 + tx2
        #     print("Budget Graph"+str(j+1)+" : "+str(t)) # give values in list
        print("Sum Budget Graph_" + str(j + 1) + " : " + str(t))
        B.append(round(t))
        #     print("PPV Graph"+str(j+1)+" : "+str(t2)) # give values in list
        print("Sum PPV Graph_" + str(j + 1) + " : " + str(t2))
        P.append(round(t2))
        driver.find_element_by_xpath(locators.sp_showhide).click()
        driver.find_element_by_xpath(locators.min1).click()
    print(B, P)
    return B,P

def VP_QP():
    VP_QP = []
    for j in range(1,3):
        driver.find_element_by_xpath(locators.max1 + '[' + str(j + 1) + ']').click()
        driver.find_element_by_xpath(locators.sp_showhide).click()
        tx = driver.find_elements_by_xpath(locators.firstrow) # gives the total number of Rows in the table
        # print(len(tx))
        t = 0
        for i in range(len(tx)):
            tx = driver.find_element_by_xpath('(' + locators.firstrow + ')' + '[' + str(i + 1) + ']').text
            tx = tx.split('\n')
            tx1 = tx[1].replace(",", "")
            tx1 = float(tx1) if tx1 != "N/A" else 0  #Inline if Function
            t = t + tx1
        #     print("Budget Graph"+str(j+1)+" : "+str(t)) # give values in list
        print("Sum VP_or_QP : " + str(t))
        VP_QP.append(round(t))
        driver.find_element_by_xpath(locators.sp_showhide).click()
        driver.find_element_by_xpath(locators.min1).click()
    print(VP_QP)
    return VP_QP


def VP_graph4():
    VP = []
    for j in range(3,4):
        driver.find_element_by_xpath(locators.max1 + '[' + str(j + 1) + ']').click()
        driver.find_element_by_xpath(locators.sp_showhide).click()
        tx = driver.find_elements_by_xpath(locators.firstrow) # gives the total number of Rows in the table
        # print(len(tx))
        t = 0
        t2 = 0
        t3 = 0
        t4 = 0
        for i in range(len(tx)):
            tx = driver.find_element_by_xpath('(' + locators.firstrow + ')' + '[' + str(i + 1) + ']').text
            tx = tx.split('\n')
            tx1 = tx[1].replace(",", "")
            tx1 = float(tx1) if tx1 != "N/A" else 0  #Inline if Function
            t = t + tx1
            tx2 = tx[4].replace(",", "")
            tx2 = float(tx2) if tx2 != "N/A" else 0
            t2 = t2 + tx2
            tx3 = tx[7].replace(",", "")
            tx3 = float(tx3) if tx3 != "N/A" else 0
            t3 = t3 + tx3
            tx4 = tx[10].replace(",", "")
            tx4 = float(tx4) if tx4 != "N/A" else 0
            t4 = t4 + tx4
        #     print("Budget Graph"+str(j+1)+" : "+str(t)) # give values in list
        print("Sum VP Sales_Stage_Graph : " + str(t+t2+t3+t4))
        VP.append(round(t+t2+t3+t4))
        #     print("PPV Graph"+str(j+1)+" : "+str(t2)) # give values in list
        # print("Sum PPV Graph_" + str(j + 1) + " : " + str(t2))
        # P.append(round(t2))
        driver.find_element_by_xpath(locators.sp_showhide).click()
        driver.find_element_by_xpath(locators.min1).click()
    print(VP)
    return VP

def loop_view(): #lopping accross views opts and coming back to summary view. Checking with KPI's, failing for Dealsize,Channel Budget graph1 not mathcing as 0,for INDUSTRY SOLUTIONS - Budget and VP not matching as 0
    bp_res = ""
    vpqp_res=""
    vpG4_res=""
    driver.find_element_by_xpath(locators.filter_icon).click()
    driver.find_element_by_xpath(locators.sp_view).click()
    lb=driver.find_elements_by_xpath(locators.sp_view_count)
    len(lb)
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    time.sleep(10)
    for i in range(len(lb)):
        driver.find_element_by_xpath(locators.sp).click()
        driver.find_element_by_xpath(locators.filter_icon).click()
        driver.find_element_by_xpath(locators.sp_view).click()
        option=driver.find_element_by_xpath('(' + locators.sp_view_opt + ')' + "[" + str(i + 1) + "]").text
        print("View: "+option)
        driver.find_element_by_xpath('(' + locators.sp_view_opt_clk + ')'+"["+str(i+1)+"]").click()
        driver.find_element_by_xpath(locators.filter_icon_close).click()

        if option!="SOLUTIONS - Strategic Imperatives" and option!="JTC/RHS" and option!="JTC" and option!="RHS":
            time.sleep(5)
            Common.Graphs1()
            kpi = SP_KPI()
            bp=Budget_PPV()
            # print(kpi[0])
            # print(kpi[1])
            # print(bp[0][0])
            # print(bp[1][0])
            if (kpi[0]!=bp[0][0]) or (kpi[1]!=bp[1][0]):
                bp_res="Budget or PPV not matching for Graph1"
                print(bp_res)
            # SP_KPI()
            vpqp=VP_QP()
            # print(kpi[4])
            # print(vpqp[0])
            # print(kpi[5])
            # print(vpqp[1])
            if (kpi[4]!=vpqp[0]) or (kpi[5]!=vpqp[1]):
                vpqp_res="VP Graph2 or QP Graph3 not matching"
                print(vpqp_res)
            # SP_KPI()
            vpG4=VP_graph4()
            # print(kpi[4])
            # print(vpG4[0])
            if kpi[4]!=vpG4[0]:
                vpG4_res="VP not matching for Graph4"
                print(vpG4_res)
        elif option=="JTC/RHS":
            time.sleep(5)
            Common.Graphs1()
            # SP_KPI()
            # Common.sp_expand_showhide_colapase3()
        elif option=="JTC" or option=="RHS":
            time.sleep(5)
            Common.Graphs1()
            # SP_KPI2()
            # Common.sp_expand_showhide_colapase2()
        else:
            time.sleep(5)
            Common.Graphs1()
            print("At present Not checking for the view : SOLUTIONS - Strategic Imperatives")
            pass
            # SP_KPI()
    #     time.sleep(5)
    #     print(driver.find_element_by_xpath("(//*[@class='ng-value-label ng-star-inserted'])[3]").text) # after clicking get the text

    driver.find_element_by_xpath(locators.filter_icon).click()
    driver.find_element_by_xpath(locators.sp_view).click()
    driver.find_element_by_xpath('(' + locators.sp_view_sum_clck+ ')'+"["+str(1)+"]").click()
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    time.sleep(10)
    print(bp_res,vpqp_res,vpG4_res)
    return bp_res,vpqp_res,vpG4_res
#
# def toggle_vp():
#     driver.find_element_by_xpath(locators.sp).click()
#     hv1=driver.find_elements_by_xpath("//*[@class='ng-tns-c59-19 ng-trigger ng-trigger-animationState ng-star-inserted']")
#     for i in range(len(hv1)):
#         tx=driver.find_element_by_xpath("//*[@class='ng-tns-c59-19 ng-trigger ng-trigger-animationState ng-star-inserted']").text
#         if ('WtW' in tx):
#             t=t+1
#         if t<len(hv1):
#             res1="Toggle Error for WtW intial"
#             print(res1)
#     # VP Toggle
#     driver.find_element_by_xpath("(//SPAN[@_ngcontent-c56=''][text()='YtY'][text()='YtY'])[2]/..//SPAN[@_ngcontent-c56=''][text()='WtW'][text()='WtW']").click()
#     for i in range(len(hv1)):
#         tx=driver.find_element_by_xpath("//*[@class='ng-tns-c59-19 ng-trigger ng-trigger-animationState ng-star-inserted']").text
#         if ('YtY' in tx):
#             t=t+1
#         if t<len(hv1):
#             res2="Toggle Error for YtY after toggle"
#             print(res2)
#     driver.find_element_by_xpath("(//SPAN[@_ngcontent-c56=''][text()='YtY'][text()='YtY'])[2]/..//SPAN[@_ngcontent-c56=''][text()='WtW'][text()='WtW']").click()
#     for i in range(len(hv1)):
#         tx=driver.find_element_by_xpath("//*[@class='ng-tns-c59-19 ng-trigger ng-trigger-animationState ng-star-inserted']").text
#         if ('WtW' in tx):
#             t=t+1
#         if t<len(hv1):
#             res3="Toggle Error for WtW after toggle"
#             print(res3)
#     return res1,res2,res3
#
# def toggle_qp():
#     driver.find_element_by_xpath(locators.sp).click()
#     hv1=driver.find_elements_by_xpath("//*[@class='ng-tns-c59-21 ng-trigger ng-trigger-animationState ng-star-inserted']")
#     for i in range(len(hv1)):
#         tx=driver.find_element_by_xpath("//*[@class='ng-tns-c59-21 ng-trigger ng-trigger-animationState ng-star-inserted']").text
#         if ('WtW' in tx):
#             t=t+1
#         if t<len(hv1):
#             res1="Toggle Error for WtW intial"
#             print(res1)
#     # QP Toggle
#     driver.find_element_by_xpath("(//SPAN[@_ngcontent-c56=''][text()='YtY'][text()='YtY'])[4]/..//SPAN[@_ngcontent-c56=''][text()='WtW'][text()='WtW']").click()
#     for i in range(len(hv1)):
#         tx=driver.find_element_by_xpath("//*[@class='ng-tns-c59-21 ng-trigger ng-trigger-animationState ng-star-inserted']").text
#         if ('YtY' in tx):
#             t=t+1
#         if t<len(hv1):
#             res2="Toggle Error for YtY after toggle"
#             print(res2)
#     driver.find_element_by_xpath("(//SPAN[@_ngcontent-c56=''][text()='YtY'][text()='YtY'])[4]/..//SPAN[@_ngcontent-c56=''][text()='WtW'][text()='WtW']").click()
#     for i in range(len(hv1)):
#         tx=driver.find_element_by_xpath("//*[@class='ng-tns-c59-21 ng-trigger ng-trigger-animationState ng-star-inserted']").text
#         if ('WtW' in tx):
#             t=t+1
#         if t<len(hv1):
#             res3="Toggle Error for WtW after toggle"
#             print(res3)
#     return res1,res2,res3
#
# def toggle():
#     driver.find_element_by_xpath(locators.filter_icon).click()
#     driver.find_element_by_xpath(locators.sp_view).click()
#     lb=driver.find_elements_by_xpath(locators.sp_view_count)
#     len(lb)
#     driver.find_element_by_xpath(locators.filter_icon_close).click()
#     for i in range(len(lb)):
#         driver.find_element_by_xpath(locators.sp).click()
#         driver.find_element_by_xpath(locators.filter_icon).click()
#         driver.find_element_by_xpath(locators.sp_view).click()
#         option=driver.find_element_by_xpath('(' + locators.sp_view_opt + ')' + "[" + str(i + 1) + "]").text
#         print("View: "+option)
#         driver.find_element_by_xpath('(' + locators.sp_view_opt_clk + ')'+"["+str(i+1)+"]").click()
#         driver.find_element_by_xpath(locators.filter_icon_close).click()
#         time.sleep(5)
#         if option == "INDUSTRY SOLUTIONS":
#             toggle_qp()
#         if option == "SOLUTIONS - Strategic Imperatives":
#
#         toggle_vp()
#         toggle_qp()
def segPipe_breadcrumb():
    breadcrumb = driver.find_element_by_xpath(locators.seg_bread)
    print(breadcrumb.text)
    return breadcrumb.text

def segPipe_View_StratImp():
    driver.find_element_by_xpath(locators.seg_View_Arrow).click()
    time.sleep(1)
    driver.find_element_by_xpath(locators.seg_View_StratImp).click()

def segPipe_View_IndSol():
    driver.find_element_by_xpath(locators.seg_View_Arrow).click()
    time.sleep(1)
    driver.find_element_by_xpath(locators.seg_View_IndSol).click()
    time.sleep(1)

def segPipe_RevType():
    arrow_Click = driver.find_element_by_xpath(locators.seg_RevType_Arrow).click()
    time.sleep(1)
    print(driver.find_element_by_id(locators.seg_RevType_Option_ALL).text)
    # all = driver.find_element_by_id(locators.seg_RevType_Option_ALL)
    # print(all.text)
    isChecked = driver.find_element_by_xpath(locators.agg_Chart_Inlines).get_attribute('aria-selected')
    assert isChecked == 'true', "Default Checkbox Not Selected"

def segPipe_All_Chart_Titles_StratImp():
    chartsTitle = driver.find_elements_by_xpath(locators.seg_All_Chart_Titles)
    print(len(chartsTitle))
    titleList = []
    time.sleep(10)
    for i in range(len(chartsTitle)):
        eachChartTitle = driver.find_element_by_xpath("("+locators.seg_All_Chart_Titles+")"+"["+str(i+1)+"]")
        titleList.append(eachChartTitle.text)
    print(titleList)
    return titleList

def segPipe_KPI_Labels():
    lbl_KPI = driver.find_elements_by_xpath(locators.seg_KPI_Labels)
    print(len(lbl_KPI))
    lblKPIlist = []
    for i in range(len(lbl_KPI)):
        eachKPIlbl = driver.find_element_by_xpath("("+locators.seg_KPI_Labels+")"+"["+str(i+1)+"]")
        lblKPIlist.append(eachKPIlbl.text)
    print(lblKPIlist)
    return lblKPIlist

def segPipe_KPI_Tiles_VP_Onwards_StratImp():
    tile_KPI = driver.find_elements_by_xpath(locators.seg_KPI_Tiles)
    print(len(tile_KPI))
    VPonwards=""
    for i in range(5,len(tile_KPI)+1):
        print(i)
        VPonwards = driver.find_element_by_xpath("("+locators.seg_KPI_Tiles+")"+"["+str(i)+"]")
        print(VPonwards.text)
        VPonwards.click()
        time.sleep(1)
        assert VPonwards.is_displayed(), "Modal should not open, but it may have"
    # Back to Summary View
    driver.find_element_by_xpath(locators.filter_icon).click()
    driver.find_element_by_xpath(locators.sp_view).click()
    time.sleep(3)
    driver.find_element_by_xpath("(" + locators.sp_view_sum_clck + ")" + "[" + str(1) + "]").click()
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    time.sleep(2)


def segPipe_KPI_ValFetch():
    all_KPI =  driver.find_elements_by_xpath(locators.seg_KPI_Tiles)
    print(len(all_KPI))
    list_KPI = []
    for i in range(len(all_KPI)):
        eachKPI = driver.find_element_by_xpath("("+locators.seg_KPI_Tiles+")"+"["+str(i+1)+"]")
        print(eachKPI.text)
        list_KPI.append(eachKPI.text)
    #Back to Summary View
    driver.find_element_by_xpath(locators.filter_icon).click()
    driver.find_element_by_xpath(locators.sp_view).click()
    driver.find_element_by_xpath('(' + locators.sp_view_sum_clck+ ')'+"["+str(1)+"]").click()
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    print(list_KPI)
    return list_KPI

def SPtop_nav():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle=driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    time.sleep(2)
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :"+str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)):
        time.sleep(2)
        GH1[i].click()#segPipe_KPI_Labels()
        time.sleep(2)
        Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
        print(Topnav.text)
        listLegend1.append(Topnav.text)
        driver.find_element_by_xpath(locators.dropdown_wrapper).click()
    # print(listLegend1)
    for i in listLegend1:
            listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    assert listLegend2 == [['NQ'], ['Signings', 'Signings-ACV'],['All', 'Americas', 'EMEA', 'Japan', 'APAC', 'INVALID', 'UNASSIGNED'],['All', 'Systems w/TPS', 'Cloud & Data Platform', 'Security', 'Cognitive Applications','Watson Health'],['CLIENT SET', 'DEAL SIZE', 'CHANNEL','JTC/RHS', 'JTC', 'RHS', 'SOLUTIONS - Strategic Imperatives','INDUSTRY SOLUTIONS', 'OI GROUP']], "Not expected"
    return listLegend2

def SPGraphDate1():
       td = date.today()
       weeklydate = (td.weekday() - 2) % 7
       last_wednesday = td - timedelta(days=weeklydate)
       Wednesday = datetime.strftime(last_wednesday, '%b %d, %Y')
       print("Wednesday date :" + Wednesday)
       time.sleep(5)

       GH1 = driver.find_element_by_xpath(locators.GH1_SP).text
       print("Graph title : " + GH1)
       GH1Date = driver.find_element_by_xpath(locators.SPGH1Date).text
       Gh1date = str(GH1Date).replace("Data as of ", "")
       print("Graph1date : " + Gh1date)
       assert Gh1date.find(Wednesday) == 0, "Date is not matching"


def SPGraphDate2():
        # driver.find_element_by_xpath("//*[@id='seg']").click()
        td = date.today()
        weeklydate = (td.weekday() - 2) % 7
        last_wednesday = td - timedelta(days=weeklydate)
        Wednesday = datetime.strftime(last_wednesday, '%b %d, %Y')
        print("Wednesday date :" + Wednesday)
        time.sleep(5)
        GH2 = driver.find_element_by_xpath(locators.GH2_SP).text
        print("Graph title : " + GH2)
        GH2Date = driver.find_element_by_xpath(locators.SPGH2Date).text
        Gh2date = str(GH2Date).replace("Data as of ", "")
        print("Graph2date : " + Gh2date)
        assert Gh2date.find(Wednesday) == 0, "Date is not matching"


def SPGraphDate3():
        td = date.today()
        weeklydate = (td.weekday() - 2) % 7
        last_wednesday = td - timedelta(days=weeklydate)
        Wednesday = datetime.strftime(last_wednesday, '%b %d, %Y')
        print("Wednesday date :" + Wednesday)
        time.sleep(5)
        GH3 = driver.find_element_by_xpath(locators.GH3_SP).text
        print("Graph title : " + GH3)
        GH3Date = driver.find_element_by_xpath(locators.SPGH3Date).text
        Gh3date = str(GH3Date).replace("Data as of ", "")
        print("Graph3date : " + Gh3date)
        assert Gh3date.find(Wednesday) == 0, "Date is not matching"



def SPGraphDate4():
    td = date.today()
    weeklydate = (td.weekday() - 2) % 7
    last_wednesday = td - timedelta(days=weeklydate)
    Wednesday = datetime.strftime(last_wednesday, '%b %d, %Y')
    print("Wednesday date :" + Wednesday)
    time.sleep(5)
    GH4 = driver.find_element_by_xpath(locators.GH4_SP).text
    print("Graph title : " + GH4)
    GH4Date = driver.find_element_by_xpath(locators.SPGH4Date).text
    Gh4date = str(GH4Date).replace("Data as of ", "")
    print("Graph4 Date : " + GH4Date)
    assert Gh4date.find(Wednesday) == 0, "Date is not matching"


def Weekly_date(date):
    td = date.today()
    weeklydate = (td.weekday() - 2) % 7
    last_wednesday = td - timedelta(days=weeklydate)
    Wednesday = datetime.strftime(last_wednesday, '%b %d, %Y')
    # return  Wednesday
    print("Wednesday date :" + Wednesday)

def SP_VP_KPI_DF_Grp():
    ES_Page.VP_KPI_DF_Grp()

def SP_VP_KPI_vs_Summary_DealList():
    ES_Page.VP_KPI_vs_Summary_DealList()

def SP_VP_KPI_Summary_DealList_vs_Sum_Detailed_List():
    ES_Page.VP_KPI_Summary_DealList_vs_Sum_Detailed_List()

def SP_QP_KPI_DF_Grp():
    AP_Page.AP_QP_KPI_DF_Grp()

def SP_QP_KPI_vs_Summary_DealList():
    AP_Page.AP_QP_KPI_vs_Summary_DealList()

def SP_QP_KPI_Summary_DealList_vs_Sum_Detailed_List():
    AP_Page.AP_QP_KPI_Summary_DealList_vs_Sum_Detailed_List()

def SP_WON_KPI_DF_Grp():
    AP_Page.AP_WON_KPI_DF_Grp()

def SP_WON_KPI_vs_Summary_DealList():
    AP_Page.AP_WON_KPI_vs_Summary_DealList()

def SP_WON_KPI_Summary_DealList_vs_Sum_Detailed_List():
    AP_Page.AP_WON_KPI_Summary_DealList_vs_Sum_Detailed_List()

##---------------------------call code below-------------------------##
#
# Login_Page.open_ISD()
# Segmented_tab()
# Segmented_bc()
#
# Common.GlobFilterClick()
# segPipe_View_StratImp()
# segPipe_RevType()
# Common.GlobFilterXiconClick()
# segPipe_breadcrumb()
#
# segPipe_All_Chart_Titles_StratImp()
#
# segPipe_KPI_Labels()
#
# segPipe_KPI_Tiles_VP_Onwards_StratImp()
#
# Common.GlobFilterClick()
# segPipe_View_IndSol()
# segPipe_RevType()
# Common.GlobFilterXiconClick()
# segPipe_breadcrumb()
#
# segPipe_KPI_Labels()
#
# segPipe_KPI_ValFetch()


# SP_KPI()
# Common.sp_expand_showhide_colapase()
# Budget_PPV_Sumy()
## VP_graph4() #(ingore for now)
# loop_view()
# #
# SPtop_nav()
## SegmentedAllView()  #(ingore for now)
# SPGraphDate1()
# SPGraphDate2()
# SPGraphDate3()
# SPGraphDate4()
#
# SP_VP_KPI_DF_Grp()
# SP_VP_KPI_vs_Summary_DealList()
# SP_VP_KPI_Summary_DealList_vs_Sum_Detailed_List()
#
# SP_QP_KPI_DF_Grp()
# SP_QP_KPI_vs_Summary_DealList()
# SP_QP_KPI_Summary_DealList_vs_Sum_Detailed_List()
#
# SP_WON_KPI_DF_Grp()
# SP_WON_KPI_vs_Summary_DealList()
# SP_WON_KPI_Summary_DealList_vs_Sum_Detailed_List()

