'''
Profile Details
User Role : Global Mkt -SVP & GM
Client Set : All
Geo : All
Market : All
Manager's Node : Not Applicable
'''
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
import re
import Login_Page
import ES_Page
import RD_Page
import AP_Page
import SP_Page
import KD_Page
import MI_Page
import Common
import Constants
import pytest
import locators
from selenium.webdriver.common.action_chains import ActionChains
# pytest ***.py
# pytest -v
#Allure reporting
    #python -m pytest ***.py --alluredir=C:\FilesFolders\Practice\PycharmProjects\2019\Skyline\ISD_Testing\Reports
    # goto the Reports folder from command line
    # in command line : allure generate C:\FilesFolders\Practice\PycharmProjects\2019\Skyline\ISD_Testing\Reports
    # open in Mozilla takes some time

driver = Login_Page.driver
def test_open():
    Login_Page.open_ISD()

# ### Executive Summary ####
def test_ESopen():
    # Check in Page
    time.sleep(3)
    es_op = ES_Page.es_breadcrumb()
    assert es_op.text=="Executive Summary / DEFAULT VIEW /","Not in Executive Summary Tab"


def test_ESTopna():
    # Check in Page
    listLegend=ES_Page.EStop_nav()
    time.sleep(5)
    assert listLegend==[['NQ'], ['Signings', 'Signings-ACV'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'Systems w/TPS', 'Cloud & Data Platform', 'Security', 'Cognitive Applications','Watson Health', 'Industry Platforms']],  "Not expected"

## Aggergated Pipeline ####

def test_Aggregated():
    # Check in Page
    time.sleep(5)
    ap_op=AP_Page.Aggregated()
    assert ap_op.text == "Aggregated Pipeline / GEO VIEW /", "Not in Aggregated Pipeline Tab"


def test_aptopnav():
    listLegend=AP_Page.APtop_nav()
    time.sleep(5)
    assert listLegend==[['NQ'], ['Signings', 'Signings-ACV'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'Systems w/TPS', 'Cloud & Data Platform', 'Security', 'Cognitive Applications','Watson Health',  'Industry Platforms'],['UNIT']],"Not expected"

### Segmented Pipeline ####

def test_Segmented():
    # Check in Page
    SP_Page.Segmented_tab()
    sp_op=SP_Page.Segmented_bc()
    assert sp_op.text == "Segmented Pipeline / SUMMARY VIEW /", "Not in Segmented Pipeline Tab"

def test_sptopnav():
    listLegend=SP_Page.SPtop_nav()
    time.sleep(5)
    assert listLegend == [['NQ'], ['Signings', 'Signings-ACV'],['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group','Latin America', 'Middle East & Africa', 'UNASSIGNED'],['All', 'Systems w/TPS', 'Cloud & Data Platform', 'Security', 'Cognitive Applications','Watson Health', 'Industry Platforms'],['CLIENT SET', 'DEAL SIZE', 'CHANNEL','JTC/RHS', 'JTC', 'RHS', 'SOLUTIONS - Strategic Imperatives','INDUSTRY SOLUTIONS', 'OI GROUP']], "Not expected"


### Roadmap ####
def test_Trans_pip():
    RD_Page.Trans_pip()

def test_Roadmap():
    # Check in Page
    rd_op=RD_Page.Roadmap()
    assert rd_op.text == "Trans. Pipeline / ROADMAP / GEO VIEW /", "Not in Roadmap Tab"

def test_RMTopnav():
    listLegend=RD_Page.RMtop_nav()
    assert listLegend== [['NQ'], ['Signings', 'Signings-ACV'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'Systems w/TPS', 'Cloud & Data Platform', 'Security', 'Cognitive Applications','Watson Health', 'Industry Platforms'], ['LIO'], ['BU', 'CLIENT SEGMENT']],"not expected"
    time.sleep(5)


# ### Keydeals ####
def test_KD_Open():
    KD_Page.KD_tab_Click()
    bread_Tooltip_KD = SP_Page.segPipe_breadcrumb()
    print(bread_Tooltip_KD)
    assert bread_Tooltip_KD == "Trans. Pipeline / KEY DEALS / DEFAULT VIEW /", "Not in Key Deals Page"

def test_kdtopnav():
    listLegend=KD_Page.kdtop_nav()
    assert listLegend == [['NQ'], ['Signings', 'Signings-ACV'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'Systems w/TPS', 'Cloud & Data Platform', 'Security', 'Cognitive Applications','Watson Health', 'Industry Platforms'], ['LIO'], ['CLIENT AGGREGATION', 'ALL LINE ITEMS'], ['By BU group', 'By BU Sub group', 'By Level 17', 'By WSR', 'By Dealsize', 'By SAQ', 'By SAQ Quadrant', 'By Market', 'By Branch Group (EBR)', 'By Branch (EBU)', 'By Branch Unit (ESU)', 'By Client Type', 'By Client Sub Type', 'By Client Set', 'By Channel', 'By Reporting Country', 'By Roadmap Status', 'By Close/Bill Week', 'By Close/Bill Month', 'By OI Source', 'By ISU Group', 'By ISU', 'By Geo']],"not expected"
    time.sleep(5)


# ===============================
### Milestone ####
def test_MI_Open():
    MI_Page.MI_tab_Click()
    bread_Tooltip_MI = SP_Page.segPipe_breadcrumb()
    print(bread_Tooltip_MI)
    assert bread_Tooltip_MI == "Trans. Pipeline / MILESTONE / DEFAULT VIEW /", "Not in Milestone Page"


def test_mitopnav():
    listLegend= MI_Page.Mitop_nav()
    assert listLegend == [['NQ'], ['Signings', 'Signings-ACV'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'Systems w/TPS', 'Cloud & Data Platform', 'Security', 'Cognitive Applications', 'Watson Health','Industry Platforms'], ['LIO'], ['ALL LINE ITEMS'], ['Identifying (1)', 'Validated (4)', 'Qualifying (7)', 'Gaining Agreement (6)']], "is not expected"
    time.sleep(5)


def test_Signings():
    sign=Common.revenue_Signings()
    assert sign=="Signings"
    time.sleep(8)

def test_ESTopna_Signing():
    # Check in Page
    driver.find_element_by_xpath(locators.ES).click()
    time.sleep(3)
    listLegend=ES_Page.EStop_nav()
    assert listLegend == [['NQ'], ['Transactional', 'Signings-ACV'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'Global Business Services', 'Global Technology Services', 'Cloud & Data Platform', 'Security']], "Not expected"
    time.sleep(5)

def test_aptopnav_Signings():
    driver.find_element_by_xpath(locators.ap).click()
    time.sleep(3)
    listLegend=AP_Page.APtop_nav()
    time.sleep(5)
    assert listLegend==[['NQ'], ['Transactional', 'Signings-ACV'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'Global Business Services', 'Global Technology Services', 'Cloud & Data Platform', 'Security'], ['UNIT']],"Not expected"

def test_sptopnav_Signings():
    driver.find_element_by_xpath(locators.sp).click()
    time.sleep(3)
    listLegend=SP_Page.SPtop_nav()
    time.sleep(5)
    assert listLegend == [['NQ'], ['Transactional', 'Signings-ACV'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'Global Business Services', 'Global Technology Services', 'Cloud & Data Platform', 'Security'], ['CLIENT SET', 'DEAL SIZE', 'CHANNEL', 'JTC/RHS', 'JTC', 'RHS', 'SOLUTIONS - Strategic Imperatives', 'INDUSTRY SOLUTIONS', 'OI GROUP']], "Not expected"

def test_RMTopnav_Signings():
    driver.find_element_by_xpath(locators.rd).click()
    time.sleep(3)
    listLegend=RD_Page.RMtop_nav()
    assert listLegend== [['NQ'], ['Transactional', 'Signings-ACV'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'Global Business Services', 'Global Technology Services', 'Cloud & Data Platform', 'Security'], ['LIO'], ['BU', 'CLIENT SEGMENT']],"not expected"
    time.sleep(5)

def test_kdtopnav_Signings():
    time.sleep(5)
    driver.find_element_by_xpath(locators.KD_tab).click()
    time.sleep(3)
    listLegend=KD_Page.kdtop_nav()
    assert listLegend == [['NQ'], ['Transactional', 'Signings-ACV'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'Global Business Services', 'Global Technology Services', 'Cloud & Data Platform', 'Security'], ['LIO'], ['CLIENT AGGREGATION', 'ALL LINE ITEMS'], ['By BU group', 'By BU Sub group', 'By Level 17', 'By WSR', 'By Dealsize', 'By SAQ', 'By SAQ Quadrant', 'By Market', 'By Branch Group (EBR)', 'By Branch (EBU)', 'By Branch Unit (ESU)', 'By Client Type', 'By Client Sub Type', 'By Client Set', 'By Channel', 'By Reporting Country', 'By Close/Bill Week', 'By Close/Bill Month', 'By OI Source', 'By ISU Group', 'By ISU', 'By Geo']],"not expected"
    time.sleep(5)

def test_mitopnav_Signings():
    driver.find_element_by_xpath(locators.MI_tab).click()
    time.sleep(3)
    listLegend= MI_Page.Mitop_nav()
    assert listLegend == [['NQ'], ['Transactional', 'Signings-ACV'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'Global Business Services', 'Global Technology Services', 'Cloud & Data Platform', 'Security'], ['LIO'], ['ALL LINE ITEMS'], ['Identifying (1)', 'Validated (4)', 'Qualifying (7)', 'Gaining Agreement (6)']], "is not expected"
    time.sleep(5)

def test_Signings_ACV():
    sign=Common.revenue_Signings_Acv()
    assert sign=="Signings-ACV"
    time.sleep(8)

def test_ESTopna_Signing_ACV():
    # Check in Page
    driver.find_element_by_xpath(locators.ES).click()
    time.sleep(3)
    listLegend=ES_Page.EStop_nav()
    assert listLegend == [['NQ'], ['Transactional', 'Signings'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'Cloud & Data Platform', 'Security', 'Cognitive Applications', 'Watson Health', 'Industry Platforms']], "Not expected"
    time.sleep(5)

def test_aptopnav_Signings_ACV():
    driver.find_element_by_xpath(locators.ap).click()
    time.sleep(3)
    listLegend=AP_Page.APtop_nav()
    time.sleep(5)
    assert listLegend==[['NQ'], ['Transactional', 'Signings'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'Cloud & Data Platform', 'Security', 'Cognitive Applications', 'Watson Health', 'Industry Platforms'], ['UNIT']],"Not expected"


def test_sptopnav_Signings_ACV():
    driver.find_element_by_xpath(locators.sp).click()
    time.sleep(3)
    listLegend=SP_Page.SPtop_nav()
    time.sleep(5)
    assert listLegend == [['NQ'], ['Transactional', 'Signings'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'Cloud & Data Platform', 'Security', 'Cognitive Applications', 'Watson Health', 'Industry Platforms'], ['CLIENT SET', 'DEAL SIZE', 'CHANNEL', 'JTC/RHS', 'JTC', 'RHS', 'SOLUTIONS - Strategic Imperatives', 'INDUSTRY SOLUTIONS', 'OI GROUP']], "Not expected"

def test_RMTopnav_Signings_ACV():
    driver.find_element_by_xpath(locators.rd).click()
    time.sleep(3)
    listLegend=RD_Page.RMtop_nav()
    assert listLegend== [['NQ'], ['Transactional', 'Signings'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'Cloud & Data Platform', 'Security', 'Cognitive Applications', 'Watson Health', 'Industry Platforms'], ['LIO'], ['BU', 'CLIENT SEGMENT']],"not expected"
    time.sleep(5)

def test_kdtopnav_Signings_ACV():
    time.sleep(5)
    driver.find_element_by_xpath(locators.KD_tab).click()
    time.sleep(3)
    listLegend=KD_Page.kdtop_nav()
    assert listLegend == [['NQ'], ['Transactional', 'Signings'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'Cloud & Data Platform', 'Security', 'Cognitive Applications', 'Watson Health', 'Industry Platforms'], ['LIO'], ['CLIENT AGGREGATION', 'ALL LINE ITEMS'], ['By BU group', 'By BU Sub group', 'By Level 17', 'By WSR', 'By Dealsize', 'By SAQ', 'By SAQ Quadrant', 'By Market', 'By Branch Group (EBR)', 'By Branch (EBU)', 'By Branch Unit (ESU)', 'By Client Type', 'By Client Sub Type', 'By Client Set', 'By Channel', 'By Reporting Country', 'By Close/Bill Week', 'By Close/Bill Month', 'By OI Source', 'By ISU Group', 'By ISU', 'By Geo']],"not expected"
    time.sleep(5)

def test_mitopnav_Signings_ACV():
    driver.find_element_by_xpath(locators.MI_tab).click()
    time.sleep(3)
    listLegend= MI_Page.Mitop_nav()
    assert listLegend == [['NQ'], ['Transactional', 'Signings'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'Cloud & Data Platform', 'Security', 'Cognitive Applications', 'Watson Health', 'Industry Platforms'], ['LIO'], ['ALL LINE ITEMS'], ['Identifying (1)', 'Validated (4)', 'Qualifying (7)', 'Gaining Agreement (6)']], "is not expected"
    Common.revenue()
    time.sleep(5)


### Closing ####
def test_close():
    driver.close()

