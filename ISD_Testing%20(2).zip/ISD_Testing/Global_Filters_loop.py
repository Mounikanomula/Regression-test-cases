from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
import re
from selenium.webdriver.common.action_chains import ActionChains
from datetime import date
from datetime import datetime
from datetime import timedelta
import locators
import Login_Page
import Common
import Constants
import string

driver = Login_Page.driver

global Bud_compar
global Scroll_txt

def Global_filter_Loop_KPI():
    Budget_KPI = driver.find_element_by_xpath("//div[text()='BUDGET ']//..//div[@id='tilesDataValue0']")
    Header_txt = driver.find_element_by_xpath("//h4[@class='text-center title']")
    Header_txt_split = Header_txt.text.split(" ")
    Header_txt_split = Header_txt_split[-1]
    if Budget_KPI.text == "N/A":
        print("KPI Tile shows N/A")
        assert Header_txt_split== "PPV", "Graph Header is not showing PPV for the N/A budgets"
    else:

        time.sleep(5)
        filter_clk = driver.find_element_by_xpath("//*[@class='new-filter-icon']")
        filter_clk.click()
        time.sleep(4)
        View_clk = driver.find_element_by_xpath("(//div[@class='filter-headers']//carbon-icon[@name='icon--chevron--down'])[2]")
        View_clk.click()
        View_clk.click()
        View_dpdwn = driver.find_element_by_xpath("//div[@class='searchGroup']//*[@id='bread_GEO']")
        View_dpdwn.click()
        scroll_host = driver.find_elements_by_xpath("//div[@class='ng-dropdown-panel-items scroll-host']")
        # print(scroll_host.text)
        scroll_options = driver.find_elements_by_xpath("//div[@class='ng-dropdown-panel-items scroll-host']//div[@role='option']")
        print("Scroll_optons size is", len(scroll_options))
        time.sleep(2)
        Filter_close = driver.find_element_by_xpath(locators.filter_icon_close)
        Geo_GF = []
        global Scroll_txt
        for i in range(len(scroll_options) - 1):
            time.sleep(5)
            View_clk = driver.find_element_by_xpath("(//div[@class='filter-headers']//carbon-icon[@name='icon--chevron--down'])[2]")
            View_clk.click()
            View_clk.click()
            View_dpdwn = driver.find_element_by_xpath("//div[@class='searchGroup']//*[@id='bread_GEO']")
            View_dpdwn.click()
            scroll_hosts = driver.find_element_by_xpath("//div[@class='ng-dropdown-panel-items scroll-host']//div[@role='option']" + '[' + str(i + 2) + ']')
            # scroll_hosts = driver.find_element_by_xpath("//*[@class='searchGroup']//*[@role='option']" + '[' + str(i + 1) + ']')
            Scroll_txt = scroll_hosts.text

            print("scroll options is", scroll_hosts.text)
            scroll_hosts.click()
            time.sleep(5)
            View_dpdwn = driver.find_element_by_xpath("//div[@class='searchGroup']//*[@id='bread_GEO']")
            View_dpdwn.click()
            Reset_Default = driver.find_element_by_xpath("//button[text()='RESET TO DEFAULT']")
            Filter_close.click()
            action = ActionChains(driver)
            time.sleep(5)
            bar_hover_()




def bar_hover_():

    bar_ele = driver.find_elements_by_xpath("(//h4[@class='text-center title'])[1]//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
    View_dpdwn = driver.find_element_by_xpath("//div[@class='searchGroup']//*[@id='bread_GEO']")
    Clear_icon = driver.find_element_by_xpath("//carbon-dropdown[@id='bread_GEO']//*[@class='ng-clear']")

    Bud_compar= []
    for j in range(len(bar_ele)):
        #     # if highlight.text==scroll_hosts.text:
        # global Bud_compar
        action = ActionChains(driver)
        highlight = driver.find_element_by_xpath("(//h4[@class='text-center title'])[1]//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
        print("highlighted bar is", highlight.text)
        time.sleep(2)
        action.move_to_element(bar_ele[j]).perform()
        time.sleep(2)
        tooltip = driver.find_element_by_xpath("//*[name()='ngx-tooltip-content']")
        action.move_to_element(tooltip)
        print(tooltip.text)
        time.sleep(2)
        if tooltip.text== "N/A":
            print("Bars has no budget which shows N/A")

        else:
            Geo_split = tooltip.text.split("\n")
            Geo_split = Geo_split[2]
            Geo_split = Geo_split.replace(",", "")
            Trim_budget = re.findall(r'[0-9]+[.]?[0-9]+',Geo_split)
            print("Trim Budget is ", Trim_budget)
            Trim_budget = Trim_budget[0]
            Trim_budget = round(float(Trim_budget))
            print("Budget for "+str(Scroll_txt)+"::  " + str(Trim_budget) + " " )
            Budget_KPI = driver.find_element_by_xpath("//div[text()='BUDGET ']//..//div[@id='tilesDataValue0']")
            Budget_KPI_txt = Budget_KPI.text
            KPI_split = Budget_KPI_txt.replace(",", "")
            Trim_budget_KPI = re.findall('\d*\.?\d+', KPI_split)
            Trim_budget_KPI = Trim_budget_KPI[0]

            diff = abs(float(Trim_budget) - float(Trim_budget_KPI))
            print("Difference of bar values vs KPI value is " + format(diff, '.2f'))

            assert Trim_budget!=Trim_budget_KPI, ("Mismatch between bar value vs KPi value " + format(diff, '.2f'))

            filter_clk = driver.find_element_by_xpath("//*[@class='new-filter-icon']")
            filter_clk.click()
            time.sleep(2)
            View_dpdwn.click()
            time.sleep(2)
            driver.find_element_by_xpath("//*[@id='bread_GEO']//span[@class='ng-arrow-wrapper']").click()
            driver.find_element_by_xpath("//*[@id='bread_GEO']//span[@class='ng-arrow-wrapper']").click()
            driver.find_element_by_xpath("//*[@id='bread_GEO']//span[@class='ng-arrow-wrapper']").click()
            time.sleep(3)
            Reset_Default = driver.find_element_by_xpath("//button[text()='RESET TO DEFAULT']")
            Reset_Default.click()
            time.sleep(3)
            Filter_close = driver.find_element_by_xpath(locators.filter_icon_close)
            Filter_close.click()
            time.sleep(3)
            filter_clk.click()


Login_Page.open_ISD()

# driver.set_page_load_timeout(20)
# driver.implicitly_wait(15)
time.sleep(5)
# GF_click()
Global_filter_Loop_KPI()