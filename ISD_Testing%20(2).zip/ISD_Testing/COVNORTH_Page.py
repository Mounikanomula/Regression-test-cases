from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
import re
from selenium.webdriver.common.action_chains import ActionChains
from datetime import date
from datetime import datetime
from datetime import timedelta


import locators
import Login_Page
import Common
import Constants
import SP_Page
import ES_Page
import RD_Page

# import Wkly_Build_WSR_KPI

driver = Login_Page.driver

# Drilldown to EBR and Drill up one level at a time
def DrillDown_UP_one_level():
    GH1= driver.find_elements_by_xpath(locators.ES_Graph1_1_Cov)
    s=len(GH1)
    det=Common.getlist()
    print("Geo "+str(det))
    P_ok=det[0]
    # print(P_ok)
    for i in P_ok:
        time.sleep(5)
        GH1= driver.find_elements_by_xpath(locators.ES_Graph1_1_Cov)
        print(i)
        ActionChains(driver).move_to_element(GH1[i]).perform()
        time.sleep(5)
        CL= driver.find_elements_by_xpath(locators.Drilldown)
        print(i)
        print(type(i))
        ActionChains(driver).click(CL[i]).perform()
        time.sleep(5)
        print("DrillDown to Market")
        det1=Common.getlist()
        print("Market: "+str(det1))
        P_ok1=det1[0]
        for j in P_ok1:
            time.sleep(5)
            DD1= driver.find_elements_by_xpath(locators.ES_Graph1_1_Cov1)
            ActionChains(driver).move_to_element(DD1[j]).perform()
            time.sleep(5)
            CL= driver.find_elements_by_xpath(locators.Drilldown)
            print(j)
            print(type(j))
            ActionChains(driver).click(CL[j]).perform()
            time.sleep(5)
            print("DrillDown to EBR")
            break
        driver.find_element_by_xpath(locators.DrillUP).click()
        time.sleep(5)
        print("DrillUP to Market")
        break
    driver.find_element_by_xpath(locators.DrillUP).click()
    print("DrillUP to Geo")

def G3_Budget_WSR_WON():
    # Budget,WSR and WON in first 3-4 graphs
    B = []
    WS = []
    WN = []
    bud=""
    wsr=""
    won=""
    ESKPI = ES_Page.ES_KPI()
    for j in [3]:
        driver.find_element_by_xpath(locators.max1 + '[' + str(j) + ']').click()
        driver.find_element_by_xpath(locators.showhide).click()
        tx = driver.find_elements_by_xpath(locators.firstrow) # gives the total number of Rows in the table
        print(len(tx))
        t = 0
        t2 = 0
        t3 = 0
        for i in range(len(tx)):
            tx = driver.find_element_by_xpath('(' + locators.firstrow + ')' + '[' + str(i + 1) + ']').text
            tx = tx.split('\n')
            if (len(tx)) < 15:
                tx.insert(0, "N/A")
                # print(tx)
            else:
                print(tx)
            tx1 = tx[1].replace(",", "")
            tx1 = float(tx1) if tx1 != "N/A" else 0
            t = t + tx1
            tx2 = tx[3].replace(",", "")
            tx2 = float(tx2) if tx2 != "N/A" else 0
            t2 = t2 + tx2
            tx3 = tx[10].replace(",", "")
            tx3 = float(tx3) if tx3 != "N/A" else 0
            t3 = t3 + tx3
        #     print("Budget Graph"+str(j+1)+" : "+str(t)) # give values in list
        print("Sum Budget Graph_" + str(j) + " : " + str(t))
        B.append(round(t))
        #     print("PPV Graph"+str(j+1)+" : "+str(t2)) # give values in list
        print("Sum WSR Graph_" + str(j) + " : " + str(t2))
        WS.append(round(t2))
        print("Sum WON Graph_" + str(j) + " : " + str(t3))
        WN.append(round(t3))
        driver.find_element_by_xpath(locators.showhide).click()
        driver.find_element_by_xpath(locators.min1).click()
    print(B, WS, WN)
    if ESKPI[0] != B[0]:
        bud = "Budget not matching for Graph3"
    if ESKPI[2] != WS[0]:
        wsr = "WSR not matching for Graph3"
    # if ESKPI[7] != WN[0]:
    #     won = "WON not matching for Graph3"
    print(bud, wsr,won)
    assert ((bud != "Budget not matching for Graph3") & (
            wsr != "WSR not matching for Graph3")), "Budget or WSR not matching for Graph3"

def G2_Budget_QTD_Actuals():
    print("Hello")
    B = []
    Q = []
    bud=""
    qtd=""
    ESKPI = ES_Page.ES_KPI()
    print("Hello")
    # for j in range(2):
    for j in [2]:
        print(("Hello"))
        # driver.find_element_by_xpath(locators.max1 + '[' + str(j + 1) + ']').click()
        driver.find_element_by_xpath(locators.max1_1 + '[' + str(j) + ']').click()
        driver.find_element_by_xpath(locators.showhide).click()
        tx = driver.find_elements_by_xpath(locators.firstrow) # gives the total number of Rows in the table
        print(len(tx))
        t = 0
        t2 = 0
        for i in range(len(tx)):
            tx = driver.find_element_by_xpath('(' + locators.firstrow + ')' + '[' + str(i + 1) + ']').text
            tx = tx.split('\n')
            if (len(tx)) < 5:
                tx.insert(0, "N/A")
                # print(tx)
            else:
                print(tx)
            tx1 = tx[1].replace(",", "")
            tx1 = float(tx1) if tx1 != "N/A" else 0  #Inline if Function
            t = t + tx1
            tx2 = tx[3].replace(",", "")
            tx2 = float(tx2) if tx2 != "N/A" else 0
            t2 = t2 + tx2
        #     print("Budget Graph"+str(j+1)+" : "+str(t)) # give values in list
        print("Sum Budget Graph_" + str(j) + " : " + str(t))
        B.append(round(t))
        #     print("PPV Graph"+str(j+1)+" : "+str(t2)) # give values in list
        print("Sum QTD Actuals Graph_" + str(j) + " : " + str(t2))
        Q.append(round(t2))
        driver.find_element_by_xpath(locators.showhide).click()
        driver.find_element_by_xpath(locators.min1).click()
    print(B, Q)
    if ESKPI[0] != B[0]:
        bud = "Budget not matching for Graph2"
    # if ESKPI[1] != Q[0]:
    #     qtd = "QTD Actuals not matching for Graph2"
    # print(bud, qtd)
    assert ((bud != "Budget not matching for Graph2")), "Budget not matching for Graph2"

def G1_Budget_PPV():
    B = []
    P = []
    G=[]
    bud=""
    ppv=""
    geo=""
    ESKPI = ES_Page.ES_KPI()
    # print(ESKPI)
    for j in [1]:
    # for j in [2]:
    #     driver.find_element_by_xpath(locators.max1 + '[' + str(j + 1) + ']').click()
        driver.find_element_by_xpath(locators.max1 + '[' + str(j) + ']').click()
        driver.find_element_by_xpath(locators.showhide).click()
        tx = driver.find_elements_by_xpath(locators.firstrow) # gives the total number of Rows in the table
        print(len(tx))
        t = 0
        t2 = 0
        for i in range(len(tx)):
            tx = driver.find_element_by_xpath('(' + locators.firstrow + ')' + '[' + str(i + 1) + ']').text
            tx = tx.split('\n')
            # print(tx)
            if(len(tx))<18:
                tx.insert(0,"N/A")
                # print(tx)
            else:
                print(tx)
            tx1 = tx[1].replace(",", "")
            tx1 = float(tx1) if tx1 != "N/A" else 0  #Inline if Function
            t = t + tx1
            tx2 = tx[3].replace(",", "")
            tx2 = float(tx2) if tx2 != "N/A" else 0
            t2 = t2 + tx2
            tx3=tx[0]
            G.append(tx3)

        #     print("Budget Graph"+str(j+1)+" : "+str(t)) # give values in list
        print("Sum Budget Graph_" + str(j) + " : " + str(t))
        B.append(round(t))
        #     print("PPV Graph"+str(j+1)+" : "+str(t2)) # give values in list
        print("Sum PPV Graph_" + str(j) + " : " + str(t2))
        P.append(round(t2))
        print("Geo :"+str(G))
        driver.find_element_by_xpath(locators.showhide).click()
        driver.find_element_by_xpath(locators.min1).click()
    print(B, P,G)
    if ESKPI[0] != B[0]:
        bud = "Budget not matching for Graph1"
    if ESKPI[3] != P[0]:
        ppv = "PPV not matching for Graph1"
    if Constants.EBU_List!=G:
        geo="Geo not matching"
    print(bud, ppv,geo)
    assert ((bud != "Budget not matching for Graph1") & (
                ppv != "PPV not matching for Graph1")& (
                geo != "Geo not matching")), "Budget or PPV or Geo_list not matching for Graph1"

def G4_Budget_WSR():
    B = []
    W = []
    bud=""
    wsr=""
    ESKPI = ES_Page.ES_KPI()
    # for j in range(2):
    for j in [4]:
        # driver.find_element_by_xpath(locators.max1 + '[' + str(j + 1) + ']').click()
        driver.find_element_by_xpath(locators.max1 + '[' + str(j) + ']').click()
        driver.find_element_by_xpath(locators.showhide).click()
        tx = driver.find_elements_by_xpath(locators.firstrow) # gives the total number of Rows in the table
        print(len(tx))
        t = 0
        t2 = 0
        # for i in range(len(tx)):
        tx = driver.find_element_by_xpath('(' + locators.firstrow + ')' + '[' + str(3) + ']').text
        tx = tx.split('\n')
        tx1 = tx[1].replace(",", "")
        tx1 = float(tx1) if tx1 != "N/A" else 0  #Inline if Function
            # t = t + tx1
            # tx2 = tx[4].replace(",", "")
            # tx2 = float(tx2) if tx2 != "N/A" else 0
            # t2 = t2 + tx2
        tx2 = driver.find_element_by_xpath('(' + locators.firstrow + ')' + '[' + str(3) + ']').text
        tx2 = tx2.split('\n')
        tx2 = tx[4].replace(",", "")
        tx2 = float(tx2) if tx2 != "N/A" else 0  # Inline if Function
        #     print("Budget Graph"+str(j+1)+" : "+str(t)) # give values in list
        print("Budget Graph_" + str(j) + " : " + str(tx1))
        B.append(round(tx1))
        #     print("PPV Graph"+str(j+1)+" : "+str(t2)) # give values in list
        print("WSR Graph_" + str(j) + " : " + str(tx2))
        W.append(round(tx2))
        driver.find_element_by_xpath(locators.showhide).click()
        driver.find_element_by_xpath(locators.min1).click()
    print(B, W)
    if ESKPI[0] != B[0]:
        bud = "Budget not matching for Graph4"
    if ESKPI[2] != W[0]:
        wsr = "WSR not matching for Graph4"
    print(bud, wsr)
    assert ((bud != "Budget not matching for Graph4") & (
            wsr != "WSR not matching for Graph4")), "Budget or WSR not matching for Graph4"

def WSR_KPI_DF_Grp():
    time.sleep(5)
    WSR_block = driver.find_element_by_xpath(locators.WSR1)
    print(WSR_block.text)
    global WSR_Val
    WSR_Val=Common.es_kpi1(WSR_block)
    print(WSR_Val)
    print("WSR is " + str(WSR_Val))
    WSR_block.click()
    time.sleep(3)
    WSR_group_default = driver.find_element_by_xpath(locators.Def_Grp)
    print(WSR_group_default.text)
    assert WSR_group_default.text == "By Roadmap Status", "Default Group for WSR is incorrect"
    # return VP_Val,Vp_group_default

def WSR_KPI_vs_Summary_DealList():
    # print(VP_Val)
    time.sleep(5)
    WSR_Summary_header = driver.find_element_by_xpath(locators.Summary_deal_header_val)
    global WSR_Deal_value_2
    WSR_Deal_value_2 = WSR_Summary_header.text.replace(",", "")
    WSR_Deal_value_2 = re.findall(r'[0-9]+[.]?[0-9]+', WSR_Deal_value_2)
    WSR_Deal_value_2 = WSR_Deal_value_2[0]

    print("Summary header lineitem Value for WSR click is " + str(WSR_Deal_value_2))
    diff = abs(float(WSR_Val) - float(WSR_Deal_value_2))
    print("Difference of WSR Kpi vs Deallist line item value is " + format(diff, '.2f'))
    assert diff<1,"Mismatch between WSR KPI value and WSR Click Deallist Line item Value"

def WSR_KPI_Summary_DealList_vs_Sum_Detailed_List():
    time.sleep(5)
    Detailed_list = driver.find_elements_by_css_selector(locators.Detailed_list)
    summary = []
    for i in range(len(Detailed_list)):
        Detailed_list_value = Detailed_list[i].text
        Detailed_list_value = Detailed_list_value.replace(",", "")
        Detailed_list_value = re.findall(r'[0-9]+[.]?[0-9]+', Detailed_list_value)
        Detailed_list_value = Detailed_list_value[0]
        print(Detailed_list_value)
        summary.append(float(Detailed_list_value))

    # print(summary)
    sum_summary = sum(summary)
    print("All WSR Deal list sum is " + str(sum_summary))

    diff_dealvSummaryLI = abs(float(sum_summary) - float(WSR_Deal_value_2))
    print("Difference of WSR Deal listsum vs Deallist line item value is " + format(diff_dealvSummaryLI, '.2f'))
    time.sleep(3)
    Common.common_Close_dealList()
    assert diff_dealvSummaryLI < 1, "Mismatch between WSR KPI Click Deallist Line item Value and Sum of Detailed Deal list"

def WON_KPI_DF_Grp():
    time.sleep(5)
    WON_block = driver.find_element_by_xpath(locators.WON3)
    print(WON_block.text)
    global WON_Val
    WON_Val=Common.es_kpi1(WON_block)
    print(WON_Val)
    print("WON is " + str(WON_Val))
    WON_block.click()
    time.sleep(3)
    WON_group_default = driver.find_element_by_xpath(locators.Def_Grp)
    print(WON_group_default.text)
    assert WON_group_default.text == "By Roadmap Status", "Default Group for WON is incorrect"

def WON_KPI_vs_Summary_DealList():
    # print(VP_Val)
    time.sleep(5)
    WON_Summary_header = driver.find_element_by_xpath(locators.Summary_deal_header_val)
    global WON_Deal_value_2
    WON_Deal_value_2 = WON_Summary_header.text.replace(",", "")
    WON_Deal_value_2 = re.findall(r'[0-9]+[.]?[0-9]+', WON_Deal_value_2)
    WON_Deal_value_2 = WON_Deal_value_2[0]

    print("Summary header lineitem Value for WON click is " + str(WON_Deal_value_2))
    diff = abs(float(WON_Val) - float(WON_Deal_value_2))
    print("Difference of WON Kpi vs Deallist line item value is " + format(diff, '.2f'))
    assert diff<1,"Mismatch between WON KPI value and WON Click Deallist Line item Value"

def WON_KPI_Summary_DealList_vs_Sum_Detailed_List():
    time.sleep(5)
    Detailed_list = driver.find_elements_by_css_selector(locators.Detailed_list)
    summary = []
    for i in range(len(Detailed_list)):
        Detailed_list_value = Detailed_list[i].text
        Detailed_list_value = Detailed_list_value.replace(",", "")
        Detailed_list_value = re.findall(r'[0-9]+[.]?[0-9]+', Detailed_list_value)
        Detailed_list_value = Detailed_list_value[0]
        print(Detailed_list_value)
        summary.append(float(Detailed_list_value))

    # print(summary)
    sum_summary = sum(summary)
    print("All WON Deal list sum is " + str(sum_summary))

    diff_dealvSummaryLI = abs(float(sum_summary) - float(WON_Deal_value_2))
    print("Difference of WON Deal listsum vs Deallist line item value is " + format(diff_dealvSummaryLI, '.2f'))
    time.sleep(3)
    Common.common_Close_dealList()
    assert diff_dealvSummaryLI < 1, "Mismatch between WON KPI Click Deallist Line item Value and Sum of Detailed Deal list"


def VP_KPI_DF_Grp():
    time.sleep(5)
    Vp_block = driver.find_element_by_xpath(locators.VP3)
    print(Vp_block.text)
    global VP_Val
    VP_Val=Common.es_kpi1(Vp_block)
    print(VP_Val)
    print("VP is " + str(VP_Val))
    Vp_block.click()
    time.sleep(3)
    Vp_group_default = driver.find_element_by_xpath(locators.Def_Grp)
    print(Vp_group_default.text)
    assert Vp_group_default.text == "By Sales Stage", "Default Group for VP is incorrect"


def VP_KPI_vs_Summary_DealList():
    # print(VP_Val)
    time.sleep(5)
    Vp_Summary_header = driver.find_element_by_xpath(locators.Summary_deal_header_val)
    global Vp_Deal_value_2
    Vp_Deal_value_2 = Vp_Summary_header.text.replace(",", "")
    Vp_Deal_value_2 = re.findall(r'[0-9]+[.]?[0-9]+', Vp_Deal_value_2)
    Vp_Deal_value_2 = Vp_Deal_value_2[0]

    print("Summary header lineitem Value for VP click is " + str(Vp_Deal_value_2))
    diff = abs(float(VP_Val) - float(Vp_Deal_value_2))
    print("Difference of Kpi vs Deallist line item value is " + format(diff, '.2f'))
    assert diff<1,"Mismatch between VP KPI value and VP Click Deallist Line item Value"

def VP_KPI_Summary_DealList_vs_Sum_Detailed_List():
    time.sleep(5)
    Detailed_list = driver.find_elements_by_css_selector(locators.Detailed_list)
    summary = []
    for i in range(len(Detailed_list)):
        Detailed_list_value = Detailed_list[i].text
        Detailed_list_value = Detailed_list_value.replace(",", "")
        Detailed_list_value = re.findall(r'[0-9]+[.]?[0-9]+', Detailed_list_value)
        Detailed_list_value = Detailed_list_value[0]
        print(Detailed_list_value)
        summary.append(float(Detailed_list_value))

    # print(summary)
    sum_summary = sum(summary)
    print("All VP Deal list sum is " + str(sum_summary))

    diff_dealvSummaryLI = abs(float(sum_summary) - float(Vp_Deal_value_2))
    print("Difference of VP Deal listsum vs Deallist line item value is " + format(diff_dealvSummaryLI, '.2f'))
    time.sleep(3)
    Common.common_Close_dealList()
    assert diff_dealvSummaryLI < 1, "Mismatch between VP KPI Click Deallist Line item Value and Sum of Detailed Deal list"

# Drilldown to EBR and Drill up Top level
def DrillDown_UP_Top_level():
    driver.find_element_by_xpath(locators.ES).click()
    time.sleep(10)
    GH1= driver.find_elements_by_xpath(locators.ES_Graph1_1_Cov)
    s=len(GH1)
    det=Common.getlist()
    print("Branch EBU "+str(det))
    P_ok=det[0]
    for i in P_ok:
        time.sleep(5)
        GH1= driver.find_elements_by_xpath(locators.ES_Graph1_1_Cov)
        print(i)
        time.sleep(5)
        ActionChains(driver).move_to_element(GH1[i]).perform()
        time.sleep(5)
        CL= driver.find_elements_by_xpath(locators.Drilldown)
        print(i)
        print(type(i))
        ActionChains(driver).click(CL[i]).perform()
        time.sleep(5)
        print("DrillDown to Branch ESU")
        det1=Common.getlist()
        print("Branch ESU: "+str(det1))
        P_ok1=det1[0]
        for j in P_ok1:
            time.sleep(5)
            DD1= driver.find_elements_by_xpath(locators.ES_Graph1_1_Cov1)
            ActionChains(driver).move_to_element(DD1[j]).perform()
            time.sleep(5)
            CL= driver.find_elements_by_xpath(locators.Drilldown)
            print(j)
            print(type(j))
            ActionChains(driver).click(CL[j]).perform()
            time.sleep(5)
            print("DrillDown to ICL")
            break
        break
    driver.find_element_by_xpath(locators.DrillTop).click()
    print("DrillTOP to Branch EBU")

def EStop_nav():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle=driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    time.sleep(2)
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :"+str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-1):
        time.sleep(2)
        GH1[i].click()
        time.sleep(2)
        Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
        print(Topnav.text)
        listLegend1.append(Topnav.text)
        driver.find_element_by_xpath(locators.dropdown_wrapper2).click()
    # print(listLegend1)
    for i in listLegend1:
            listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    assert listLegend2==[['NQ'], ['Signings', 'Signings-ACV'], ['All', 'CA Commercial', 'CA E&C Quebec EBU', 'CA Entrp Atlantic & Ontar EBU', 'CA Entrp Caribbean North EBU', 'CA Entrp West EBU', 'CA IA - Air Canada', 'CA IA - Royal Bank of Canada', 'CA IA - ScotiaBank', 'CA IA - Toronto Dominion Bank', 'CA Industry - Communications', 'CA Industry - Federal', 'CA Industry - Financial Serv', 'CA Industry - Govt of Ontario', 'Canada Default'], ['All', 'Systems w/TPS', 'Cloud & Data Platform', 'Security', 'Cognitive Applications', 'Watson Health','Industry Platforms']],  "Not expected"
    return listLegend2


def APtop_nav():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle=driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    time.sleep(2)
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :"+str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-2):
    # for i in [0,2,3,4]:
        try:
            # print(i)
            time.sleep(2)
            GH1[i].click()
            time.sleep(2)
            Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
            print(Topnav.text)
            listLegend1.append(Topnav.text)
            driver.find_element_by_xpath(locators.dropdown_wrapper2).click()
        except(RuntimeError, TypeError, NameError, Exception):
            print("Top Nav failed for : "+str(i))
            print("Not Clickable")
            pass
    # print(listLegend1)
    for i in listLegend1:
            listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    assert listLegend2==[['NQ'], ['Signings', 'Signings-ACV'], ['All', 'CA Commercial', 'CA E&C Quebec EBU', 'CA Entrp Atlantic & Ontar EBU', 'CA Entrp Caribbean North EBU', 'CA Entrp West EBU', 'CA IA - Air Canada', 'CA IA - Royal Bank of Canada', 'CA IA - ScotiaBank', 'CA IA - Toronto Dominion Bank', 'CA Industry - Communications', 'CA Industry - Federal', 'CA Industry - Financial Serv', 'CA Industry - Govt of Ontario', 'Canada Default'], ['All', 'Systems w/TPS', 'Cloud & Data Platform', 'Security', 'Cognitive Applications', 'Watson Health','Industry Platforms'], ['UNIT']],"Not expected"
    return listLegend2



def loop_view(): #lopping accross views opts and coming back to summary view. Checking with KPI's, failing for Dealsize,Channel Budget graph1 not mathcing as 0,for INDUSTRY SOLUTIONS - Budget and VP not matching as 0
    bp_res = ""
    vpqp_res=""
    vpG4_res=""
    driver.find_element_by_xpath(locators.filter_icon).click()
    driver.find_element_by_xpath(locators.sp_view2).click()
    lb=driver.find_elements_by_xpath(locators.sp_view_count)
    len(lb)
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    time.sleep(10)
    for i in range(len(lb)):
        driver.find_element_by_xpath(locators.sp).click()
        driver.find_element_by_xpath(locators.filter_icon).click()
        driver.find_element_by_xpath(locators.sp_view2).click()
        option=driver.find_element_by_xpath('(' + locators.sp_view_opt + ')' + "[" + str(i + 1) + "]").text
        print("View: "+option)
        time.sleep(3)
        driver.find_element_by_xpath('(' + locators.sp_view_opt_clk + ')'+"["+str(i+1)+"]").click()
        driver.find_element_by_xpath(locators.filter_icon_close).click()
        time.sleep(5)
        Common.Graphs()
        kpi = SP_Page.SP_KPI()
        if option!="SOLUTIONS - Strategic Imperatives":
            bp=SP_Page.Budget_PPV()
            # print(kpi[0])
            # print(kpi[1])
            # print(bp[0][0])
            # print(bp[1][0])
            if (kpi[0]!=bp[0][0]) or (kpi[1]!=bp[1][0]):
                bp_res="Budget or PPV not matching for Graph1"
                print(bp_res)
            # SP_KPI()
            vpqp=SP_Page.VP_QP()
            # print(kpi[4])
            # print(vpqp[0])
            # print(kpi[5])
            # print(vpqp[1])
            if (kpi[4]!=vpqp[0]) or (kpi[5]!=vpqp[1]):
                vpqp_res="VP Graph2 or QP Graph3 not matching"
                print(vpqp_res)
            # SP_KPI()
            vpG4=SP_Page.VP_graph4()
            # print(kpi[4])
            # print(vpG4[0])
            if kpi[4]!=vpG4[0]:
                vpG4_res="VP not matching for Graph4"
                print(vpG4_res)
        else:
            print("At present Not checking for the view : SOLUTIONS - Strategic Imperatives")
            pass
            # SP_KPI()
    #     time.sleep(5)
    #     print(driver.find_element_by_xpath("(//*[@class='ng-value-label ng-star-inserted'])[3]").text) # after clicking get the text

    driver.find_element_by_xpath(locators.filter_icon).click()
    driver.find_element_by_xpath(locators.sp_view2).click()
    time.sleep(8)
    driver.find_element_by_xpath('(' + locators.sp_view_sum_clck+ ')'+"["+str(1)+"]").click()
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    time.sleep(10)
    print(bp_res,vpqp_res,vpG4_res)
    return bp_res,vpqp_res,vpG4_res


def aggPipe_GraphOne_Title_BU():
    global agg_GrOne_Title
    budgetVerify = driver.find_element_by_xpath(locators.common_KPI_Budget_Val).text
    print(budgetVerify)
    if budgetVerify != 'N/A':
        agg_GrOne_Title = driver.find_element_by_xpath(locators.agg_GraphOne_Title_BUCov)
    elif budgetVerify == 'N/A':
        agg_GrOne_Title = driver.find_element_by_xpath(locators.agg_GraphOne_Title_BUPPV)
    print(agg_GrOne_Title.text)
    print(agg_GrOne_Title.text)
    return agg_GrOne_Title


def AP_KPI():
    APKPI=Common.KPI()
    # del APKPI[5]
    del APKPI[1:13]
    del APKPI[7:len(APKPI)]
    print(APKPI)
    return APKPI


def SPtop_nav():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle=driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    time.sleep(2)
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :"+str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)):
        time.sleep(2)
        GH1[i].click()#segPipe_KPI_Labels()
        time.sleep(2)
        Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
        print(Topnav.text)
        listLegend1.append(Topnav.text)
        driver.find_element_by_xpath(locators.dropdown_wrapper2).click()
    # print(listLegend1)
    for i in listLegend1:
            listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    assert listLegend2 == [['NQ'], ['Signings', 'Signings-ACV'], ['All', 'CA Commercial', 'CA E&C Quebec EBU', 'CA Entrp Atlantic & Ontar EBU', 'CA Entrp Caribbean North EBU', 'CA Entrp West EBU', 'CA IA - Air Canada', 'CA IA - Royal Bank of Canada', 'CA IA - ScotiaBank', 'CA IA - Toronto Dominion Bank', 'CA Industry - Communications', 'CA Industry - Federal', 'CA Industry - Financial Serv', 'CA Industry - Govt of Ontario', 'Canada Default'], ['All', 'Systems w/TPS', 'Cloud & Data Platform', 'Security', 'Cognitive Applications', 'Watson Health', 'Industry Platforms'], ['CLIENT SET', 'DEAL SIZE', 'CHANNEL', 'JTC/RHS', 'JTC', 'RHS', 'SOLUTIONS - Strategic Imperatives', 'INDUSTRY SOLUTIONS', 'OI GROUP']],"Not expected"



def QP_KPI_DF_Grp():
    QP_block = driver.find_element_by_xpath(locators.QP3)
    print(QP_block.text)
    global QP_Val
    QP_Val=Common.es_kpi1(QP_block)
    print(QP_Val)
    print("QP is " + str(QP_Val))
    QP_block.click()
    time.sleep(3)
    QP_group_default = driver.find_element_by_xpath(locators.Def_Grp)
    print(QP_group_default.text)
    assert QP_group_default.text == "By Sales Stage", "Default Group for QP is incorrect"
    # return VP_Val,Vp_group_default

def QP_KPI_vs_Summary_DealList():
    # print(VP_Val)
    QP_Summary_header = driver.find_element_by_xpath(locators.Summary_deal_header_val)
    global QP_Deal_value_2
    QP_Deal_value_2 = QP_Summary_header.text.replace(",", "")
    QP_Deal_value_2 = re.findall(r'[0-9]+[.]?[0-9]+', QP_Deal_value_2)
    QP_Deal_value_2 = QP_Deal_value_2[0]

    print("Summary header lineitem Value for QP click is " + str(QP_Deal_value_2))
    diff = abs(float(QP_Val) - float(QP_Deal_value_2))
    print("Difference of QP Kpi vs Deallist line item value is " + format(diff, '.2f'))
    assert diff<1,"Mismatch between QP KPI value and QP Click Deallist Line item Value"

def QP_KPI_Summary_DealList_vs_Sum_Detailed_List():
    Detailed_list = driver.find_elements_by_css_selector(locators.Detailed_list)
    summary = []
    for i in range(len(Detailed_list)):
        Detailed_list_value = Detailed_list[i].text
        Detailed_list_value = Detailed_list_value.replace(",", "")
        Detailed_list_value = re.findall(r'[0-9]+[.]?[0-9]+', Detailed_list_value)
        Detailed_list_value = Detailed_list_value[0]
        print(Detailed_list_value)
        summary.append(float(Detailed_list_value))

    # print(summary)
    sum_summary = sum(summary)
    print("All QP Deal list sum is " + str(sum_summary))

    diff_dealvSummaryLI = abs(float(sum_summary) - float(QP_Deal_value_2))
    print("Difference of QP Deal listsum vs Deallist line item value is " + format(diff_dealvSummaryLI, '.2f'))
    time.sleep(3)
    Common.common_Close_dealList()
    assert diff_dealvSummaryLI < 1, "Mismatch between QP KPI Click Deallist Line item Value and Sum of Detailed Deal list"

def kdtop_nav():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle = driver.find_element_by_xpath(locators.MoveElementkd)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :" + str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-8):
        try:
            time.sleep(2)
            GH1[i].click()
            time.sleep(2)
            Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
            print(Topnav.text)
            listLegend1.append(Topnav.text)
            driver.find_element_by_xpath(locators.dropdown_wrapper2).click()
        except(RuntimeError, TypeError, NameError, Exception):
            print("Top Nav failed for : "+str(i))
            print("Not Clickable")
            pass
    for i in listLegend1:
        listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    time.sleep(5)
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    assert listLegend2 == [['NQ'], ['Signings', 'Signings-ACV'], ['All', 'CA Commercial', 'CA E&C Quebec EBU', 'CA Entrp Atlantic & Ontar EBU', 'CA Entrp Caribbean North EBU', 'CA Entrp West EBU', 'CA IA - Air Canada', 'CA IA - Royal Bank of Canada', 'CA IA - ScotiaBank', 'CA IA - Toronto Dominion Bank', 'CA Industry - Communications', 'CA Industry - Federal', 'CA Industry - Financial Serv', 'CA Industry - Govt of Ontario', 'Canada Default'], ['All', 'Systems w/TPS', 'Cloud & Data Platform', 'Security', 'Cognitive Applications', 'Watson Health','Industry Platforms'], ['LIO'], ['CLIENT AGGREGATION', 'ALL LINE ITEMS'], ['By BU group', 'By BU Sub group', 'By Level 17', 'By WSR', 'By Dealsize', 'By SAQ', 'By SAQ Quadrant', 'By Market', 'By Branch Group (EBR)', 'By Branch (EBU)', 'By Branch Unit (ESU)', 'By Client Type', 'By Client Sub Type', 'By Client Set', 'By Channel', 'By Reporting Country', 'By Roadmap Status', 'By Close/Bill Week', 'By Close/Bill Month', 'By OI Source', 'By ISU Group', 'By ISU']],  "not expected"
    return listLegend2

def RMtop_nav():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle = driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    # driver.find_element_by_xpath(locators.RMTab).click()
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :" + str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-4):
        try:
            time.sleep(2)
            GH1[i].click()
            time.sleep(2)
            Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
            print(Topnav.text)
            listLegend1.append(Topnav.text)
            driver.find_element_by_xpath(locators.dropdown_wrapper2).click()
        except(RuntimeError, TypeError, NameError, Exception):
            print("Top Nav failed for : "+str(i))
            print("Not Clickable")
            pass
    for i in listLegend1:
        listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    assert listLegend2 == [['NQ'], ['Signings', 'Signings-ACV'], ['All', 'CA Commercial', 'CA E&C Quebec EBU', 'CA Entrp Atlantic & Ontar EBU', 'CA Entrp Caribbean North EBU', 'CA Entrp West EBU', 'CA IA - Air Canada', 'CA IA - Royal Bank of Canada', 'CA IA - ScotiaBank', 'CA IA - Toronto Dominion Bank', 'CA Industry - Communications', 'CA Industry - Federal', 'CA Industry - Financial Serv', 'CA Industry - Govt of Ontario', 'Canada Default'], ['All', 'Systems w/TPS', 'Cloud & Data Platform', 'Security', 'Cognitive Applications', 'Watson Health', 'Industry Platforms'], ['LIO'], ['BU', 'CLIENT SEGMENT']], "not expected"
    return listLegend2

def Mitop_nav():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle = driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :" + str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-4):
        try:
            time.sleep(2)
            GH1[i].click()
            time.sleep(2)
            Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
            print(Topnav.text)
            listLegend1.append(Topnav.text)
            driver.find_element_by_xpath(locators.dropdown_wrapper2).click()
        except(RuntimeError, TypeError, NameError, Exception):
            print("Top Nav failed for : "+str(i))
            print("Not Clickable")
            pass
    for i in listLegend1:
        listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    time.sleep(3)
    driver.find_element_by_xpath(locators.common_GlobalFilterXicon).click()
    assert listLegend2 == [['NQ'], ['Signings', 'Signings-ACV'], ['All', 'CA Commercial', 'CA E&C Quebec EBU', 'CA Entrp Atlantic & Ontar EBU', 'CA Entrp Caribbean North EBU', 'CA Entrp West EBU', 'CA IA - Air Canada', 'CA IA - Royal Bank of Canada', 'CA IA - ScotiaBank', 'CA IA - Toronto Dominion Bank', 'CA Industry - Communications', 'CA Industry - Federal', 'CA Industry - Financial Serv', 'CA Industry - Govt of Ontario', 'Canada Default'], ['All', 'Systems w/TPS', 'Cloud & Data Platform', 'Security', 'Cognitive Applications','Watson Health', 'Industry Platforms'], ['LIO'], ['ALL LINE ITEMS'], ['Identifying (1)', 'Validated (4)', 'Qualifying (7)', 'Gaining Agreement (6)']], "is not expected"
    return listLegend2

def aggPipe_GraphOne_Title_BU():
    global agg_GrOne_Title
    budgetVerify = driver.find_element_by_xpath(locators.common_KPI_Budget_Val).text
    print(budgetVerify)
    if budgetVerify != 'N/A':
        agg_GrOne_Title = driver.find_element_by_xpath(locators.agg_GraphOne_Title_BUCov11)
    elif budgetVerify == 'N/A':
        agg_GrOne_Title = driver.find_element_by_xpath(locators.agg_GraphOne_Title_BUPPA)
    print(agg_GrOne_Title.text)
    print(agg_GrOne_Title.text)
    return agg_GrOne_Title

def Segmented_tab():
    #Click on Segmented Tab
    driver.find_element_by_xpath(locators.sp).click()

    time.sleep(20)

#for SP won

def RD_WON_KPI_DF_Grp1():
    RD_WON_block = driver.find_element_by_xpath(locators.rd_WON)
    print(RD_WON_block.text)
    global RD_WON_Val
    RD_WON_Val=Common.es_kpi1(RD_WON_block)
    print(RD_WON_Val)
    print("RD_WON is " + str(RD_WON_Val))
    time.sleep(5)
    RD_WON_block.click()
    time.sleep(5)
    RD_WON_group_default = driver.find_element_by_xpath(locators.Def_Grp)
    print(RD_WON_group_default.text)
    assert RD_WON_group_default.text == "By Sales Stage", "Default Group for RD_WON is incorrect"

def RD_WON_KPI_DF_Grp():
    RD_WON_block = driver.find_element_by_xpath(locators.rd_WON)
    print(RD_WON_block.text)
    global RD_WON_Val
    RD_WON_Val=Common.es_kpi1(RD_WON_block)
    print(RD_WON_Val)
    print("RD_WON is " + str(RD_WON_Val))
    time.sleep(5)
    RD_WON_block.click()
    time.sleep(5)
    RD_WON_group_default = driver.find_element_by_xpath(locators.Def_Grp)
    print(RD_WON_group_default.text)
    assert RD_WON_group_default.text == "By Roadmap Status", "Default Group for RD_WON is incorrect"
    # return VP_Val,Vp_group_default

def RD_WON_KPI_vs_Summary_DealList():
    # print(VP_Val)
    RD_WON_Summary_header = driver.find_element_by_xpath(locators.Summary_deal_header_val)
    global RD_WON_Deal_value_2
    RD_WON_Deal_value_2 = RD_WON_Summary_header.text.replace(",", "")
    RD_WON_Deal_value_2 = re.findall(r'[0-9]+[.]?[0-9]+', RD_WON_Deal_value_2)
    RD_WON_Deal_value_2 = RD_WON_Deal_value_2[0]

    print("Summary header lineitem Value for RD_WON click is " + str(RD_WON_Deal_value_2))
    diff = abs(float(RD_WON_Val) - float(RD_WON_Deal_value_2))
    print("Difference of RD_WON Kpi vs Deallist line item value is " + format(diff, '.2f'))
    assert diff<1,"Mismatch between RD_WON KPI value and RD_WON Click Deallist Line item Value"

def RD_WON_KPI_Summary_DealList_vs_Sum_Detailed_List():
    Detailed_list = driver.find_elements_by_css_selector(locators.Detailed_list)
    summary = []
    for i in range(len(Detailed_list)):
        Detailed_list_value = Detailed_list[i].text
        Detailed_list_value = Detailed_list_value.replace(",", "")
        Detailed_list_value = re.findall(r'[0-9]+[.]?[0-9]+', Detailed_list_value)
        Detailed_list_value = Detailed_list_value[0]
        print(Detailed_list_value)
        summary.append(float(Detailed_list_value))

    # print(summary)
    sum_summary = sum(summary)
    print("All RD_WON Deal list sum is " + str(sum_summary))

    diff_dealvSummaryLI = abs(float(sum_summary) - float(RD_WON_Deal_value_2))
    print("Difference of RD_WON Deal listsum vs Deallist line item value is " + format(diff_dealvSummaryLI, '.2f'))
    time.sleep(3)
    Common.common_Close_dealList()
    assert diff_dealvSummaryLI < 1, "Mismatch between RD_WON KPI Click Deallist Line item Value and Sum of Detailed Deal list"

def RD_STR_KPI_DF_Grp():
    RD_STR_block = driver.find_element_by_xpath(locators.rd_STR)
    print(RD_STR_block.text)
    global RD_STR_Val
    RD_STR_Val=Common.es_kpi1(RD_STR_block)
    print(RD_STR_Val)
    print("RD_STR is " + str(RD_STR_Val))
    RD_STR_block.click()
    time.sleep(3)
    RD_STR_group_default = driver.find_element_by_xpath(locators.Def_Grp)
    print(RD_STR_group_default.text)
    assert RD_STR_group_default.text == "By Roadmap Status", "Default Group for RD_STR is incorrect"
    # return VP_Val,Vp_group_default

def RD_STR_KPI_vs_Summary_DealList():
    # print(VP_Val)
    RD_STR_Summary_header = driver.find_element_by_xpath(locators.Summary_deal_header_val)
    global RD_STR_Deal_value_2
    RD_STR_Deal_value_2 = RD_STR_Summary_header.text.replace(",", "")
    RD_STR_Deal_value_2 = re.findall(r'[0-9]+[.]?[0-9]+', RD_STR_Deal_value_2)
    RD_STR_Deal_value_2 = RD_STR_Deal_value_2[0]

    print("Summary header lineitem Value for RD_STR click is " + str(RD_STR_Deal_value_2))
    diff = abs(float(RD_STR_Val) - float(RD_STR_Deal_value_2))
    print("Difference of RD_STR Kpi vs Deallist line item value is " + format(diff, '.2f'))
    assert diff<1,"Mismatch between RD_STR KPI value and RD_STR Click Deallist Line item Value"

def RD_STR_KPI_Summary_DealList_vs_Sum_Detailed_List():
    Detailed_list = driver.find_elements_by_css_selector(locators.Detailed_list)
    summary = []
    for i in range(len(Detailed_list)):
        Detailed_list_value = Detailed_list[i].text
        Detailed_list_value = Detailed_list_value.replace(",", "")
        Detailed_list_value = re.findall(r'[0-9]+[.]?[0-9]+', Detailed_list_value)
        Detailed_list_value = Detailed_list_value[0]
        print(Detailed_list_value)
        summary.append(float(Detailed_list_value))

    # print(summary)
    sum_summary = sum(summary)
    print("All RD_STR Deal list sum is " + str(sum_summary))

    diff_dealvSummaryLI = abs(float(sum_summary) - float(RD_STR_Deal_value_2))
    print("Difference of RD_STR Deal listsum vs Deallist line item value is " + format(diff_dealvSummaryLI, '.2f'))
    time.sleep(3)
    Common.common_Close_dealList()
    assert diff_dealvSummaryLI < 1, "Mismatch between RD_STR KPI Click Deallist Line item Value and Sum of Detailed Deal list"

def RD_WKS_KPI_DF_Grp():
    RD_WKS_block = driver.find_element_by_xpath(locators.rd_WKS)
    print(RD_WKS_block.text)
    global RD_WKS_Val
    RD_WKS_Val=Common.es_kpi1(RD_WKS_block)
    print(RD_WKS_Val)
    print("RD_WKS is " + str(RD_WKS_Val))
    RD_WKS_block.click()
    time.sleep(3)
    RD_WKS_group_default = driver.find_element_by_xpath(locators.Def_Grp)
    print(RD_WKS_group_default.text)
    assert RD_WKS_group_default.text == "By Roadmap Status", "Default Group for RD_WKS is incorrect"
    # return VP_Val,Vp_group_default

def RD_WKS_KPI_vs_Summary_DealList():
    # print(VP_Val)
    RD_WKS_Summary_header = driver.find_element_by_xpath(locators.Summary_deal_header_val)
    global RD_WKS_Deal_value_2
    RD_WKS_Deal_value_2 = RD_WKS_Summary_header.text.replace(",", "")
    RD_WKS_Deal_value_2 = re.findall(r'[0-9]+[.]?[0-9]+', RD_WKS_Deal_value_2)
    RD_WKS_Deal_value_2 = RD_WKS_Deal_value_2[0]

    print("Summary header lineitem Value for RD_WKS click is " + str(RD_WKS_Deal_value_2))
    diff = abs(float(RD_WKS_Val) - float(RD_WKS_Deal_value_2))
    print("Difference of RD_WKS Kpi vs Deallist line item value is " + format(diff, '.2f'))
    assert diff<1,"Mismatch between RD_WKS KPI value and RD_WKS Click Deallist Line item Value"

def RD_WKS_KPI_Summary_DealList_vs_Sum_Detailed_List():
    Detailed_list = driver.find_elements_by_css_selector(locators.Detailed_list)
    summary = []
    for i in range(len(Detailed_list)):
        Detailed_list_value = Detailed_list[i].text
        Detailed_list_value = Detailed_list_value.replace(",", "")
        Detailed_list_value = re.findall(r'[0-9]+[.]?[0-9]+', Detailed_list_value)
        Detailed_list_value = Detailed_list_value[0]
        print(Detailed_list_value)
        summary.append(float(Detailed_list_value))

    # print(summary)
    sum_summary = sum(summary)
    print("All RD_WKS Deal list sum is " + str(sum_summary))

    diff_dealvSummaryLI = abs(float(sum_summary) - float(RD_WKS_Deal_value_2))
    print("Difference of RD_WKS Deal listsum vs Deallist line item value is " + format(diff_dealvSummaryLI, '.2f'))
    time.sleep(3)
    Common.common_Close_dealList()
    assert diff_dealvSummaryLI < 1, "Mismatch between RD_WKS KPI Click Deallist Line item Value and Sum of Detailed Deal list"




##---------------------------call code below-------------------------##

# Login_Page.open_ISD()
# time.sleep(8)
# Segmented_tab()
# loop_view()

# ISDLOGO()
# NEEDHELP()
# Profile_Page_AH()
# PRIVACY()
# ABOUTISD()
# PROFILEINFO()
# LEXPANDICON()
# LEXPANDICON_close()
# es_breadcrumb()
# ES_KPI()
# es_budget(Graph1()) #(ingore for now)
# es_ppv(Graph1()) #(ingore for now)
# geo_check(Graph1()) #(ingore for now)
# #graph2()   # Giving error due to "N/A" #(ingore for now)
# G1_G2_Budget_PPV()
# G3_Budget_WSR_WON()
# G3_G4_Budget_WSR_WON()
# DrillDown_UP_one_level()
# DrillDown_UP_Top_level()
# EStop_nav()
# MESChecking()
# ESGraphDate1()
# ESGraphDate2()
# ESGraphDate3()
# ESGraphDate4()

# VP_KPI_DF_Grp()
# VP_KPI_vs_Summary_DealList()
# VP_KPI_Summary_DealList_vs_Sum_Detailed_List()
#
# # WSR_KPI_DF_Grp()
# # WSR_KPI_vs_Summary_DealList()
# # WSR_KPI_Summary_DealList_vs_Sum_Detailed_List()
#
# WON_KPI_DF_Grp()
# WON_KPI_vs_Summary_DealList()
# WON_KPI_Summary_DealList_vs_Sum_Detailed_List()
# G2_Budget_QTD_Actuals()
# # G4_Budget_WSR()
# SPtop_nav()
# QP_KPI_DF_Grp()
# QP_KPI_vs_Summary_DealList()
# QP_KPI_Summary_DealList_vs_Sum_Detailed_List()