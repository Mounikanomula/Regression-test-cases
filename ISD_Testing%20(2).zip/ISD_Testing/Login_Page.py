from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
import re
from selenium.webdriver.common.action_chains import ActionChains
import locators


#driver = webdriver.Chrome()
driver = webdriver.Chrome(executable_path=r"C:\DRIVERBIN\chromedriver.exe")
# driver = webdriver.Edge()
def open_ISD():
    driver.get(locators.url)
    driver.maximize_window()
    driver.implicitly_wait(30)
    login_id = driver.find_element_by_name('username')
    login_id.send_keys(locators.user)
    login_pass = driver.find_element_by_name('password')
    login_pass.send_keys(locators.password)
    login_pass.send_keys(Keys.RETURN)
    driver.implicitly_wait(20)
    time.sleep(30)

    # print(es.text)
# driver.close()
