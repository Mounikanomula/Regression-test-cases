from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
import re
from selenium.webdriver.common.action_chains import ActionChains
from datetime import date
from datetime import datetime
from datetime import timedelta
import locators
import Login_Page
import Common
import Constants
import ES_Page

driver = Login_Page.driver
def Aggregated():
    #Click on Aggregated Tab
    rd=driver.find_element_by_xpath(locators.ap).click()
    time.sleep(20)
    #Breadcrumb
    ap1=driver.find_element_by_xpath(locators.breadcrumb)
    return ap1

def AP_KPI():
    APKPI=Common.KPI()
    # del APKPI[5]
    del APKPI[7:len(APKPI)]
    print(APKPI)
    return APKPI

def AP_Graphs():
    graph = Common.Graphs1()
    saq=driver.find_element_by_xpath(locators.SAQ_Graph).text
    track = driver.find_element_by_xpath(locators.Track).text
    graph.insert(1,saq)
    graph.insert(3, track)
    print(graph)
    return graph

def aggPipe_GraphOne_Title_BU():
    global agg_GrOne_Title
    budgetVerify = driver.find_element_by_xpath(locators.common_KPI_Budget_Val).text
    print(budgetVerify)
    if budgetVerify != 'N/A':
        agg_GrOne_Title = driver.find_element_by_xpath(locators.agg_GraphOne_Title_BUCov)
    elif budgetVerify == 'N/A':
        agg_GrOne_Title = driver.find_element_by_xpath(locators.agg_GraphOne_Title_BUPPV)
    print(agg_GrOne_Title.text)
    print(agg_GrOne_Title.text)
    return agg_GrOne_Title

def aggPipe_GraphOne_xAxis():
    #agg_geoXaxis = driver.find_elements_by_xpath(locators.agg_geoCovGraphxAxis)
    view_txt = driver.find_element_by_xpath(locators.common_GlobalFilter_View).text
    agg_geoXaxis = driver.find_elements_by_xpath((locators.agg_Graph1)+(locators.agg_graphxAxis))
    geoList = []
    for geo in agg_geoXaxis:
        geoList.append(geo.text)
    return geoList

def aggPipe_GraphThree_Title():
    agg_GrThree_Title = driver.find_element_by_xpath(locators.agg_GraphThree_Title)
    return agg_GrThree_Title

def aggPipe_GraphThree_SubTitle():
    agg_GrThree_SubTitle = driver.find_element_by_xpath(locators.agg_GraphThree_SubTitle)
    return agg_GrThree_SubTitle

def aggPipe_GraphThree_xAxis():
    agg_PPqXaxis = driver.find_elements_by_xpath((locators.agg_Graph3)+(locators.agg_graphxAxis))
    geoList=[]
    for geo in agg_PPqXaxis:
        geoList.append(geo.text)
    return geoList

def aggPipe_Bars_Tooltip():
    agg_Bars_tooltipFetch = driver.find_elements_by_xpath(locators.agg_PPQ_Bars)
    print(len(agg_Bars_tooltipFetch))
    barList = []
    for i in agg_Bars_tooltipFetch:
        ActionChains(driver).move_to_element(i).perform()
        time.sleep(1)
        txt_bars = driver.find_element_by_xpath(locators.Bars_Tooltip)
        print(txt_bars.text)
        barList.append(txt_bars.text)
    return barList

def aggPipe_PPQ_Inline_Clicks():
    arrow_Click = driver.find_element_by_xpath(locators.agg_Chart_Inline_Click)
    arrow_Click.click()
    agg_Chart_Inline = driver.find_elements_by_xpath(locators.agg_Chart_Inlines)
    print("Element Size:", len(agg_Chart_Inline))
    for i in range(len(agg_Chart_Inline)):
        dropItem = driver.find_element_by_xpath("("+locators.agg_Chart_Inlines+")"+"["+str(i+1)+"]")
        print("Dropdown Item:", dropItem.text)
        dropItem.click()
        time.sleep(1)
        print("Chart Title:", aggPipe_GraphThree_Title().text)
        aggPipe_Bars_Tooltip()
        time.sleep(1)
        arrow_Click.click()
        time.sleep(1)
    arrow_Click.click()

def aggPipe_VPTrack_Inline_Clicks():
    # ------- default view (vp track) ------------------
    print("Chart Title:", driver.find_element_by_xpath(locators.agg_Track_Chart_Title).text)
    print("Legend:", driver.find_element_by_xpath(locators.agg_Track_Legend).text)
    abc = driver.find_element_by_xpath(locators.agg_Track_Legend_Indi)
    print(abc.text)
    # assert abc.text == 'VP($M)'
    aggPipe_VPTrack_Tooltip()

    # -------- inline clicks and corresponding views excluding PPA. PPA dealt separately ------------
    arrow_Click = driver.find_element_by_xpath(locators.agg_VPTrack_Chart_Inline_Click)
    arrow_Click.click()
    agg_Chart_Inline = driver.find_elements_by_xpath(locators.agg_Chart_Inlines)
    print("Element Size:", len(agg_Chart_Inline))
    for i in range(len(agg_Chart_Inline)-1):
        dropItem = driver.find_element_by_xpath("("+locators.agg_Chart_Inlines+")"+"["+str(i+1)+"]")
        print("Dropdown Item:", dropItem.text)
        dropItem.click()
        time.sleep(1)
        print(driver.find_element_by_xpath(locators.agg_Track_Chart_Title).text)
        print("Chart Title", driver.find_element_by_xpath(locators.agg_Track_Chart_Title).text)
        print("Legend:", driver.find_element_by_xpath(locators.agg_Track_Legend).text)
        legendIndi = driver.find_element_by_xpath(locators.agg_Track_Legend_Indi)
        print("Related Legend:", legendIndi.text)
        time.sleep(1)
        aggPipe_VPTrack_Tooltip()
        arrow_Click.click()
        time.sleep(1)
    arrow_Click.click()

def aggPipe_VPTrack_Tooltip():
    moveOnLine = driver.find_elements_by_xpath(locators.agg_VPTrack_MoveOnLine)
    print("Element Size:", len(moveOnLine))
    for i in moveOnLine:
        ActionChains(driver).move_to_element(i).perform()
        driver.implicitly_wait(2)
#        time.sleep(1)
        aggPipe_VPTrack_Tooltip_label()

def aggPipe_VPTrack_Tooltip_label():
    lineLabel = driver.find_elements_by_xpath(locators.Tracks_Tooltip)
#    print(len(lineLabel)) --- uncomment this line for debugging purpose, if you may like.
    size = len(lineLabel)
    tooltip = lineLabel[size-1]
    print(tooltip.text)

def aggPipe_PPA():
    driver.find_element_by_xpath(locators.agg_VPTrack_Chart_Inline_Click).click()
    driver.find_element_by_xpath(locators.agg_Inline_PPA_Select).click()
    driver.implicitly_wait(10)
    time.sleep(5)
    print(driver.find_element_by_xpath(locators.agg_PPA_VelocityAvg).text)
    PPALine = driver.find_element_by_xpath(locators.agg_PPA_Toy)
    ActionChains(driver).move_to_element(PPALine).perform()
    time.sleep(1)
    print(PPALine.text)
    driver.implicitly_wait(10)
    driver.find_element_by_xpath(locators.agg_VPTrack_Chart_Inline_Click).click()
    driver.find_element_by_xpath("("+locators.agg_Chart_Inlines+")"+"["+str(1)+"]").click()


def aggPipe_Track_Chart_Title_Legend():
    print("Chart Title:", driver.find_element_by_xpath(locators.agg_Track_Chart_Title).text)
    arrow_Click = driver.find_element_by_xpath(locators.agg_VPTrack_Chart_Inline_Click)
    arrow_Click.click()
    agg_Chart_Inline = driver.find_elements_by_xpath(locators.agg_Chart_Inlines)
    print("Element Size:", len(agg_Chart_Inline))
    lst_ChartTitle = []
    lst_ChartLegend = []
    for i in range(1, len(agg_Chart_Inline)):
        dropItem = driver.find_element_by_xpath("(" + locators.agg_Chart_Inlines + ")" + "[" + str(i) + "]")
        print("Dropdown Item:", dropItem.text)
        dropItem.click()
        time.sleep(1)
        chartTitle = driver.find_element_by_xpath(locators.agg_Track_Chart_Title)
        print("Chart Title", driver.find_element_by_xpath(locators.agg_Track_Chart_Title).text)
        lst_ChartTitle.append(chartTitle.text)
        chartLegend = driver.find_element_by_xpath(locators.agg_Track_Legend_Indi)
        print("Chart Legend", driver.find_element_by_xpath(locators.agg_Track_Legend_Indi).text)
        lst_ChartLegend.append(chartLegend.text)
        arrow_Click.click()
    print(lst_ChartTitle)
    print(lst_ChartLegend)
#    return lst_ChartTitle, lst_ChartLegend
    assert lst_ChartTitle == Constants.AP_Track_ChartTitles, "Chart Titles not as expected"
    assert lst_ChartLegend == Constants.AP_Track_Legend, "Chart legend not as expected"
    arrow_Click.click()

def APtop_nav():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle=driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    time.sleep(2)
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :"+str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-2):
        time.sleep(2)
        GH1[i].click()
        time.sleep(2)
        Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
        print(Topnav.text)
        listLegend1.append(Topnav.text)
        driver.find_element_by_xpath(locators.dropdown_wrapper).click()
    # print(listLegend1)
    for i in listLegend1:
            listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    assert listLegend2==[['NQ'], ['Signings', 'Signings-ACV'], ['All', 'Americas', 'EMEA', 'Japan', 'APAC', 'INVALID', 'UNASSIGNED'], ['All', 'Systems w/TPS', 'Cloud & Data Platform', 'Security', 'Cognitive Applications','Watson Health'],['UNIT']],"Not expected"
    return listLegend2


def APGraphDate1():
    td = date.today()
    weeklydate = (td.weekday() - 2) % 7
    last_wednesday = td - timedelta(days=weeklydate)
    Wednesday = datetime.strftime(last_wednesday, '%b %d, %Y')
    print("Wednesday date :" + Wednesday)

    time.sleep(5)
    GH1 = driver.find_element_by_xpath(locators.GH1).text
    print("Graph title : "+ GH1)
    GH1Date = driver.find_element_by_xpath(locators.APGH1Date).text
    Gh1date = str(GH1Date).replace("Data as of ", "")
    assert Gh1date.find(Wednesday) == 0, "Date is not matching"
    print("Graph1date : " + Gh1date)
    time.sleep(2)

def APGraphDate2():

    GH2 = driver.find_element_by_xpath(locators.SAQGraphHeader).text
    print("Graph title : "+GH2)
    GH2Date = driver.find_element_by_xpath(locators.SAQGraphDate).text
    print("Graph Date : " + GH2Date)
    time.sleep(2)

def APGraphDate3():
    td = date.today()
    weeklydate = (td.weekday() - 2) % 7
    last_wednesday = td - timedelta(days=weeklydate)
    Wednesday = datetime.strftime(last_wednesday, '%b %d, %Y')
    print("Wednesday date :" + Wednesday)
    time.sleep(5)
    GH3 = driver.find_element_by_xpath(locators.GH2_AP).text
    print("Graph title : " + GH3)
    GH3Date = driver.find_element_by_xpath(locators.APGH2Date).text
    Gh3date = str(GH3Date).replace("Data as of ", "")
    assert Gh3date.find(Wednesday) == 0, "Date is not matching"
    print("Graph Date : " + Gh3date )

def APGraphDate4():
    td = date.today()
    weeklydate = (td.weekday() - 2) % 7
    last_wednesday = td - timedelta(days=weeklydate)
    Wednesday = datetime.strftime(last_wednesday, '%b %d, %Y')
    print("Wednesday date :" + Wednesday)
    time.sleep(5)
    GH4 = driver.find_element_by_xpath(locators.VPtrackHeader).text
    print("Graph title : " + GH4)
    GH4Date = driver.find_element_by_xpath(locators.VPTrack_Date).text
    Gh4date = str(GH4Date).replace("Data as of ", "")
    print(Gh4date)
    assert Gh4date.find(Wednesday) == 0, "Date is not matching"
    print("Graph Date : " + Gh4date)
    time.sleep(2)
def Weekly_date(date):
    td = date.today()
    weeklydate = (td.weekday() - 2) % 7
    last_wednesday = td - timedelta(days=weeklydate)
    Wednesday = datetime.strftime(last_wednesday, '%b %d, %Y')
    # return  Wednesday
    print("Wednesday date :" + Wednesday)
    time.sleep(2)

def AP_VP_KPI_DF_Grp():
    ES_Page.VP_KPI_DF_Grp()

def AP_VP_KPI_vs_Summary_DealList():
    ES_Page.VP_KPI_vs_Summary_DealList()

def AP_VP_KPI_Summary_DealList_vs_Sum_Detailed_List():
    ES_Page.VP_KPI_Summary_DealList_vs_Sum_Detailed_List()

def AP_QP_KPI_DF_Grp():
    QP_block = driver.find_element_by_xpath(locators.QP)
    print(QP_block.text)
    global QP_Val
    QP_Val=Common.es_kpi1(QP_block)
    print(QP_Val)
    print("QP is " + str(QP_Val))
    QP_block.click()
    time.sleep(3)
    QP_group_default = driver.find_element_by_xpath(locators.Def_Grp)
    print(QP_group_default.text)
    assert QP_group_default.text == "By Sales Stage", "Default Group for QP is incorrect"
    # return VP_Val,Vp_group_default

def AP_QP_KPI_vs_Summary_DealList():
    # print(VP_Val)
    QP_Summary_header = driver.find_element_by_xpath(locators.Summary_deal_header_val)
    global QP_Deal_value_2
    QP_Deal_value_2 = QP_Summary_header.text.replace(",", "")
    QP_Deal_value_2 = re.findall(r'[0-9]+[.]?[0-9]+', QP_Deal_value_2)
    QP_Deal_value_2 = QP_Deal_value_2[0]

    print("Summary header lineitem Value for QP click is " + str(QP_Deal_value_2))
    diff = abs(float(QP_Val) - float(QP_Deal_value_2))
    print("Difference of QP Kpi vs Deallist line item value is " + format(diff, '.2f'))
    assert diff<1,"Mismatch between QP KPI value and QP Click Deallist Line item Value"

def AP_QP_KPI_Summary_DealList_vs_Sum_Detailed_List():
    Detailed_list = driver.find_elements_by_css_selector(locators.Detailed_list)
    summary = []
    for i in range(len(Detailed_list)):
        Detailed_list_value = Detailed_list[i].text
        Detailed_list_value = Detailed_list_value.replace(",", "")
        Detailed_list_value = re.findall(r'[0-9]+[.]?[0-9]+', Detailed_list_value)
        Detailed_list_value = Detailed_list_value[0]
        print(Detailed_list_value)
        summary.append(float(Detailed_list_value))

    # print(summary)
    sum_summary = sum(summary)
    print("All QP Deal list sum is " + str(sum_summary))

    diff_dealvSummaryLI = abs(float(sum_summary) - float(QP_Deal_value_2))
    print("Difference of QP Deal listsum vs Deallist line item value is " + format(diff_dealvSummaryLI, '.2f'))
    time.sleep(3)
    Common.common_Close_dealList()
    assert diff_dealvSummaryLI < 1, "Mismatch between QP KPI Click Deallist Line item Value and Sum of Detailed Deal list"

def AP_WON_KPI_DF_Grp():
    time.sleep(5)
    WON_block = driver.find_element_by_xpath(locators.WON)
    print(WON_block.text)
    global WON_Val
    WON_Val = Common.es_kpi1(WON_block)
    print(WON_Val)
    print("WON is " + str(WON_Val))
    WON_block.click()
    time.sleep(3)
    WON_group_default = driver.find_element_by_xpath(locators.Def_Grp)
    print(WON_group_default.text)
    assert WON_group_default.text == "By Sales Stage", "Default Group for WON is incorrect"
    # return VP_Val,Vp_group_default


def AP_WON_KPI_vs_Summary_DealList():
    # print(VP_Val)
    time.sleep(5)
    WON_Summary_header = driver.find_element_by_xpath(locators.Summary_deal_header_val)
    global WON_Deal_value_2
    WON_Deal_value_2 = WON_Summary_header.text.replace(",", "")
    WON_Deal_value_2 = re.findall(r'[0-9]+[.]?[0-9]+', WON_Deal_value_2)
    WON_Deal_value_2 = WON_Deal_value_2[0]

    print("Summary header lineitem Value for WON click is " + str(WON_Deal_value_2))
    diff = abs(float(WON_Val) - float(WON_Deal_value_2))
    print("Difference of WON Kpi vs Deallist line item value is " + format(diff, '.2f'))
    assert diff < 1, "Mismatch between WON KPI value and WON Click Deallist Line item Value"


def AP_WON_KPI_Summary_DealList_vs_Sum_Detailed_List():
    time.sleep(5)
    Detailed_list = driver.find_elements_by_css_selector(locators.Detailed_list)
    summary = []
    for i in range(len(Detailed_list)):
        Detailed_list_value = Detailed_list[i].text
        Detailed_list_value = Detailed_list_value.replace(",", "")
        Detailed_list_value = re.findall(r'[0-9]+[.]?[0-9]+', Detailed_list_value)
        Detailed_list_value = Detailed_list_value[0]
        print(Detailed_list_value)
        summary.append(float(Detailed_list_value))

    # print(summary)
    sum_summary = sum(summary)
    print("All WON Deal list sum is " + str(sum_summary))

    diff_dealvSummaryLI = abs(float(sum_summary) - float(WON_Deal_value_2))
    print("Difference of WON Deal listsum vs Deallist line item value is " + format(diff_dealvSummaryLI, '.2f'))
    time.sleep(3)
    Common.common_Close_dealList()
    assert diff_dealvSummaryLI < 1, "Mismatch between WON KPI Click Deallist Line item Value and Sum of Detailed Deal list"

def SAQ_Probe():
    Probe_txt = driver.find_element_by_xpath(locators.SAQ_Probe).text
    Probe_clk = driver.find_element_by_xpath(locators.SAQ_Probe_txt)
    action = ActionChains(driver)
    action.move_to_element(Probe_clk).perform()
    print("Probe text is " + str(Probe_clk.text))
    Probe_str = Probe_clk.text.replace(",", "").replace("$","").replace("M","")
    print(Probe_str)
    Probe_str = re.findall(r'[0-9]+[.]?[0-9]+', Probe_str)
    print(Probe_str)
    global Probe_sum_val_str
    Probe_sum_val_str = Probe_str[0]
    print(Probe_sum_val_str)
    Probe_clk.click()
    time.sleep(5)
    SAQ_Probe_group_default = driver.find_element_by_xpath(locators.Def_Grp)
    print(SAQ_Probe_group_default.text)
    assert SAQ_Probe_group_default.text == "BY SAQ QUADRANT", "Default Group for SAQ Probe is incorrect"

def SAQ_Probe_vs_Summary_DealList():
    # print(VP_Val)
    SAQ_Probe_Summary_header = driver.find_element_by_xpath(locators.SAQ_Probe_Dl)
    global SAQ_Probe_Deal_value_2
    SAQ_Probe_Deal_value_2 = SAQ_Probe_Summary_header.text.replace(",", "")
    SAQ_Probe_Deal_value_2 = re.findall(r'[0-9]+[.]?[0-9]+', SAQ_Probe_Deal_value_2)
    SAQ_Probe_Deal_value_2 = SAQ_Probe_Deal_value_2[0]

    print("Summary header lineitem Value for SAQ_Probe click is " + str(SAQ_Probe_Deal_value_2))
    diff = abs(float(Probe_sum_val_str) - float(SAQ_Probe_Deal_value_2))
    print("Difference of SAQ Probe vs Deallist line item value is " + format(diff, '.2f'))
    assert diff<1,"Mismatch between SAQ Probe value and SAQ_Probe Click Deallist Line item Value"

def SAQ_Probe_Summary_DealList_vs_Sum_Detailed_List():
    Detailed_list = driver.find_elements_by_css_selector(locators.Detailed_list)
    summary = []
    for i in range(len(Detailed_list)):
        Detailed_list_value = Detailed_list[i].text
        Detailed_list_value = Detailed_list_value.replace(",", "")
        Detailed_list_value = re.findall(r'[0-9]+[.]?[0-9]+', Detailed_list_value)
        Detailed_list_value = Detailed_list_value[0]
        print(Detailed_list_value)
        summary.append(float(Detailed_list_value))

    # print(summary)
    sum_summary = sum(summary)
    print("All SAQ_Probe Deal list sum is " + str(sum_summary))

    diff_dealvSummaryLI = abs(float(sum_summary) - float(SAQ_Probe_Deal_value_2))
    print("Difference of SAQ_Probe listsum vs Deallist line item value is " + format(diff_dealvSummaryLI, '.2f'))
    time.sleep(3)
    Common.common_Close_dealList()
    assert diff_dealvSummaryLI < 1, "Mismatch between SAQ_Probe Click Deallist Line item Value and Sum of Detailed Deal list"

def SAQ_Close():
    Close_txt = driver.find_element_by_xpath(locators.SAQ_Close).text
    Close_clk = driver.find_element_by_xpath(locators.SAQ_Close_txt)
    action = ActionChains(driver)
    action.move_to_element(Close_clk).perform()
    print("Close text is " + str(Close_clk.text))
    Close_str = Close_clk.text.replace(",", "")
    Close_str = re.findall(r'[0-9]+[.]?[0-9]+', Close_str)
    global Close_sum_val_str
    Close_sum_val_str = Close_str[0]
    print(Close_sum_val_str)
    Close_clk.click()
    time.sleep(5)
    SAQ_Close_group_default = driver.find_element_by_xpath(locators.Def_Grp)
    print(SAQ_Close_group_default.text)
    assert SAQ_Close_group_default.text == "BY SAQ QUADRANT", "Default Group for SAQ Close is incorrect"

def SAQ_Close_vs_Summary_DealList():
    # print(VP_Val)
    SAQ_Close_Summary_header = driver.find_element_by_xpath(locators.SAQ_Probe_Dl)
    global SAQ_Close_Deal_value_2
    SAQ_Close_Deal_value_2 = SAQ_Close_Summary_header.text.replace(",", "")
    SAQ_Close_Deal_value_2 = re.findall(r'[0-9]+[.]?[0-9]+', SAQ_Close_Deal_value_2)
    SAQ_Close_Deal_value_2 = SAQ_Close_Deal_value_2[0]

    print("Summary header lineitem Value for SAQ_Close click is " + str(SAQ_Close_Deal_value_2))
    diff = abs(float(Close_sum_val_str) - float(SAQ_Close_Deal_value_2))
    print("Difference of SAQ Close vs Deallist line item value is " + format(diff, '.2f'))
    assert diff<1,"Mismatch between SAQ Close value and SAQ_Close Click Deallist Line item Value"

def SAQ_Close_Summary_DealList_vs_Sum_Detailed_List():
    Detailed_list = driver.find_elements_by_css_selector(locators.Detailed_list)
    summary = []
    for i in range(len(Detailed_list)):
        Detailed_list_value = Detailed_list[i].text
        Detailed_list_value = Detailed_list_value.replace(",", "")
        Detailed_list_value = re.findall(r'[0-9]+[.]?[0-9]+', Detailed_list_value)
        Detailed_list_value = Detailed_list_value[0]
        print(Detailed_list_value)
        summary.append(float(Detailed_list_value))

    # print(summary)
    sum_summary = sum(summary)
    print("All SAQ_Close Deal list sum is " + str(sum_summary))

    diff_dealvSummaryLI = abs(float(sum_summary) - float(SAQ_Close_Deal_value_2))
    print("Difference of SAQ_Close listsum vs Deallist line item value is " + format(diff_dealvSummaryLI, '.2f'))
    time.sleep(3)
    Common.common_Close_dealList()
    assert diff_dealvSummaryLI < 1, "Mismatch between SAQ_Close Click Deallist Line item Value and Sum of Detailed Deal list"

def SAQ_Refine():
    Refine_txt = driver.find_element_by_xpath(locators.SAQ_Refine).text
    Refine_clk = driver.find_element_by_xpath(locators.SAQ_Refine_txt)
    action = ActionChains(driver)
    action.move_to_element(Refine_clk).perform()
    print("Refine text is " + str(Refine_clk.text))
    Refine_str = Refine_clk.text.replace(",", "")
    Refine_str = re.findall(r'[0-9]+[.]?[0-9]+', Refine_str)
    global Refine_sum_val_str
    Refine_sum_val_str = Refine_str[0]
    print(Refine_sum_val_str)
    Refine_clk.click()
    time.sleep(5)
    SAQ_Refine_group_default = driver.find_element_by_xpath(locators.Def_Grp)
    print(SAQ_Refine_group_default.text)
    assert SAQ_Refine_group_default.text == "BY SAQ QUADRANT", "Default Group for SAQ Refine is incorrect"

def SAQ_Refine_vs_Summary_DealList():
    # print(VP_Val)
    SAQ_Refine_Summary_header = driver.find_element_by_xpath(locators.SAQ_Probe_Dl)
    global SAQ_Refine_Deal_value_2
    SAQ_Refine_Deal_value_2 = SAQ_Refine_Summary_header.text.replace(",", "")
    SAQ_Refine_Deal_value_2 = re.findall(r'[0-9]+[.]?[0-9]+', SAQ_Refine_Deal_value_2)
    SAQ_Refine_Deal_value_2 = SAQ_Refine_Deal_value_2[0]

    print("Summary header lineitem Value for SAQ_Refine click is " + str(SAQ_Refine_Deal_value_2))
    diff = abs(float(Refine_sum_val_str) - float(SAQ_Refine_Deal_value_2))
    print("Difference of SAQ Refine vs Deallist line item value is " + format(diff, '.2f'))
    assert diff<1,"Mismatch between SAQ Refine value and SAQ_Refine Click Deallist Line item Value"

def SAQ_Refine_Summary_DealList_vs_Sum_Detailed_List():
    Detailed_list = driver.find_elements_by_css_selector(locators.Detailed_list)
    summary = []
    for i in range(len(Detailed_list)):
        Detailed_list_value = Detailed_list[i].text
        Detailed_list_value = Detailed_list_value.replace(",", "")
        Detailed_list_value = re.findall(r'[0-9]+[.]?[0-9]+', Detailed_list_value)
        Detailed_list_value = Detailed_list_value[0]
        print(Detailed_list_value)
        summary.append(float(Detailed_list_value))

    # print(summary)
    sum_summary = sum(summary)
    print("All SAQ_Refine Deal list sum is " + str(sum_summary))

    diff_dealvSummaryLI = abs(float(sum_summary) - float(SAQ_Refine_Deal_value_2))
    print("Difference of SAQ_Refine listsum vs Deallist line item value is " + format(diff_dealvSummaryLI, '.2f'))
    time.sleep(3)
    Common.common_Close_dealList()
    assert diff_dealvSummaryLI < 1, "Mismatch between SAQ_Refine Click Deallist Line item Value and Sum of Detailed Deal list"

def SAQ_Advance():
    Advance_txt = driver.find_element_by_xpath(locators.SAQ_Advance).text
    Advance_clk = driver.find_element_by_xpath(locators.SAQ_Advance_txt)
    action = ActionChains(driver)
    action.move_to_element(Advance_clk).perform()
    print("Advance text is " + str(Advance_clk.text))
    Advance_str = Advance_clk.text.replace(",", "")
    Advance_str = re.findall(r'[0-9]+[.]?[0-9]+', Advance_str)
    global Advance_sum_val_str
    Advance_sum_val_str = Advance_str[0]
    print(Advance_sum_val_str)
    Advance_clk.click()
    time.sleep(5)
    SAQ_Advance_group_default = driver.find_element_by_xpath(locators.Def_Grp)
    print(SAQ_Advance_group_default.text)
    assert SAQ_Advance_group_default.text == "BY SAQ QUADRANT", "Default Group for SAQ Advance is incorrect"

def SAQ_Advance_vs_Summary_DealList():
    # print(VP_Val)
    SAQ_Advance_Summary_header = driver.find_element_by_xpath(locators.SAQ_Probe_Dl)
    global SAQ_Advance_Deal_value_2
    SAQ_Advance_Deal_value_2 = SAQ_Advance_Summary_header.text.replace(",", "")
    SAQ_Advance_Deal_value_2 = re.findall(r'[0-9]+[.]?[0-9]+', SAQ_Advance_Deal_value_2)
    SAQ_Advance_Deal_value_2 = SAQ_Advance_Deal_value_2[0]

    print("Summary header lineitem Value for SAQ_Advance click is " + str(SAQ_Advance_Deal_value_2))
    diff = abs(float(Advance_sum_val_str) - float(SAQ_Advance_Deal_value_2))
    print("Difference of SAQ Advance vs Deallist line item value is " + format(diff, '.2f'))
    assert diff<1,"Mismatch between SAQ Advance value and SAQ_Refine Click Deallist Line item Value"

def SAQ_Advance_Summary_DealList_vs_Sum_Detailed_List():
    Detailed_list = driver.find_elements_by_css_selector(locators.Detailed_list)
    summary = []
    for i in range(len(Detailed_list)):
        Detailed_list_value = Detailed_list[i].text
        Detailed_list_value = Detailed_list_value.replace(",", "")
        Detailed_list_value = re.findall(r'[0-9]+[.]?[0-9]+', Detailed_list_value)
        Detailed_list_value = Detailed_list_value[0]
        print(Detailed_list_value)
        summary.append(float(Detailed_list_value))

    # print(summary)
    sum_summary = sum(summary)
    print("All SAQ_Advance Deal list sum is " + str(sum_summary))

    diff_dealvSummaryLI = abs(float(sum_summary) - float(SAQ_Advance_Deal_value_2))
    print("Difference of SAQ_Advance listsum vs Deallist line item value is " + format(diff_dealvSummaryLI, '.2f'))
    time.sleep(3)
    Common.common_Close_dealList()
    assert diff_dealvSummaryLI < 1, "Mismatch between SAQ_Advance Click Deallist Line item Value and Sum of Detailed Deal list"






##---------------------------call code below-------------------------##

#
# Login_Page.open_ISD()
# Aggregated()
# AP_KPI()
# AP_Graphs()

# Common.GlobFilterClick()
##Common.common_TopNav_AltView() #(ingore for now)
# Common.GlobFilterXiconClick()
## aggPipe_GraphOne_Title_BU() #(ingore for now)


# aggPipe_GraphOne_xAxis()
# aggPipe_GraphThree_Title()
# aggPipe_GraphThree_SubTitle()
# aggPipe_GraphThree_xAxis()
# aggPipe_Bars_Tooltip()
# aggPipe_PPQ_Inline_Clicks()
# aggPipe_VPTrack_Inline_Clicks()
# # aggPipe_Track_Chart_Title_Legend()  #(ingore for now)
# aggPipe_PPA()
#
# APtop_nav()
# APGraphDate1()
# APGraphDate2()
# APGraphDate3()
# APGraphDate4()
#
# AP_VP_KPI_DF_Grp()
# AP_VP_KPI_vs_Summary_DealList()
# AP_VP_KPI_Summary_DealList_vs_Sum_Detailed_List()
#
# AP_QP_KPI_DF_Grp()
# AP_QP_KPI_vs_Summary_DealList()
# AP_QP_KPI_Summary_DealList_vs_Sum_Detailed_List()
#
# AP_WON_KPI_DF_Grp()
# AP_WON_KPI_vs_Summary_DealList()
# AP_WON_KPI_Summary_DealList_vs_Sum_Detailed_List()
#
# SAQ_Probe()
# SAQ_Probe_vs_Summary_DealList()
# SAQ_Probe_Summary_DealList_vs_Sum_Detailed_List()
#
# SAQ_Close()
# SAQ_Close_vs_Summary_DealList()
# SAQ_Close_Summary_DealList_vs_Sum_Detailed_List()
#
# SAQ_Refine()
# SAQ_Refine_vs_Summary_DealList()
# SAQ_Refine_Summary_DealList_vs_Sum_Detailed_List()
#
# SAQ_Advance()
# SAQ_Advance_vs_Summary_DealList()
# SAQ_Advance_Summary_DealList_vs_Sum_Detailed_List()