from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
import re
from selenium.webdriver.common.action_chains import ActionChains
from datetime import date
from datetime import datetime
from datetime import timedelta
import locators
import Login_Page
import Common
import Constants

import ES_Page
import AP_Page
import SP_Page
import RD_Page
import KD_Page
import MI_Page

driver = Login_Page.driver

def EStop_nav():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle=driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    time.sleep(2)
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :"+str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-1):
        time.sleep(2)
        GH1[i].click()
        time.sleep(2)
        Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
        print(Topnav.text)
        listLegend1.append(Topnav.text)
        driver.find_element_by_xpath(locators.dropdown_wrapper2).click()
    # print(listLegend1)
    for i in listLegend1:
            listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    if driver.find_element_by_xpath(locators.common_Profile_Name).text == 'IBM_SW_TranSaaS':
        assert listLegend2==[['NQ'], ['Signings-ACV'], Constants.geo_List_TopNav, Constants.bu_List_TopNav],  "Not expected"

    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'IBM_SW_Trans':
        assert listLegend2 == [['NQ'], [''], Constants.geo_List_TopNav, Constants.bu_List_TopNav], "Not expected"

    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'CnC_SW_All':
        assert listLegend2 == [['NQ'], ['Signings-ACV'], Constants.geo_List_TopNav, Constants.CnC_SW_AllBU_TopNav], "Not expected"

    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'CogApp_All':
        assert listLegend2 == [['NQ'], ['Signings-ACV'], Constants.geo_List_TopNav, Constants.CnC_CogApp_AllBU_TopNav], "Not expected"

    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == ' Cloud and Security Signin...':
        assert listLegend2 == [['NQ'], Constants.CloudnSecSign_DealSize_TopNav, Constants.geo_List_TopNav, Constants.CloudnSecSign_Lvl17_TopNav,
                               ['IBM C&DP', 'IBM Security']], "Not expected"

    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'BU_Lvl10_All':
        assert listLegend2 == [['NQ'], ['Signings-ACV'], Constants.geo_List_TopNav, Constants.BU_Lvl10_All_TopNav], "Not expected"

    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'BU_Lvl15_All':
        assert listLegend2 == [['NQ'], ['Signings-ACV'], Constants.geo_List_TopNav, Constants.BU_lvl17_All_TopNav], "Not expected"

    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'BUL10_CDPSecCogApps':
        assert listLegend2 == [['NQ'], ['Signings', 'Signings-ACV'], Constants.geo_List_TopNav, Constants.CnC_CDPSecCogAppsBUTopNav], "Not expected"

    return listLegend2

def G1_Budget_PPV():
    B = []
    P = []
    G=[]
    bud=""
    ppv=""
    geo=""
    ESKPI = ES_Page.ES_KPI()
    # print(ESKPI)
    for j in [1]:
    # for j in [2]:
    #     driver.find_element_by_xpath(locators.max1 + '[' + str(j + 1) + ']').click()
        driver.find_element_by_xpath(locators.max1 + '[' + str(j) + ']').click()
        driver.find_element_by_xpath(locators.showhide).click()
        tx = driver.find_elements_by_xpath(locators.firstrow) # gives the total number of Rows in the table
        print(len(tx))
        t = 0
        t2 = 0
        for i in range(len(tx)):
            tx = driver.find_element_by_xpath('(' + locators.firstrow + ')' + '[' + str(i + 1) + ']').text
            tx = tx.split('\n')
            tx1 = tx[1].replace(",", "")
            tx1 = float(tx1) if tx1 != "N/A" else 0  #Inline if Function
            t = t + tx1
            tx2 = tx[3].replace(",", "")
            tx2 = float(tx2) if tx2 != "N/A" else 0
            t2 = t2 + tx2
            tx3=tx[0]
            G.append(tx3)

        #     print("Budget Graph"+str(j+1)+" : "+str(t)) # give values in list
        print("Sum Budget Graph_" + str(j) + " : " + str(t))
        B.append(round(t))
        #     print("PPV Graph"+str(j+1)+" : "+str(t2)) # give values in list
        print("Sum PPV Graph_" + str(j) + " : " + str(t2))
        P.append(round(t2))
        print("Geo :"+str(G))
        driver.find_element_by_xpath(locators.showhide).click()
        driver.find_element_by_xpath(locators.min1).click()
    print(B, P,G)
    if ESKPI[0] != B[0]:
        bud = "Budget not matching for Graph1"
    if ESKPI[3] != P[0]:
        ppv = "PPV not matching for Graph1"
    if Constants.geo_List!=G:
        geo="Geo not matching"
    print(bud, ppv,geo)
    assert ((bud != "Budget not matching for Graph1") & (
                ppv != "PPV not matching for Graph1")& (
                geo != "Geo not matching")), "Budget or PPV or Geo_list not matching for Graph1"


def APtop_nav():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle=driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    time.sleep(2)
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :"+str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-2):
    # for i in [0,2,3,4]:
        try:
            # print(i)
            time.sleep(2)
            GH1[i].click()
            time.sleep(2)
            Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
            print(Topnav.text)
            listLegend1.append(Topnav.text)
            driver.find_element_by_xpath(locators.dropdown_wrapper2).click()
        except(RuntimeError, TypeError, NameError, Exception):
            print("Top Nav failed for : "+str(i))
            print("Not Clickable")
            pass
    # print(listLegend1)
    for i in listLegend1:
            listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    if driver.find_element_by_xpath(locators.common_Profile_Name).text == 'IBM_SW_TranSaaS':
        assert listLegend2==[['NQ'], ['Signings-ACV'], Constants.geo_List_TopNav, Constants.bu_List_TopNav,['UNIT']],"Not expected"
    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'IBM_SW_Trans':
        assert listLegend2 == [['NQ'], [''], Constants.geo_List_TopNav, Constants.bu_List_TopNav, ['UNIT']], "Not expected"
    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'CnC_SW_All':
        assert listLegend2 == [['NQ'], ['Signings-ACV'], Constants.geo_List_TopNav, Constants.CnC_SW_AllBU_TopNav, ['UNIT']], "Not expected"
    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'CogApp_All':
        assert listLegend2 == [['NQ'], ['Signings-ACV'], Constants.geo_List_TopNav, Constants.CnC_CogApp_AllBU_TopNav, ['UNIT']], "Not expected"
    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == ' Cloud and Security Signin...':
        assert listLegend2 == [['NQ'], Constants.CloudnSecSign_DealSize_TopNav, Constants.geo_List_TopNav, Constants.CloudnSecSign_Lvl17_TopNav,
                               ['UNIT'],['IBM C&DP', 'IBM Security']], "Not expected"

    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'BU_Lvl10_All':
        assert listLegend2 == [['NQ'], ['Signings-ACV'], Constants.geo_List_TopNav, Constants.BU_Lvl10_All_TopNav, ['UNIT']], "Not expected"

    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'BU_Lvl15_All':
        assert listLegend2 == [['NQ'], ['Signings-ACV'], Constants.geo_List_TopNav, Constants.BU_lvl17_All_TopNav, ['UNIT']], "Not expected"

    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'BUL10_CDPSecCogApps':
        assert listLegend2 == [['NQ'], ['Signings', 'Signings-ACV'], Constants.geo_List_TopNav, Constants.CnC_CDPSecCogAppsBUTopNav, ['UNIT']], "Not expected"

    return listLegend2


def SPtop_nav():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle=driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    time.sleep(2)
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :"+str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)):
        try:
            time.sleep(2)
            GH1[i].click()
            time.sleep(2)
            Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
            print(Topnav.text)
            listLegend1.append(Topnav.text)
            driver.find_element_by_xpath(locators.dropdown_wrapper2).click()
        except(RuntimeError, TypeError, NameError, Exception):
            print("Top Nav failed for : "+str(i))
            print("Not Clickable")
            pass
    # print(listLegend1)
    for i in listLegend1:
            listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    if driver.find_element_by_xpath(locators.common_Profile_Name).text == 'IBM_SW_TranSaaS':
        assert listLegend2 == [['NQ'], ['Signings-ACV'], Constants.geo_List_TopNav, Constants.bu_List_TopNav, ['CHANNEL', 'DEAL SIZE', 'TIER GROUP', 'TIER', 'OI GROUP']], "Not expected"
    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'IBM_SW_Trans':
        assert listLegend2 == [['NQ'], [''], Constants.geo_List_TopNav, Constants.bu_List_TopNav, ['CHANNEL', 'DEAL SIZE', 'TIER GROUP', 'TIER']], "Not expected"
    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'CnC_SW_All':
        assert listLegend2 == [['NQ'], ['Signings-ACV'], Constants.geo_List_TopNav, Constants.CnC_SW_AllBU_TopNav, ['CHANNEL', 'JTC/RHS', 'JTC', 'RHS', 'DEAL SIZE', 'TIER GROUP', 'TIER', 'OI GROUP']], "Not expected"
    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'CogApp_All':
        assert listLegend2 == [['NQ'], ['Signings-ACV'], Constants.geo_List_TopNav, Constants.CnC_CogApp_AllBU_TopNav, ['CHANNEL', 'DEAL SIZE', 'TIER GROUP', 'TIER', 'OI GROUP']], "Not expected"
    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == ' Cloud and Security Signin...':
        assert listLegend2 == [['NQ'],Constants.CloudnSecSign_DealSize_TopNav, Constants.geo_List_TopNav, Constants.CloudnSecSign_Lvl17_TopNav,
                               ['CHANNEL', 'DEAL SIZE', 'CLIENT SET', 'CLOUD PLATFORM TOP ACCOUNTS'], ['IBM C&DP', 'IBM Security']], "Not expected"

    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'BU_Lvl10_All':
        assert listLegend2 == [['NQ'], ['Signings-ACV'],Constants.geo_List_TopNav, Constants.BU_Lvl10_All_TopNav,
                               ['CHANNEL', 'JTC/RHS', 'JTC', 'RHS', 'DEAL SIZE', 'TIER GROUP', 'TIER', 'OI GROUP']], "Not expected"

    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'BU_Lvl15_All':
        assert listLegend2 == [['NQ'], ['Signings-ACV'],Constants.geo_List_TopNav, Constants.BU_lvl17_All_TopNav,
                               ['CHANNEL', 'JTC/RHS', 'JTC', 'RHS', 'DEAL SIZE', 'TIER GROUP', 'TIER', 'OI GROUP']], "Not expected"

    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'BUL10_CDPSecCogApps':
        assert listLegend2 == [['NQ'], ['Signings', 'Signings-ACV'],Constants.geo_List_TopNav, Constants.CnC_CDPSecCogAppsBUTopNav,
                               ['CHANNEL', 'JTC/RHS', 'JTC', 'RHS', 'DEAL SIZE', 'TIER GROUP', 'TIER', 'OI GROUP']], "Not expected"

    return listLegend2


def RMtop_nav():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle = driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    # driver.find_element_by_xpath(locators.RMTab).click()
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :" + str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-4):
        try:
            time.sleep(2)
            GH1[i].click()
            time.sleep(2)
            Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
            print(Topnav.text)
            listLegend1.append(Topnav.text)
            driver.find_element_by_xpath(locators.dropdown_wrapper2).click()
        except(RuntimeError, TypeError, NameError, Exception):
            print("Top Nav failed for : "+str(i))
            print("Not Clickable")
            pass
    for i in listLegend1:
        listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    if driver.find_element_by_xpath(locators.common_Profile_Name).text == 'IBM_SW_TranSaaS':
        assert listLegend2== [['NQ'], ['Signings-ACV'], Constants.geo_List_TopNav, Constants.bu_List_TopNav, ['LIO'], ['BU', 'DEAL SIZE','TIER GROUP', 'TIER']],"not expected"
    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'IBM_SW_Trans':
        assert listLegend2 == [['NQ'], [''], Constants.geo_List_TopNav, Constants.bu_List_TopNav, ['LIO'],
                               ['BU', 'DEAL SIZE', 'TIER GROUP', 'TIER']], "not expected"
    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'CnC_SW_All':
        assert listLegend2 == [['NQ'], ['Signings-ACV'], Constants.geo_List_TopNav, Constants.CnC_SW_AllBU_TopNav, ['LIO'],['BU', 'DEAL SIZE', 'TIER GROUP', 'TIER']], "not expected"
    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'CogApp_All':
        assert listLegend2 == [['NQ'], ['Signings-ACV'], Constants.geo_List_TopNav, Constants.CnC_CogApp_AllBU_TopNav, ['LIO'],
                               ['BU', 'DEAL SIZE', 'TIER GROUP', 'TIER']], "not expected"
    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == ' Cloud and Security Signin...':
        assert listLegend2 == [['NQ'], Constants.CloudnSecSign_DealSize_TopNav, Constants.geo_List_TopNav, Constants.CloudnSecSign_Lvl17_TopNav,
                               ['LEVEL17', 'DEAL SIZE', 'DEAL SIZE', 'CLIENT SET', 'CLOUD PLATFORM TOP ACCOUNTS'], ['IBM C&DP', 'IBM Security']], "Not expected"

    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'BU_Lvl10_All':
        assert listLegend2== [['NQ'], ['Signings-ACV'], Constants.geo_List_TopNav, Constants.BU_Lvl10_All_TopNav,
                              ['LIO'], ['BU SUBGROUP', 'DEAL SIZE','TIER GROUP', 'TIER']],"not expected"

    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'BUL10_CDPSecCogApps':
        assert listLegend2== [['NQ'], ['Signings', 'Signings-ACV'], Constants.geo_List_TopNav, Constants.CnC_CDPSecCogAppsBUTopNav,
                              ['LIO'], ['BU SUBGROUP', 'DEAL SIZE','TIER GROUP', 'TIER']],"not expected"

    return listLegend2


def kdtop_nav():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle = driver.find_element_by_xpath(locators.MoveElementkd)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :" + str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-8):
        try:
            time.sleep(2)
            GH1[i].click()
            time.sleep(2)
            Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
            print(Topnav.text)
            listLegend1.append(Topnav.text)
            driver.find_element_by_xpath(locators.dropdown_wrapper2).click()
        except(RuntimeError, TypeError, NameError, Exception):
            print("Top Nav failed for : "+str(i))
            print("Not Clickable")
            pass
    for i in listLegend1:
        listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    time.sleep(5)
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    if driver.find_element_by_xpath(locators.common_Profile_Name).text == 'IBM_SW_TranSaaS':
        assert listLegend2 == [['NQ'], ['Signings-ACV'],Constants.geo_List_TopNav, Constants.bu_List_TopNav, ['LIO'], ['CLIENT AGGREGATION', 'ALL LINE ITEMS'],
                               ['By BU group', 'By BU Sub group', 'By Level 17', 'By WSR', 'By Dealsize', 'By SAQ', 'By SAQ Quadrant', 'By Market',
                                'By Branch Group (EBR)', 'By Branch (EBU)', 'By Branch Unit (ESU)', 'By Client Type', 'By Client Sub Type', 'By Client Set',
                                'By Channel', 'By Reporting Country', 'By Roadmap Status', 'By Close/Bill Week', 'By Close/Bill Month', 'By OI Source',
                                'By ISU Group', 'By ISU', 'By Geo', 'By Tier Group', 'By Tier']],"not expected"
    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'IBM_SW_Trans':
        assert listLegend2 == [['NQ'], [''], Constants.geo_List_TopNav, Constants.bu_List_TopNav, ['LIO'], ['CLIENT AGGREGATION', 'ALL LINE ITEMS'],
                               ['By BU group', 'By BU Sub group', 'By Level 17', 'By WSR', 'By Dealsize', 'By SAQ',
                                'By SAQ Quadrant', 'By Market', 'By Branch Group (EBR)', 'By Branch (EBU)',
                                'By Branch Unit (ESU)', 'By Client Type', 'By Client Sub Type', 'By Client Set',
                                'By Channel', 'By Reporting Country', 'By Roadmap Status', 'By Close/Bill Week',
                                'By Close/Bill Month', 'By OI Source', 'By ISU Group', 'By ISU', 'By Geo',
                                'By Tier Group', 'By Tier']], "not expected"

    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'CnC_SW_All':
        assert listLegend2 == [['NQ'], ['Signings-ACV'], Constants.geo_List_TopNav, Constants.CnC_SW_AllBU_TopNav, ['LIO'], ['CLIENT AGGREGATION', 'ALL LINE ITEMS'],
                               ['By BU group', 'By BU Sub group', 'By Level 17', 'By WSR', 'By Dealsize', 'By SAQ',
                                'By SAQ Quadrant', 'By Market', 'By Branch Group (EBR)', 'By Branch (EBU)',
                                'By Branch Unit (ESU)', 'By Client Type', 'By Client Sub Type', 'By Client Set',
                                'By Channel', 'By Reporting Country', 'By Roadmap Status', 'By Close/Bill Week',
                                'By Close/Bill Month', 'By OI Source', 'By ISU Group', 'By ISU', 'By Geo',
                                'By Tier Group', 'By Tier']], "not expected"

    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'CogApp_All':
        assert listLegend2 == [['NQ'], ['Signings-ACV'], Constants.geo_List_TopNav, Constants.CnC_CogApp_AllBU_TopNav, ['LIO'], ['CLIENT AGGREGATION', 'ALL LINE ITEMS'],
                               ['By BU group', 'By BU Sub group', 'By Level 17', 'By WSR', 'By Dealsize', 'By SAQ',
                                'By SAQ Quadrant', 'By Market', 'By Branch Group (EBR)', 'By Branch (EBU)',
                                'By Branch Unit (ESU)', 'By Client Type', 'By Client Sub Type', 'By Client Set',
                                'By Channel', 'By Reporting Country', 'By Roadmap Status', 'By Close/Bill Week',
                                'By Close/Bill Month', 'By OI Source', 'By ISU Group', 'By ISU', 'By Geo',
                                'By Tier Group', 'By Tier']], "not expected"

    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == ' Cloud and Security Signin...':
        assert listLegend2 == [['NQ'], Constants.CloudnSecSign_DealSize_TopNav, Constants.geo_List_TopNav, Constants.CloudnSecSign_Lvl17_TopNav,
                               ['CLIENT AGGREGATION', 'ALL LINE ITEMS'],
                               ['By BU group', 'By BU Sub group', 'By Level 17', 'By WSR', 'By Dealsize', 'By SAQ',
                                'By SAQ Quadrant', 'By Market', 'By Branch Group (EBR)', 'By Branch (EBU)',
                                'By Branch Unit (ESU)', 'By Client Type', 'By Client Sub Type', 'By Client Set',
                                'By Channel', 'By Reporting Country', 'By Roadmap Status', 'By Close/Bill Week',
                                'By Close/Bill Month', 'By OI Source', 'By ISU Group', 'By ISU', 'By Geo']], "not expected"

    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'BU_Lvl10_All':
        assert listLegend2 == [['NQ'], ['Signings-ACV'], Constants.geo_List_TopNav, Constants.BU_Lvl10_All_TopNav, ['LIO'],
                               ['CLIENT AGGREGATION', 'ALL LINE ITEMS'],
                               ['By BU group', 'By BU Sub group', 'By Level 17', 'By WSR', 'By Dealsize', 'By SAQ',
                                'By SAQ Quadrant', 'By Market', 'By Branch Group (EBR)', 'By Branch (EBU)',
                                'By Branch Unit (ESU)', 'By Client Type', 'By Client Sub Type', 'By Client Set',
                                'By Channel', 'By Reporting Country', 'By Roadmap Status', 'By Close/Bill Week',
                                'By Close/Bill Month', 'By OI Source', 'By ISU Group', 'By ISU', 'By Geo',
                                'By Tier Group', 'By Tier']], "not expected"

    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'BU_Lvl15_All':
        assert listLegend2 == [['NQ'], ['Signings-ACV'], Constants.geo_List_TopNav, Constants.BU_lvl17_All_TopNav, ['LIO'],
                               ['CLIENT AGGREGATION', 'ALL LINE ITEMS'],
                               ['By BU group', 'By BU Sub group', 'By Level 17', 'By WSR', 'By Dealsize', 'By SAQ',
                                'By SAQ Quadrant', 'By Market', 'By Branch Group (EBR)', 'By Branch (EBU)',
                                'By Branch Unit (ESU)', 'By Client Type', 'By Client Sub Type', 'By Client Set',
                                'By Channel', 'By Reporting Country', 'By Roadmap Status', 'By Close/Bill Week',
                                'By Close/Bill Month', 'By OI Source', 'By ISU Group', 'By ISU', 'By Geo',
                                'By Tier Group', 'By Tier']], "not expected"

    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'BUL10_CDPSecCogApps':
        assert listLegend2 == [['NQ'], ['Signings', 'Signings-ACV'], Constants.geo_List_TopNav, Constants.CnC_CDPSecCogAppsBUTopNav, ['LIO'],
                               ['CLIENT AGGREGATION', 'ALL LINE ITEMS'],
                               ['By BU Sub group', 'By Level 17', 'By WSR', 'By Dealsize', 'By SAQ',
                                'By SAQ Quadrant', 'By Market', 'By Branch Group (EBR)', 'By Branch (EBU)',
                                'By Branch Unit (ESU)', 'By Client Type', 'By Client Sub Type', 'By Client Set',
                                'By Channel', 'By Reporting Country', 'By Roadmap Status', 'By Close/Bill Week',
                                'By Close/Bill Month', 'By OI Source', 'By ISU Group', 'By ISU', 'By Geo',
                                'By Tier Group', 'By Tier']], "not expected"

    return listLegend2


def Mitop_nav():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle = driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :" + str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-4):
        try:
            time.sleep(2)
            GH1[i].click()
            time.sleep(2)
            Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
            print(Topnav.text)
            listLegend1.append(Topnav.text)
            driver.find_element_by_xpath(locators.dropdown_wrapper2).click()
        except(RuntimeError, TypeError, NameError, Exception):
            print("Top Nav failed for : "+str(i))
            print("Not Clickable")
            pass
    for i in listLegend1:
        listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    time.sleep(3)
    driver.find_element_by_xpath(locators.common_GlobalFilterXicon).click()
    if driver.find_element_by_xpath(locators.common_Profile_Name).text == 'IBM_SW_TranSaaS':
        assert listLegend2 == [['NQ'], ['Signings-ACV'], Constants.geo_List_TopNav, Constants.bu_List_TopNav, ['LIO'], ['ALL LINE ITEMS'],
                               ['Identifying (1)', 'Validated (4)', 'Qualifying (7)', 'Gaining Agreement (6)']], "is not expected"
    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'IBM_SW_Trans':
        assert listLegend2 == [['NQ'], [''], Constants.geo_List_TopNav, Constants.bu_List_TopNav, ['LIO'],
                               ['ALL LINE ITEMS'], ['Identifying (1)', 'Validated (4)', 'Qualifying (7)',
                                                    'Gaining Agreement (6)']], "is not expected"

    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'CnC_SW_All':
        assert listLegend2 == [['NQ'], ['Signings-ACV'], Constants.geo_List_TopNav, Constants.CnC_SW_AllBU_TopNav, ['LIO'],
                               ['ALL LINE ITEMS'], ['Identifying (1)', 'Validated (4)', 'Qualifying (7)',
                                                    'Gaining Agreement (6)']], "is not expected"

    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'CogApp_All':
        assert listLegend2 == [['NQ'], ['Signings-ACV'], Constants.geo_List_TopNav, Constants.CnC_CogApp_AllBU_TopNav, ['LIO'],
                               ['ALL LINE ITEMS'], ['Identifying (1)', 'Validated (4)', 'Qualifying (7)',
                                                    'Gaining Agreement (6)']], "is not expected"

    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == ' Cloud and Security Signin...':
        assert listLegend2 == [['NQ'], Constants.CloudnSecSign_DealSize_TopNav, Constants.geo_List_TopNav, Constants.CloudnSecSign_Lvl17_TopNav,
                               ['CLIENT AGGREGATION', 'ALL LINE ITEMS'],
                               ['Identifying (1)', 'Validated (4)', 'Qualifying (7)',
                                'Gaining Agreement (6)']], "not expected"

    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'BU_Lvl10_All':
        assert listLegend2 == [['NQ'], ['Signings-ACV'], Constants.geo_List_TopNav, Constants.BU_Lvl10_All_TopNav, ['LIO'],
                               ['ALL LINE ITEMS'], ['Identifying (1)', 'Validated (4)', 'Qualifying (7)',
                                 'Gaining Agreement (6)']], "is not expected"\

    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'BU_Lvl15_All':
        assert listLegend2 == [['NQ'], ['Signings-ACV'], Constants.geo_List_TopNav, Constants.BU_lvl17_All_TopNav, ['LIO'],
                               ['ALL LINE ITEMS'], ['Identifying (1)', 'Validated (4)', 'Qualifying (7)',
                                 'Gaining Agreement (6)']], "is not expected"

    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'BUL10_CDPSecCogApps':
        assert listLegend2 == [['NQ'], ['Signings', 'Signings-ACV'], Constants.geo_List_TopNav, Constants.CnC_CDPSecCogAppsBUTopNav, ['LIO'],
                               ['ALL LINE ITEMS'], ['Identifying (1)', 'Validated (4)', 'Qualifying (7)',
                                 'Gaining Agreement (6)']], "is not expected"

    return listLegend2






# -------- Call Below Code ------------- #

# Login_Page.open_ISD()
# ES_Page.es_breadcrumb()
# EStop_nav()
# time.sleep(2)
# AP_Page.Aggregated()
# APtop_nav()
# time.sleep(2)
# SP_Page.Segmented_tab()
# time.sleep(2)
# SPtop_nav()
# time.sleep(2)
# RD_Page.Trans_pip()
# time.sleep(2)
# RD_Page.Roadmap()
# RMtop_nav()
# time.sleep(2)
# KD_Page.KD_tab_Click()
# kdtop_nav()
# time.sleep(2)
# MI_Page.MI_tab_Click()
# Mitop_nav()

