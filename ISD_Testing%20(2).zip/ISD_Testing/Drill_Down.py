from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
import re
from selenium.webdriver.common.action_chains import ActionChains

# No Auth URL Test
url = "https://skyline.epm-sales-staging.us-south.containers.appdomain.cloud/esa-skyline-ibm-dev/uiappltest//esa-skyline-ibm-dev/uiappltest/?email=skytesti@in.ibm.com&firstname=Functional ID 3&bluegroups=ARDE_ALL&uid=07820E744&noauthentication=true"


# Preprod
# url = "https://w3-pre.ibm.com/sales/management-dashboard//sales/management-dashboard/?email=skytesti@in.ibm.com&firstname=Functional ID 3&bluegroups=ARDE_ALL&uid=07820E744&noauthentication=true"
# # Staging
# url="https://skylinestag.epm-sales-staging.us-south.containers.appdomain.cloud/esa-skyline-ibm-dev/epmsales/esa-skyline-ibm-dev/epmsales/?email=skytesti@in.ibm.com&firstname=Functional ID 3&bluegroups=ARDE_ALL&uid=07820E744&noauthentication=true"

def Login():
    global driver
    driver = webdriver.Chrome()
    driver.get(url)
    # u = driver.find_element_by_name('username')
    # u.send_keys('skytesti@in.ibm.com')
    # p = driver.find_element_by_name('password')
    # p.send_keys('SkylineTesting@3')
    # p.send_keys(Keys.RETURN)
    driver.maximize_window()
    time.sleep(20)


def es_kpi1(element):
    element = element.text
    element = element.split('\n')
    print(element)
    element_2 = element[1]
    print(element_2)
    if element_2.find("K") < 0:
        element_2 = element_2.replace(",", "")
        #         element_2 = re.findall(r'\d+', element_2)
        element_2 = re.findall(r'\d+\.?\d+', element_2)
        #         element_2 = re.findall('^[-+]?\d*\.?\d*$', element_2)
        print(element_2)
        element_2 = element_2[0]
        element_2 = round(float(element_2))
    else:
        element_2 = element_2.replace(",", "").replace("$", "").replace("K", "")
        print(element_2)
        element_2 = re.findall(r'\d+\.?\d+', element_2)
        print(element_2)
        element_2 = element_2[0]
        element_2 = round(float(element_2) / 1000)
    return element_2


def KPI():
    try:
        Budget = es_kpi1(driver.find_element_by_xpath("(//div[@class='verticalCenter'])[1]"))
        print("Budget: " + str(Budget))
    except (RuntimeError, TypeError, NameError, Exception):
        Budget = "Budget locator not found"
        pass
    try:
        PPV = es_kpi1(driver.find_element_by_xpath("(//div[@class='verticalCenter'])[4]"))
        print("PPV: " + str(PPV))
    except (RuntimeError, TypeError, NameError, Exception):
        PPV = "PPV locator not found"
        pass
    return Budget, PPV


def getlist():
    max1 = "(//*[@name='icon--maximize'])"
    showhide = "//*[@class='buttonShowHide']"
    firstrow = "//*[@class='datatable-body-row datatable-row-even ng-star-inserted']"
    min1 = "(//*[@name='icon--minimize'])"
    # get datatable and get the index of the values which are not equal to 0
    P = []
    P_ok = []
    P_nok = []
    B = []  # Budget
    PP = []  # PPV
    driver.find_element_by_xpath(max1).click()
    driver.find_element_by_xpath(showhide).click()
    tx = driver.find_elements_by_xpath(firstrow)
    t = 0
    t2 = 0
    for ik in range(len(tx)):
        tx = driver.find_element_by_xpath('(' + firstrow + ')' + '[' + str(ik + 1) + ']').text
        tx = tx.split('\n')
        try:
            float(tx[0])
            tx1 = 'N/A'
        except(RuntimeError, TypeError, NameError, ValueError, Exception):
            tx1 = tx[0]
            tx1
        P.append(tx1)
        if len(tx) == 18:
            tx2 = tx[1].replace(",", "")
            tx2 = float(tx2) if tx2 != "N/A" else 0
            t = t + tx2
            tx3 = tx[3].replace(",", "")
            tx3 = float(tx3) if tx3 != "N/A" else 0
            t2 = t2 + tx3
        else:
            tx2 = tx[0].replace(",", "")
            tx2 = float(tx2) if tx2 != "N/A" else 0
            t = t + tx2
            tx3 = tx[2].replace(",", "")
            tx3 = float(tx3) if tx3 != "N/A" else 0
            t2 = t2 + tx3

    driver.find_element_by_xpath(showhide).click()
    driver.find_element_by_xpath(min1).click()

    B.append(round(t))
    PP.append(round(t2))

    #     B.append(t)
    #     PP.append(t2)
    for k in range(len(P)):
        if P[k] == "N/A" or P[k] == "UNASSIGNED":
            P_nok.append(P.index(P[k]))
        else:
            P_ok.append(P.index(P[k]))
    return P_ok, P_nok, P, B, PP


# BU Drill Down

def BU_toggle():
    driver.find_element_by_xpath("(//label[@class='bx--radio-button__label'])[2]").click()  # BU Click
    time.sleep(3)


def bu_getlist():
    max1 = "(//*[@name='icon--maximize'])[2]"
    showhide = "//*[@class='buttonShowHide']"
    firstrow = "//*[@class='datatable-body-row datatable-row-even ng-star-inserted']"
    min1 = "(//*[@name='icon--minimize'])"
    # get datatable and get the index of the values which are not equal to 0
    P = []
    P_ok = []
    P_nok = []
    B = []  # Budget
    PP = []  # PPV
    #     for j in range(1,2):
    driver.find_element_by_xpath(max1).click()
    driver.find_element_by_xpath(showhide).click()
    tx = driver.find_elements_by_xpath(firstrow)
    t = 0
    t2 = 0
    for ik in range(len(tx)):
        tx = driver.find_element_by_xpath('(' + firstrow + ')' + '[' + str(ik + 1) + ']').text
        tx = tx.split('\n')
        try:
            float(tx[0])
            tx1 = "N/A"
        except(RuntimeError, TypeError, NameError, ValueError, Exception):
            tx1 = tx[0]
            print(tx1)
        P.append(tx1)
        if len(tx) == 18:
            tx2 = tx[1].replace(",", "")
            tx2 = float(tx2) if tx2 != "N/A" else 0
            t = t + tx2
            tx3 = tx[3].replace(",", "")
            tx3 = float(tx3) if tx3 != "N/A" else 0
            t2 = t2 + tx3
        else:
            tx2 = tx[0].replace(",", "")
            tx2 = float(tx2) if tx2 != "N/A" else 0
            t = t + tx2
            tx3 = tx[2].replace(",", "")
            tx3 = float(tx3) if tx3 != "N/A" else 0
            t2 = t2 + tx3
    driver.find_element_by_xpath(showhide).click()
    driver.find_element_by_xpath(min1).click()
    B.append(round(t))
    PP.append(round(t2))
    for k in range(len(P)):
        if P[k] == "N/A" or P[k] == "UNASSIGNED":
            P_nok.append(P.index(P[k]))
        else:
            P_ok.append(P.index(P[k]))
    return P_ok, P_nok, P, B, PP


# BU to BU Sub group
def BU_to_BU_Subgroup():   #BUSINESS UNIT GROUP -> BUSINESS UNIT SUBGROUP
    GH1 = driver.find_elements_by_xpath(
        "//h4[text()='BUSINESS UNIT GROUP COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
    # TP=driver.find_element_by_xpath("//*[name()='ngx-tooltip-content']")
    s = len(GH1)
    st = []
    stDD1 = []
    stDD2 = []
    stDD3 = []
    stDD4 = []
    # i=1
    det = getlist()
    print("BU " + str(det))
    P_ok = det[0]
    for i in P_ok:
        time.sleep(5)
        GH1 = driver.find_elements_by_xpath(
            "//h4[text()='BUSINESS UNIT GROUP COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
        print(i)
        ActionChains(driver).move_to_element_with_offset((GH1)[i], xoffset=1, yoffset=1).perform()
        time.sleep(5)
        CL = driver.find_elements_by_xpath("//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
        print((CL)[i].text)
        #     print(i)
        #     print(type(i))
        ActionChains(driver).click((CL)[i]).perform()
        time.sleep(5)
        print("DrillDown to BU Subgroup")
        det1 = bu_getlist()
        print("BU Sub Group: " + str(det1))
        P_ok1 = det1[0]
        for k in P_ok1:
            try:
                time.sleep(5)
                DD2 = driver.find_elements_by_xpath(
                    "//h4[text()='BUSINESS UNIT SUBGROUP COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
                print(k)
                ActionChains(driver).move_to_element_with_offset((DD2)[k], xoffset=1, yoffset=1).perform()
                CL2 = driver.find_elements_by_xpath(
                    "//h4[text()='BUSINESS UNIT SUBGROUP COV% (PPV)']//..//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
                print((CL2)[k].text)
                time.sleep(2)
            except (RuntimeError, TypeError, NameError, Exception, IndexError):
                time.sleep(5)
                DD2 = driver.find_elements_by_xpath(
                    "//h4[text()='BUSINESS UNIT SUBGROUP PPV']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
                print(k)
                ActionChains(driver).move_to_element_with_offset((DD2)[k], xoffset=1, yoffset=1).perform()
                CL2 = driver.find_elements_by_xpath(
                    "//h4[text()='BUSINESS UNIT SUBGROUP PPV']//..//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
                print((CL2)[k].text)
                time.sleep(2)
        driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
        print("DrillUP to BU")


# Click on get_list and BU_get_Lits, alos change to BU
# BU to BU Sub group to Level 17
def BU_to_Level17(): #BUSINESS UNIT GROUP -> BUSINESS UNIT SUBGROUP -> Level 17
    # Click on get_list and BU_get_Lits, alos change to BU
    # BU to BU Sub group to Level 17
    GH1 = driver.find_elements_by_xpath(
        "//h4[text()='BUSINESS UNIT GROUP COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
    # TP=driver.find_element_by_xpath("//*[name()='ngx-tooltip-content']")
    s = len(GH1)
    # i=1
    det = getlist()
    # print(det)
    kpi = KPI()
    print(kpi)
    print("BU" + str(det))
    print(kpi[0], kpi[1], det[3][0], det[4][0])
    if kpi[0] != det[3][0]:
        bud = "Budget not matching for BU SubGroup"
        print(bud)
    if kpi[1] != det[4][0]:
        ppv = "PPV not matching for BU SubGroup"
        print(ppv)
    P_ok = det[0]
    print("BU List: " + str(P_ok))
    for i in P_ok:
        # for i in [0, 1, 3]:  # Removed Miscelenious as no DD
        time.sleep(5)
        GH1 = driver.find_elements_by_xpath(
            "//h4[text()='BUSINESS UNIT GROUP COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
        print(i)
        time.sleep(3)
        ActionChains(driver).move_to_element((GH1)[i]).perform()
        time.sleep(5)
        CL = driver.find_elements_by_xpath(
            "//h4[text()='BUSINESS UNIT GROUP COV% (PPV)']//..//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
        print(i)
        print("BU: " + (CL)[i].text)
        #     print(i)
        #     print(type(i))
        ActionChains(driver).click((CL)[i]).perform()
        time.sleep(5)
        print("DrillDown to BU Subgroup")
        det1 = bu_getlist()
        kpi1 = KPI()
        print(kpi1)
        #     print("BU Sub Group: "+str(det1))
        P_ok1 = det1[0]
        print("BU Sub Group List: " + str(det1[2]))
        for k in P_ok1:
            try:
                time.sleep(5)
                DD2 = driver.find_elements_by_xpath(
                    "//h4[text()='BUSINESS UNIT SUBGROUP COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
                print(k)
                ActionChains(driver).move_to_element_with_offset((DD2)[k], xoffset=1, yoffset=1).perform()
                CL2 = driver.find_elements_by_xpath(
                    "//h4[text()='BUSINESS UNIT SUBGROUP COV% (PPV)']//..//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
                print("BU Sub Group: " + (CL2)[k].text)
                time.sleep(2)
                ActionChains(driver).click((CL2)[k]).perform()
                time.sleep(5)
                print("DrillDown to Level 17")
                det2 = bu_getlist()
                kpi2 = KPI()
                print(kpi2)
                P_ok2 = det2[2]
                print("Level 17 List: " + str(P_ok2))
                driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
                print(kpi2[0], kpi2[1], det2[3][0], det2[4][0])
                if kpi2[0] != det2[3][0]:
                    bud = "Budget not matching for Level 17"
                    print(bud)
                if kpi2[1] != det2[4][0]:
                    ppv = "PPV not matching for Level 17"
                    print(ppv)
                print("DrillUP to BU Sub Group")
                driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
                time.sleep(3)
                driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
                time.sleep(3)
            except (RuntimeError, TypeError, NameError, Exception, IndexError):
                time.sleep(5)
                DD2 = driver.find_elements_by_xpath(
                    "//h4[text()='BUSINESS UNIT SUBGROUP PPV']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
                print(k)
                ActionChains(driver).move_to_element_with_offset((DD2)[k], xoffset=1, yoffset=1).perform()
                CL2 = driver.find_elements_by_xpath(
                    "//h4[text()='BUSINESS UNIT SUBGROUP PPV']//..//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
                print("BU Sub Group: " + (CL2)[k].text)
                time.sleep(2)
                ActionChains(driver).click((CL2)[k]).perform()
                time.sleep(8)
                print("DrillDown to Level 17")
                det2 = bu_getlist()
                kpi2 = KPI()
                print(kpi2)
                P_ok2 = det2[2]
                print("Level 17 List: " + str(P_ok2))
                time.sleep(2)
                driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
                print(kpi2[0], kpi2[1], det2[3][0], det2[4][0])
                if kpi2[0] != det2[3][0]:
                    bud = "Budget not matching for Level 17"
                    print(bud)
                if kpi2[1] != det2[4][0]:
                    ppv = "PPV not matching for Level 17"
                    print(ppv)
                print("DrillUP to BU Sub Group")
                driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
                time.sleep(3)
                driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
                time.sleep(3)
        time.sleep(5)
        MoveEle = driver.find_element_by_xpath("(//div[@class='verticalCenter'])[5]")
        action = ActionChains(driver)
        action.move_to_element(MoveEle).perform()
        time.sleep(3)
        driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
        print(kpi1[0], kpi1[1], det1[3][0], det1[4][0])
        if kpi1[0] != det1[3][0]:
            bud = "Budget not matching for BU sub group"
            print(bud)
        if kpi1[1] != det1[4][0]:
            ppv = "PPV not matching for BU sub group"
            print(ppv)
        print("DrillUP to BU")
        driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
        time.sleep(3)
        driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
        time.sleep(3)


def DD_Geo(): #Geo -> MARKET -> EBR -> EBU -> ESU
    GH1 = driver.find_elements_by_xpath(
        "//h4[text()='GEO COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
    # TP=driver.find_element_by_xpath("//*[name()='ngx-tooltip-content']")
    s = len(GH1)
    st = []
    stDD1 = []
    stDD2 = []
    stDD3 = []
    stDD4 = []
    # i=1
    det = getlist()
    kpi = KPI()
    print(kpi)
    print("GEO " + str(det))
    print(kpi[0], kpi[1], det[3][0], det[4][0])
    if kpi[0] != det[3][0]:
        bud = "Budget not matching for Geo"
        print(bud)
    if kpi[1] != det[4][0]:
        ppv = "PPV not matching for Geo"
        print(ppv)
    P_ok = det[0]
    # print("BU List: "+str(P_ok))
    for i in P_ok:
        time.sleep(5)
        GH1 = driver.find_elements_by_xpath(
            "//h4[text()='GEO COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
        print(i)
        time.sleep(3)
        ActionChains(driver).move_to_element_with_offset((GH1)[i], xoffset=1, yoffset=1).perform()
        time.sleep(5)
        CL = driver.find_elements_by_xpath("//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
        print(i)
        print("Geo: " + (CL)[i].text)
        #     print(i)
        #     print(type(i))
        ActionChains(driver).click((CL)[i]).perform()
        time.sleep(5)
        print("DrillDown to Market")
        det1 = getlist()
        kpi1 = KPI()
        print(det1)
        print(kpi1)
        #     print("BU Sub Group: "+str(det1))
        P_ok1 = det1[0]
        print("Market List: " + str(det1[2]))
        for j in P_ok1:
            #         try:
            time.sleep(5)
            DD1 = driver.find_elements_by_xpath(
                "//h4[text()='MARKET COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
            print(j)
            ActionChains(driver).move_to_element_with_offset((DD1)[j], xoffset=1, yoffset=1).perform()
            CL2 = driver.find_elements_by_xpath("//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
            print("Market Group: " + (CL2)[j].text)
            time.sleep(2)
            ActionChains(driver).click((CL2)[j]).perform()
            time.sleep(5)
            print("DrillDown to EBR")
            det2 = getlist()
            kpi2 = KPI()
            print(kpi2)
            P_ok2 = det2[0]
            print("EBR List: " + str(det2[2]))
            for k in P_ok2:
                try:
                    time.sleep(5)
                    DD2 = driver.find_elements_by_xpath(
                        "//h4[text()='BRANCH GROUP (EBR) COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
                    print(k)
                    ActionChains(driver).move_to_element((DD2)[k]).perform()
                    CL3 = driver.find_elements_by_xpath(
                        "//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
                    print("EBR: " + (CL3)[k].text)
                    time.sleep(2)
                    #                 print(k)
                    ActionChains(driver).click((CL3)[k]).perform()
                    #                 print(k)
                    #                 print(type(k))
                    time.sleep(5)
                    print("DrillDown to EBU")
                    det3 = getlist()
                    kpi3 = KPI()
                    print(kpi3)
                    print("EBU: " + str(det3))
                    P_ok3 = det3[0]
                    print("EBU List: " + str(det3[2]))
                    for l in P_ok3:
                        try:
                            time.sleep(5)
                            DD3 = driver.find_elements_by_xpath(
                                "//h4[text()='BRANCH (EBU) COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
                            print(l)
                            ActionChains(driver).move_to_element((DD3)[l]).perform()
                            time.sleep(5)
                            CL4 = driver.find_elements_by_xpath(
                                "//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
                            print("EBU: " + (CL4)[l].text)
                            time.sleep(3)
                            ActionChains(driver).click((CL4)[l]).perform()
                            time.sleep(5)
                            print("DrillDown to ESU")
                            det4 = getlist()
                            kpi4 = KPI()
                            print(kpi4)
                            print("ESU: " + str(det4))
                            P_ok4 = det4[2]
                            print("ESU List: " + str(P_ok4))
                            time.sleep(3)
                            driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
                            if kpi4[0] != det4[3][0]:
                                bud = "Budget not matching for ESU"
                                print(bud)
                            if kpi4[1] != det4[4][0]:
                                ppv = "PPV not matching for ESU"
                                print(ppv)
                            print("DrillUP to EBU")
                            driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
                            time.sleep(3)
                            driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
                            time.sleep(3)
                        except (RuntimeError, TypeError, NameError, Exception, IndexError):
                            time.sleep(5)
                            DD3 = driver.find_elements_by_xpath(
                                "//h4[text()='BRANCH (EBU) PPV']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
                            print(l)
                            ActionChains(driver).move_to_element((DD3)[l]).perform()
                            time.sleep(5)
                            CL4 = driver.find_elements_by_xpath(
                                "//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
                            print("EBU: " + (CL4)[l].text)
                            time.sleep(3)
                            ActionChains(driver).click((CL4)[l]).perform()
                            time.sleep(5)
                            print("DrillDown to ESU")
                            det4 = getlist()
                            kpi4 = KPI()
                            print(kpi4)
                            print("ESU: " + str(det4))
                            P_ok4 = det4[2]
                            print("ESU List: " + str(P_ok4))
                            time.sleep(3)
                            driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
                            if kpi4[0] != det4[3][0]:
                                bud = "Budget not matching for ESU"
                                print(bud)
                            if kpi4[1] != det4[4][0]:
                                ppv = "PPV not matching for ESU"
                                print(ppv)
                            print("DrillUP to EBU")
                            driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
                            time.sleep(3)
                            driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
                            time.sleep(3)
                    time.sleep(5)
                    MoveEle = driver.find_element_by_xpath("(//div[@class='verticalCenter'])[5]")
                    action = ActionChains(driver)
                    action.move_to_element(MoveEle).perform()
                    time.sleep(3)
                    driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
                    if kpi3[0] != det3[3][0]:
                        bud = "Budget not matching for EBU"
                        print(bud)
                    if kpi3[1] != det3[4][0]:
                        ppv = "PPV not matching for EBU"
                        print(ppv)
                    print("DrillUP to EBR")
                    driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
                    time.sleep(3)
                    driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
                    time.sleep(3)
                except (RuntimeError, TypeError, NameError, Exception, IndexError):
                    time.sleep(5)
                    DD2 = driver.find_elements_by_xpath(
                        "//h4[text()='BRANCH GROUP (EBR) PPV']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
                    print(k)
                    ActionChains(driver).move_to_element((DD2)[k]).perform()
                    CL3 = driver.find_elements_by_xpath(
                        "//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
                    print("EBR: " + (CL3)[k].text)
                    time.sleep(2)
                    #                 print(k)
                    ActionChains(driver).click((CL3)[k]).perform()
                    #                 print(k)
                    #                 print(type(k))
                    time.sleep(5)
                    print("DrillDown to EBU")
                    det3 = getlist()
                    kpi3 = KPI()
                    print(kpi3)
                    print("EBU: " + str(det3))
                    P_ok3 = det3[0]
                    print("EBU List: " + str(det3[2]))
                    for l in P_ok3:
                        try:
                            time.sleep(5)
                            DD3 = driver.find_elements_by_xpath(
                                "//h4[text()='BRANCH (EBU) COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
                            print(l)
                            ActionChains(driver).move_to_element((DD3)[l]).perform()
                            time.sleep(5)
                            CL4 = driver.find_elements_by_xpath(
                                "//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
                            print("EBU: " + (CL4)[l].text)
                            time.sleep(3)
                            ActionChains(driver).click((CL4)[l]).perform()
                            time.sleep(5)
                            print("DrillDown to ESU")
                            det4 = getlist()
                            kpi4 = KPI()
                            print(kpi4)
                            print("ESU: " + str(det4))
                            P_ok4 = det4[2]
                            print("ESU List: " + str(P_ok4))
                            time.sleep(3)
                            driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
                            if kpi4[0] != det4[3][0]:
                                bud = "Budget not matching for ESU"
                                print(bud)
                            if kpi4[1] != det4[4][0]:
                                ppv = "PPV not matching for ESU"
                                print(ppv)
                            print("DrillUP to EBU")
                            driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
                            time.sleep(3)
                            driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
                            time.sleep(3)
                        except (RuntimeError, TypeError, NameError, Exception, IndexError):
                            time.sleep(5)
                            DD3 = driver.find_elements_by_xpath(
                                "//h4[text()='BRANCH (EBU) PPV']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
                            print(l)
                            ActionChains(driver).move_to_element((DD3)[l]).perform()
                            time.sleep(5)
                            CL4 = driver.find_elements_by_xpath(
                                "//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
                            print("EBU: " + (CL4)[l].text)
                            print(l)
                            ActionChains(driver).click((CL4)[l]).perform()
                            time.sleep(5)
                            print("DrillDown to ESU")
                            det4 = getlist()
                            kpi4 = KPI()
                            print(kpi4)
                            print("ESU: " + str(det4))
                            P_ok4 = det4[2]
                            print("ESU List: " + str(P_ok4))
                            time.sleep(3)
                            driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
                            if kpi4[0] != det4[3][0]:
                                bud = "Budget not matching for ESU"
                                print(bud)
                            if kpi4[1] != det4[4][0]:
                                ppv = "PPV not matching for ESU"
                                print(ppv)
                            print("DrillUP to EBU")
                            driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
                            time.sleep(3)
                            driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
                            time.sleep(3)
                    time.sleep(5)
                    MoveEle = driver.find_element_by_xpath("(//div[@class='verticalCenter'])[5]")
                    action = ActionChains(driver)
                    action.move_to_element(MoveEle).perform()
                    time.sleep(3)
                    driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
                    if kpi3[0] != det3[3][0]:
                        bud = "Budget not matching for EBU"
                        print(bud)
                    if kpi3[1] != det3[4][0]:
                        ppv = "PPV not matching for EBU"
                        print(ppv)
                    print("DrillUP to EBR")
                    driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
                    time.sleep(3)
                    driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
                    time.sleep(3)
            time.sleep(5)
            MoveEle = driver.find_element_by_xpath("(//div[@class='verticalCenter'])[5]")
            action = ActionChains(driver)
            action.move_to_element(MoveEle).perform()
            time.sleep(3)
            driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
            if kpi2[0] != det2[3][0]:
                bud = "Budget not matching for EBR"
                print(bud)
            if kpi2[1] != det2[4][0]:
                ppv = "PPV not matching for EBR"
                print(ppv)
            print("DrillUP to Market")
            driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
            time.sleep(3)
            driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
            time.sleep(3)
        time.sleep(5)
        MoveEle = driver.find_element_by_xpath("(//div[@class='verticalCenter'])[5]")
        action = ActionChains(driver)
        action.move_to_element(MoveEle).perform()
        time.sleep(3)
        driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
        if kpi1[0] != det1[3][0]:
            bud = "Budget not matching for Market"
            print(bud)
        if kpi1[1] != det1[4][0]:
            ppv = "PPV not matching for Market"
            print(ppv)
        print("DrillUP to GEO")
        driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
        time.sleep(3)
        driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
        time.sleep(3)

#------------
# Change Geo Manually for NA,EU,AP,LA [0,1,3,5]
def DD_Geo_CG_Geo_manu():  #Geo -> MARKET -> EBR -> EBU -> ESU
    # Geo Drill Down- Working. But issue the squence is changing when drilling up and down and vice versa
    GH1 = driver.find_elements_by_xpath(
        "//h4[text()='GEO COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
    # TP=driver.find_element_by_xpath("//*[name()='ngx-tooltip-content']")
    s = len(GH1)
    st = []
    stDD1 = []
    stDD2 = []
    stDD3 = []
    stDD4 = []
    # i=1
    det = getlist()
    kpi = KPI()
    print(kpi)
    print("GEO " + str(det))
    print(kpi[0], kpi[1], det[3][0], det[4][0])
    if kpi[0] != det[3][0]:
        bud = "Budget not matching for Geo"
        print(bud)
    if kpi[1] != det[4][0]:
        ppv = "PPV not matching for Geo"
        print(ppv)
    P_ok = det[0]
    # print("BU List: "+str(P_ok))
    # for i in P_ok:
    for i in [5]:  # Change here [0,1,3,5] for NA,EU,AP,LA
        time.sleep(5)
        GH1 = driver.find_elements_by_xpath(
            "//h4[text()='GEO COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
        print(i)
        time.sleep(3)
        ActionChains(driver).move_to_element_with_offset((GH1)[i], xoffset=1, yoffset=1).perform()
        time.sleep(5)
        CL = driver.find_elements_by_xpath("//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
        print(i)
        print("Geo: " + (CL)[i].text)
        #     print(i)
        #     print(type(i))
        ActionChains(driver).click((CL)[i]).perform()
        time.sleep(5)
        print("DrillDown to Market")
        det1 = getlist()
        kpi1 = KPI()
        print(det1)
        print(kpi1)
        #     print("BU Sub Group: "+str(det1))
        P_ok1 = det1[0]
        print("Market List: " + str(det1[2]))
        for j in P_ok1:
            #         try:
            time.sleep(5)
            DD1 = driver.find_elements_by_xpath(
                "//h4[text()='MARKET COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
            print(j)
            ActionChains(driver).move_to_element_with_offset((DD1)[j], xoffset=1, yoffset=1).perform()
            CL2 = driver.find_elements_by_xpath("//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
            print("Market Group: " + (CL2)[j].text)
            time.sleep(2)
            ActionChains(driver).click((CL2)[j]).perform()
            time.sleep(5)
            print("DrillDown to EBR")
            det2 = getlist()
            kpi2 = KPI()
            print(kpi2)
            P_ok2 = det2[0]
            print("EBR List: " + str(det2[2]))
            for k in P_ok2:
                try:
                    time.sleep(5)
                    DD2 = driver.find_elements_by_xpath(
                        "//h4[text()='BRANCH GROUP (EBR) COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
                    print(k)
                    ActionChains(driver).move_to_element((DD2)[k]).perform()
                    CL3 = driver.find_elements_by_xpath(
                        "//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
                    print("EBR: " + (CL3)[k].text)
                    time.sleep(2)
                    #                 print(k)
                    ActionChains(driver).click((CL3)[k]).perform()
                    #                 print(k)
                    #                 print(type(k))
                    time.sleep(5)
                    print("DrillDown to EBU")
                    det3 = getlist()
                    kpi3 = KPI()
                    print(kpi3)
                    print("EBU: " + str(det3))
                    P_ok3 = det3[0]
                    print("EBU List: " + str(det3[2]))
                    for l in P_ok3:
                        try:
                            time.sleep(5)
                            DD3 = driver.find_elements_by_xpath(
                                "//h4[text()='BRANCH (EBU) COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
                            print(l)
                            ActionChains(driver).move_to_element((DD3)[l]).perform()
                            time.sleep(5)
                            CL4 = driver.find_elements_by_xpath(
                                "//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
                            print("EBU: " + (CL4)[l].text)
                            time.sleep(3)
                            ActionChains(driver).click((CL4)[l]).perform()
                            time.sleep(5)
                            print("DrillDown to ESU")
                            det4 = getlist()
                            kpi4 = KPI()
                            print(kpi4)
                            print("ESU: " + str(det4))
                            P_ok4 = det4[2]
                            print("ESU List: " + str(P_ok4))
                            time.sleep(3)
                            driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
                            if kpi4[0] != det4[3][0]:
                                bud = "Budget not matching for ESU"
                                print(bud)
                            if kpi4[1] != det4[4][0]:
                                ppv = "PPV not matching for ESU"
                                print(ppv)
                            print("DrillUP to EBU")
                            driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
                            time.sleep(3)
                            driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
                            time.sleep(3)
                        except (RuntimeError, TypeError, NameError, Exception, IndexError):
                            time.sleep(5)
                            DD3 = driver.find_elements_by_xpath(
                                "//h4[text()='BRANCH (EBU) PPV']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
                            print(l)
                            ActionChains(driver).move_to_element((DD3)[l]).perform()
                            time.sleep(5)
                            CL4 = driver.find_elements_by_xpath(
                                "//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
                            print("EBU: " + (CL4)[l].text)
                            time.sleep(3)
                            ActionChains(driver).click((CL4)[l]).perform()
                            time.sleep(5)
                            print("DrillDown to ESU")
                            det4 = getlist()
                            kpi4 = KPI()
                            print(kpi4)
                            print("ESU: " + str(det4))
                            P_ok4 = det4[2]
                            print("ESU List: " + str(P_ok4))
                            time.sleep(3)
                            driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
                            if kpi4[0] != det4[3][0]:
                                bud = "Budget not matching for ESU"
                                print(bud)
                            if kpi4[1] != det4[4][0]:
                                ppv = "PPV not matching for ESU"
                                print(ppv)
                            print("DrillUP to EBU")
                            driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
                            time.sleep(3)
                            driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
                            time.sleep(3)
                    time.sleep(5)
                    MoveEle = driver.find_element_by_xpath("(//div[@class='verticalCenter'])[5]")
                    action = ActionChains(driver)
                    action.move_to_element(MoveEle).perform()
                    time.sleep(3)
                    driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
                    if kpi3[0] != det3[3][0]:
                        bud = "Budget not matching for EBU"
                        print(bud)
                    if kpi3[1] != det3[4][0]:
                        ppv = "PPV not matching for EBU"
                        print(ppv)
                    print("DrillUP to EBR")
                    driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
                    time.sleep(3)
                    driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
                    time.sleep(3)
                except (RuntimeError, TypeError, NameError, Exception, IndexError):
                    time.sleep(5)
                    DD2 = driver.find_elements_by_xpath(
                        "//h4[text()='BRANCH GROUP (EBR) PPV']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
                    print(k)
                    ActionChains(driver).move_to_element((DD2)[k]).perform()
                    CL3 = driver.find_elements_by_xpath(
                        "//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
                    print("EBR: " + (CL3)[k].text)
                    time.sleep(2)
                    #                 print(k)
                    ActionChains(driver).click((CL3)[k]).perform()
                    #                 print(k)
                    #                 print(type(k))
                    time.sleep(5)
                    print("DrillDown to EBU")
                    det3 = getlist()
                    kpi3 = KPI()
                    print(kpi3)
                    print("EBU: " + str(det3))
                    P_ok3 = det3[0]
                    print("EBU List: " + str(det3[2]))
                    for l in P_ok3:
                        try:
                            time.sleep(5)
                            DD3 = driver.find_elements_by_xpath(
                                "//h4[text()='BRANCH (EBU) COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
                            print(l)
                            ActionChains(driver).move_to_element((DD3)[l]).perform()
                            time.sleep(5)
                            CL4 = driver.find_elements_by_xpath(
                                "//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
                            print("EBU: " + (CL4)[l].text)
                            time.sleep(3)
                            ActionChains(driver).click((CL4)[l]).perform()
                            time.sleep(5)
                            print("DrillDown to ESU")
                            det4 = getlist()
                            kpi4 = KPI()
                            print(kpi4)
                            print("ESU: " + str(det4))
                            P_ok4 = det4[2]
                            print("ESU List: " + str(P_ok4))
                            time.sleep(3)
                            driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
                            if kpi4[0] != det4[3][0]:
                                bud = "Budget not matching for ESU"
                                print(bud)
                            if kpi4[1] != det4[4][0]:
                                ppv = "PPV not matching for ESU"
                                print(ppv)
                            print("DrillUP to EBU")
                            driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
                            time.sleep(3)
                            driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
                            time.sleep(3)
                        except (RuntimeError, TypeError, NameError, Exception, IndexError):
                            time.sleep(5)
                            DD3 = driver.find_elements_by_xpath(
                                "//h4[text()='BRANCH (EBU) PPV']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
                            print(l)
                            ActionChains(driver).move_to_element((DD3)[l]).perform()
                            time.sleep(5)
                            CL4 = driver.find_elements_by_xpath(
                                "//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
                            print("EBU: " + (CL4)[l].text)
                            print(l)
                            ActionChains(driver).click((CL4)[l]).perform()
                            time.sleep(5)
                            print("DrillDown to ESU")
                            det4 = getlist()
                            kpi4 = KPI()
                            print(kpi4)
                            print("ESU: " + str(det4))
                            P_ok4 = det4[2]
                            print("ESU List: " + str(P_ok4))
                            time.sleep(3)
                            driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
                            if kpi4[0] != det4[3][0]:
                                bud = "Budget not matching for ESU"
                                print(bud)
                            if kpi4[1] != det4[4][0]:
                                ppv = "PPV not matching for ESU"
                                print(ppv)
                            print("DrillUP to EBU")
                            driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
                            time.sleep(3)
                            driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
                            time.sleep(3)
                    time.sleep(5)
                    MoveEle = driver.find_element_by_xpath("(//div[@class='verticalCenter'])[5]")
                    action = ActionChains(driver)
                    action.move_to_element(MoveEle).perform()
                    time.sleep(3)
                    driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
                    if kpi3[0] != det3[3][0]:
                        bud = "Budget not matching for EBU"
                        print(bud)
                    if kpi3[1] != det3[4][0]:
                        ppv = "PPV not matching for EBU"
                        print(ppv)
                    print("DrillUP to EBR")
                    driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
                    time.sleep(3)
                    driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
                    time.sleep(3)
            time.sleep(5)
            MoveEle = driver.find_element_by_xpath("(//div[@class='verticalCenter'])[5]")
            action = ActionChains(driver)
            action.move_to_element(MoveEle).perform()
            time.sleep(3)
            driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
            if kpi2[0] != det2[3][0]:
                bud = "Budget not matching for EBR"
                print(bud)
            if kpi2[1] != det2[4][0]:
                ppv = "PPV not matching for EBR"
                print(ppv)
            print("DrillUP to Market")
            driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
            time.sleep(3)
            driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
            time.sleep(3)
        time.sleep(5)
        MoveEle = driver.find_element_by_xpath("(//div[@class='verticalCenter'])[5]")
        action = ActionChains(driver)
        action.move_to_element(MoveEle).perform()
        time.sleep(3)
        driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
        if kpi1[0] != det1[3][0]:
            bud = "Budget not matching for Market"
            print(bud)
        if kpi1[1] != det1[4][0]:
            ppv = "PPV not matching for Market"
            print(ppv)
        print("DrillUP to GEO")
        driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
        time.sleep(3)
        driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
        time.sleep(3)


#----------------------------
def DD_Geo_JP_GCG_MEA(): #Geo -> EBR -> EBU -> ESU
    GH1 = driver.find_elements_by_xpath(
        "//h4[text()='GEO COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
    # TP=driver.find_element_by_xpath("//*[name()='ngx-tooltip-content']")
    s = len(GH1)
    st = []
    stDD1 = []
    stDD2 = []
    stDD3 = []
    stDD4 = []
    # i=1
    det = getlist()
    kpi = KPI()
    print(kpi)
    print("GEO " + str(det))
    print(kpi[0], kpi[1], det[3][0], det[4][0])
    if kpi[0] != det[3][0]:
        bud = "Budget not matching for Geo"
        print(bud)
    if kpi[1] != det[4][0]:
        ppv = "PPV not matching for Geo"
        print(ppv)
    P_ok = det[0]
    # print("BU List: "+str(P_ok))
    # for i in P_ok:
    for i in [2,4,6]:
        time.sleep(5)
        GH1 = driver.find_elements_by_xpath(
            "//h4[text()='GEO COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
        print(i)
        time.sleep(3)
        ActionChains(driver).move_to_element_with_offset((GH1)[i], xoffset=1, yoffset=1).perform()
        time.sleep(5)
        CL = driver.find_elements_by_xpath("//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
        print(i)
        print("Geo: " + (CL)[i].text)
        #     print(i)
        #     print(type(i))
        ActionChains(driver).click((CL)[i]).perform()
        time.sleep(5)
        # print("DrillDown to Market")
        # det1 = getlist()
        # kpi1 = KPI()
        # print(det1)
        # print(kpi1)
        # #     print("BU Sub Group: "+str(det1))
        # P_ok1 = det1[0]
        # print("Market List: " + str(det1[2]))
        # for j in P_ok1:
        #     #         try:
        #     time.sleep(5)
        #     DD1 = driver.find_elements_by_xpath(
        #         "//h4[text()='MARKET COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
        #     print(j)
        #     ActionChains(driver).move_to_element_with_offset((DD1)[j], xoffset=1, yoffset=1).perform()
        #     CL2 = driver.find_elements_by_xpath("//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
        #     print("Market Group: " + (CL2)[j].text)
        #     time.sleep(2)
        #     ActionChains(driver).click((CL2)[j]).perform()
        #     time.sleep(5)
        print("DrillDown to EBR")
        det2 = getlist()
        kpi2 = KPI()
        print(kpi2)
        P_ok2 = det2[0]
        print("EBR List: " + str(det2[2]))
        for k in P_ok2:
            try:
                time.sleep(5)
                DD2 = driver.find_elements_by_xpath(
                    "//h4[text()='BRANCH GROUP (EBR) COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
                print(k)
                ActionChains(driver).move_to_element((DD2)[k]).perform()
                CL3 = driver.find_elements_by_xpath(
                    "//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
                print("EBR: " + (CL3)[k].text)
                time.sleep(2)
                #                 print(k)
                ActionChains(driver).click((CL3)[k]).perform()
                #                 print(k)
                #                 print(type(k))
                time.sleep(5)
                print("DrillDown to EBU")
                det3 = getlist()
                kpi3 = KPI()
                print(kpi3)
                print("EBU: " + str(det3))
                P_ok3 = det3[0]
                print("EBU List: " + str(det3[2]))
                for l in P_ok3:
                    try:
                        time.sleep(5)
                        DD3 = driver.find_elements_by_xpath(
                            "//h4[text()='BRANCH (EBU) COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
                        print(l)
                        ActionChains(driver).move_to_element((DD3)[l]).perform()
                        time.sleep(5)
                        CL4 = driver.find_elements_by_xpath(
                            "//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
                        print("EBU: " + (CL4)[l].text)
                        time.sleep(3)
                        ActionChains(driver).click((CL4)[l]).perform()
                        time.sleep(5)
                        print("DrillDown to ESU")
                        det4 = getlist()
                        kpi4 = KPI()
                        print(kpi4)
                        print("ESU: " + str(det4))
                        P_ok4 = det4[2]
                        print("ESU List: " + str(P_ok4))
                        time.sleep(3)
                        driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
                        if kpi4[0] != det4[3][0]:
                            bud = "Budget not matching for ESU"
                            print(bud)
                        if kpi4[1] != det4[4][0]:
                            ppv = "PPV not matching for ESU"
                            print(ppv)
                        print("DrillUP to EBU")
                        driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
                        time.sleep(3)
                        driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
                        time.sleep(3)
                    except (RuntimeError, TypeError, NameError, Exception, IndexError):
                        time.sleep(5)
                        DD3 = driver.find_elements_by_xpath(
                            "//h4[text()='BRANCH (EBU) PPV']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
                        print(l)
                        ActionChains(driver).move_to_element((DD3)[l]).perform()
                        time.sleep(5)
                        CL4 = driver.find_elements_by_xpath(
                            "//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
                        print("EBU: " + (CL4)[l].text)
                        time.sleep(3)
                        ActionChains(driver).click((CL4)[l]).perform()
                        time.sleep(5)
                        print("DrillDown to ESU")
                        det4 = getlist()
                        kpi4 = KPI()
                        print(kpi4)
                        print("ESU: " + str(det4))
                        P_ok4 = det4[2]
                        print("ESU List: " + str(P_ok4))
                        time.sleep(3)
                        driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
                        if kpi4[0] != det4[3][0]:
                            bud = "Budget not matching for ESU"
                            print(bud)
                        if kpi4[1] != det4[4][0]:
                            ppv = "PPV not matching for ESU"
                            print(ppv)
                        print("DrillUP to EBU")
                        driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
                        time.sleep(3)
                        driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
                        time.sleep(3)
                time.sleep(5)
                MoveEle = driver.find_element_by_xpath("(//div[@class='verticalCenter'])[5]")
                action = ActionChains(driver)
                action.move_to_element(MoveEle).perform()
                time.sleep(3)
                driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
                if kpi3[0] != det3[3][0]:
                    bud = "Budget not matching for EBU"
                    print(bud)
                if kpi3[1] != det3[4][0]:
                    ppv = "PPV not matching for EBU"
                    print(ppv)
                print("DrillUP to EBR")
                driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
                time.sleep(3)
                driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
                time.sleep(3)
            except (RuntimeError, TypeError, NameError, Exception, IndexError):
                time.sleep(5)
                DD2 = driver.find_elements_by_xpath(
                    "//h4[text()='BRANCH GROUP (EBR) PPV']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
                print(k)
                ActionChains(driver).move_to_element((DD2)[k]).perform()
                CL3 = driver.find_elements_by_xpath(
                    "//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
                print("EBR: " + (CL3)[k].text)
                time.sleep(2)
                #                 print(k)
                ActionChains(driver).click((CL3)[k]).perform()
                #                 print(k)
                #                 print(type(k))
                time.sleep(5)
                print("DrillDown to EBU")
                det3 = getlist()
                kpi3 = KPI()
                print(kpi3)
                print("EBU: " + str(det3))
                P_ok3 = det3[0]
                print("EBU List: " + str(det3[2]))
                for l in P_ok3:
                    try:
                        time.sleep(5)
                        DD3 = driver.find_elements_by_xpath(
                            "//h4[text()='BRANCH (EBU) COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
                        print(l)
                        ActionChains(driver).move_to_element((DD3)[l]).perform()
                        time.sleep(5)
                        CL4 = driver.find_elements_by_xpath(
                            "//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
                        print("EBU: " + (CL4)[l].text)
                        time.sleep(3)
                        ActionChains(driver).click((CL4)[l]).perform()
                        time.sleep(5)
                        print("DrillDown to ESU")
                        det4 = getlist()
                        kpi4 = KPI()
                        print(kpi4)
                        print("ESU: " + str(det4))
                        P_ok4 = det4[2]
                        print("ESU List: " + str(P_ok4))
                        time.sleep(3)
                        driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
                        if kpi4[0] != det4[3][0]:
                            bud = "Budget not matching for ESU"
                            print(bud)
                        if kpi4[1] != det4[4][0]:
                            ppv = "PPV not matching for ESU"
                            print(ppv)
                        print("DrillUP to EBU")
                        driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
                        time.sleep(3)
                        driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
                        time.sleep(3)
                    except (RuntimeError, TypeError, NameError, Exception, IndexError):
                        time.sleep(5)
                        DD3 = driver.find_elements_by_xpath(
                            "//h4[text()='BRANCH (EBU) PPV']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
                        print(l)
                        ActionChains(driver).move_to_element((DD3)[l]).perform()
                        time.sleep(5)
                        CL4 = driver.find_elements_by_xpath(
                            "//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
                        print("EBU: " + (CL4)[l].text)
                        print(l)
                        ActionChains(driver).click((CL4)[l]).perform()
                        time.sleep(5)
                        print("DrillDown to ESU")
                        det4 = getlist()
                        kpi4 = KPI()
                        print(kpi4)
                        print("ESU: " + str(det4))
                        P_ok4 = det4[2]
                        print("ESU List: " + str(P_ok4))
                        time.sleep(3)
                        driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
                        if kpi4[0] != det4[3][0]:
                            bud = "Budget not matching for ESU"
                            print(bud)
                        if kpi4[1] != det4[4][0]:
                            ppv = "PPV not matching for ESU"
                            print(ppv)
                        print("DrillUP to EBU")
                        driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
                        time.sleep(3)
                        driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
                        time.sleep(3)
                time.sleep(5)
                MoveEle = driver.find_element_by_xpath("(//div[@class='verticalCenter'])[5]")
                action = ActionChains(driver)
                action.move_to_element(MoveEle).perform()
                time.sleep(3)
                driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
                if kpi3[0] != det3[3][0]:
                    bud = "Budget not matching for EBU"
                    print(bud)
                if kpi3[1] != det3[4][0]:
                    ppv = "PPV not matching for EBU"
                    print(ppv)
                print("DrillUP to EBR")
                driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
                time.sleep(3)
                driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
                time.sleep(3)
        time.sleep(5)
        MoveEle = driver.find_element_by_xpath("(//div[@class='verticalCenter'])[5]")
        action = ActionChains(driver)
        action.move_to_element(MoveEle).perform()
        time.sleep(3)
        driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
        if kpi2[0] != det2[3][0]:
            bud = "Budget not matching for EBR"
            print(bud)
        if kpi2[1] != det2[4][0]:
            ppv = "PPV not matching for EBR"
            print(ppv)
        # print("DrillUP to Market")
        # driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
        # time.sleep(3)
        # driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
        # time.sleep(3)
        # time.sleep(5)
        # MoveEle = driver.find_element_by_xpath("(//div[@class='verticalCenter'])[5]")
        # action = ActionChains(driver)
        # action.move_to_element(MoveEle).perform()
        # time.sleep(3)
        # driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
        # if kpi1[0] != det1[3][0]:
        #     bud = "Budget not matching for Market"
        #     print(bud)
        # if kpi1[1] != det1[4][0]:
        #     ppv = "PPV not matching for Market"
        #     print(ppv)
        print("DrillUP to GEO")
        driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
        time.sleep(3)
        driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
        time.sleep(3)



# ----------------------Call Code Below-------------------

Login()

# For BU
BU_toggle()
BU_to_Level17() # Added KPI Validation

# For Geo
# DD_Geo() # Added KPI Validation working but getting stuck so use below one
DD_Geo_CG_Geo_manu() # Change Geo Manually for NA,EU,AP,LA
# DD_Geo_JP_GCG_MEA()




