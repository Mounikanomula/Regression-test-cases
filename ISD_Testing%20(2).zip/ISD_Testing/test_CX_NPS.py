'''
Profile Details
CX
User Role : Global Mkt -SVP & GM
Client Set : All
Geo : All
Market : All
Manager's Node : Not Applicable
'''
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
import re
import Login_Page
import ES_Page
import RD_Page
import AP_Page
import SP_Page
import KD_Page
import MI_Page
import Common
import Constants
import pytest
import locators
import CX_Nps


from selenium.webdriver.common.action_chains import ActionChains
# pytest ***.py
# pytest -v
#Allure reporting
    #python -m pytest ***.py --alluredir=C:\FilesFolders\Practice\PycharmProjects\2019\Skyline\ISD_Testing\Reports
    # goto the Reports folder from command line
    # in command line : allure generate C:\FilesFolders\Practice\PycharmProjects\2019\Skyline\ISD_Testing\Reports
    # open in Mozilla takes some time
from CX_Nps import Graph1_validation

driver = Login_Page.driver
def test_open():
    Login_Page.open_ISD()

def test_CX_tab():
    CX_Nps.CX_tab()

def test_cx_click():
    CX_Nps.Cx_clk()

def test_Breadcrumb():
    CX_Nps.Breadcrumb()

# def test_KPI_tiles_headers_relational():
#     CX_Nps.KPI_tiles_headers_relational()
#
# def test_KPI_Deal_list_Promoter():
#     CX_Nps.KPI_Deal_list_Promoter()
#
# def test_KPI_Deal_list_Passives():
#     CX_Nps.KPI_Deal_list_Passives()
#
# def test_KPI_Deal_list_DETRACTORS():
#     CX_Nps.KPI_Deal_list_DETRACTORS()

# def test_Gf_options():
#     CX_Nps.GF_validation()

# def test_Expand_Graphs():
#     CX_Nps.Expand_collapse()

def test_visual1():
    CX_Nps.Graph1_validation()
####################################### belongs to survey types###########
# def test_KPI_headers_survery():
#     CX_Nps.KPI_headers_survery()
#
# def test_kpi_deal_survey_prom():
#     CX_Nps.kpi_deal_survey_prom()
#
# def test_Kpi_deal_survey_pass():
#     CX_Nps.Kpi_deal_survey_pass()
#
# def test_Kpi_deal_survey_Det():
#     CX_Nps.Kpi_deal_survey_Det()


