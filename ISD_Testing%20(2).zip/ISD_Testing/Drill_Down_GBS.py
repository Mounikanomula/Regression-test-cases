from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
import re
from selenium.webdriver.common.action_chains import ActionChains

#No Auth Test URL
url="https://skyline.epm-sales-staging.us-south.containers.appdomain.cloud/esa-skyline-ibm-dev/uiappltest//esa-skyline-ibm-dev/uiappltest/?email=sktestin@in.ibm.com&firstname=Functional ID 2&bluegroups=ARDE_ALL&uid=07820E744&noauthentication=true"


def Login():
    global driver
    driver = webdriver.Chrome()
    driver.get(url)
    # u = driver.find_element_by_name('username')
    # u.send_keys('skytesti@in.ibm.com')
    # p = driver.find_element_by_name('password')
    # p.send_keys('SkylineTesting@3')
    # p.send_keys(Keys.RETURN)
    driver.maximize_window()
    time.sleep(20)

def getlist():
    max1="(//*[@name='icon--maximize'])"
    showhide="//*[@class='buttonShowHide']"
    firstrow="//*[@class='datatable-body-row datatable-row-even ng-star-inserted']"
    min1="(//*[@name='icon--minimize'])"
    # get datatable and get the index of the values which are not equal to 0
    P=[]
    P_ok=[]
    P_nok=[]
    B=[] #Budget
    PP=[] #PPV
    driver.find_element_by_xpath(max1).click()
    driver.find_element_by_xpath(showhide).click()
    tx=driver.find_elements_by_xpath(firstrow)
    t=0
    t2=0
    for ik in range(len(tx)):
        tx=driver.find_element_by_xpath('('+firstrow+')'+'['+str(ik+1)+']').text
        tx=tx.split('\n')
        try:
            float(tx[0])
            tx1='N/A'
        except(RuntimeError,TypeError,NameError,ValueError,Exception):
            tx1=tx[0]
            print(tx1)
        P.append(tx1)
        if len(tx)==18:
            tx2=tx[1].replace(",","")
            tx2=float(tx2) if tx2!="N/A" else 0
            t=t+tx2
            tx3=tx[3].replace(",","")
            tx3=float(tx3) if tx3!="N/A" else 0
            t2=t2+tx3
        else:
            tx2=tx[0].replace(",","")
            tx2=float(tx2) if tx2!="N/A" else 0
            t=t+tx2
            tx3=tx[2].replace(",","")
            tx3=float(tx3) if tx3!="N/A" else 0
            t2=t2+tx3

    driver.find_element_by_xpath(showhide).click()
    driver.find_element_by_xpath(min1).click()
    
    B.append(round(t))
    PP.append(round(t2))
        
#     B.append(t)
#     PP.append(t2)
    for k in range(len(P)):
        if P[k]=="N/A" or P[k]=="UNASSIGNED":
            P_nok.append(P.index(P[k]))
        else:
            P_ok.append(P.index(P[k]))
    return P_ok,P_nok,P,B,PP
    
        



# BU Drill Down

def BU_toggle():
    driver.find_element_by_xpath("(//label[@class='bx--radio-button__label'])[2]").click()  # BU Click
    time.sleep(3)

def bu_getlist():
    max1="(//*[@name='icon--maximize'])[2]"
    showhide="//*[@class='buttonShowHide']"
    firstrow="//*[@class='datatable-body-row datatable-row-even ng-star-inserted']"
    min1="(//*[@name='icon--minimize'])"
    # get datatable and get the index of the values which are not equal to 0
    P=[]
    P_ok=[]
    P_nok=[]
    B=[] #Budget
    PP=[] #PPV
#     for j in range(1,2):
    driver.find_element_by_xpath(max1).click()
    driver.find_element_by_xpath(showhide).click()
    tx=driver.find_elements_by_xpath(firstrow)
    t=0
    t2=0
    for ik in range(len(tx)):
        tx=driver.find_element_by_xpath('('+firstrow+')'+'['+str(ik+1)+']').text
        tx=tx.split('\n')
        try:
            float(tx[0])
            tx1="N/A"
        except(RuntimeError, TypeError, NameError, ValueError, Exception):
            tx1=tx[0]
            print(tx1)
        P.append(tx1)
        if len(tx)==18:
            tx2=tx[1].replace(",","")
            tx2=float(tx2) if tx2!="N/A" else 0
            t=t+tx2
            tx3=tx[3].replace(",","")
            tx3=float(tx3) if tx3!="N/A" else 0
            t2=t2+tx3
        else:
            tx2=tx[0].replace(",","")
            tx2=float(tx2) if tx2!="N/A" else 0
            t=t+tx2
            tx3=tx[2].replace(",","")
            tx3=float(tx3) if tx3!="N/A" else 0
            t2=t2+tx3    
    driver.find_element_by_xpath(showhide).click()
    driver.find_element_by_xpath(min1).click()
    B.append(round(t))
    PP.append(round(t2))
    for k in range(len(P)):
        if P[k]=="N/A" or P[k]=="UNASSIGNED":
            P_nok.append(P.index(P[k]))
        else:
            P_ok.append(P.index(P[k]))
    return P_ok,P_nok,P,B,PP

def es_kpi1(element):
    element = element.text
    element = element.split('\n')
    print(element)
    element_2 = element[1]
    print(element_2)
    if element_2.find("K")<0:
        element_2 = element_2.replace(",", "")
#         element_2 = re.findall(r'\d+', element_2)
        element_2 = re.findall(r'\d+\.?\d*', element_2)
#         element_2 = re.findall('^[-+]?\d*\.?\d*$', element_2)
        print(element_2)
        element_2 = element_2[0]
        element_2 = round(float(element_2))
    else:
        element_2 = element_2.replace(",", "").replace("$", "").replace("K", "")
        print(element_2)
        element_2 = re.findall(r'\d+\.?\d*', element_2)
        print(element_2)
        element_2 = element_2[0]
        element_2 = round(float(element_2)/1000)
    return element_2

def KPI():
    try:
        Budget = es_kpi1(driver.find_element_by_xpath("(//div[@class='verticalCenter'])[1]"))
        print("Budget: "+str(Budget))
    except (RuntimeError, TypeError, NameError, Exception):
        Budget = "Budget locator not found"
        pass
    try:
        PPV = es_kpi1(driver.find_element_by_xpath("(//div[@class='verticalCenter'])[4]"))
        print("PPV: "+str(PPV))
    except (RuntimeError, TypeError, NameError, Exception):
        PPV = "PPV locator not found"
        pass
    return Budget,PPV


# Click on get_list and BU_get_Lits, alos change to BU
# BU to BU Sub group to Level 17
def DD_BuSub_to_Level20():
    GH1= driver.find_elements_by_xpath("//h4[text()='BUSINESS UNIT SUBGROUP COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
    # TP=driver.find_element_by_xpath("//*[name()='ngx-tooltip-content']")
    s=len(GH1)

    # i=1
    det=getlist()
    kpi=KPI()
    print(kpi)
    print("BU SubGroup"+str(det))
    print(kpi[0],kpi[1],det[3][0],det[4][0])
    if kpi[0] != det[3][0]:
        bud = "Budget not matching for BU SubGroup"
        print(bud)
    if kpi[1] != det[4][0]:
        ppv = "PPV not matching for BU SubGroup"
        print(ppv)
    P_ok=det[0]
    # print("BU List: "+str(P_ok))
    # for i in P_ok:
    for i in [0,1,3]: # Removed Miscelenious as no DD
        time.sleep(5)
        GH1= driver.find_elements_by_xpath("//h4[text()='BUSINESS UNIT SUBGROUP COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
        print(i)
        time.sleep(3)
        ActionChains(driver).move_to_element_with_offset((GH1)[i],xoffset=1, yoffset=1).perform()
        time.sleep(5)
        CL= driver.find_elements_by_xpath("//h4[text()='BUSINESS UNIT SUBGROUP COV% (PPV)']//..//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
        print(i)
        print("BU SubGroup: "+(CL)[i].text)
    #     print(i)
    #     print(type(i))
        ActionChains(driver).click((CL)[i]).perform()
        time.sleep(5)
        print("DrillDown to Level 17")
        det1=bu_getlist()
        kpi1=KPI()
        print(kpi1)
    #     print("BU Sub Group: "+str(det1))
        P_ok1=det1[0]
        print("Level 17 Group List: "+str(det1[2]))
        for k in P_ok1:
            try:
                time.sleep(5)
                DD2= driver.find_elements_by_xpath("//h4[text()='LEVEL 17 COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
                print(k)
                ActionChains(driver).move_to_element_with_offset((DD2)[k],xoffset=1, yoffset=1).perform()
                CL2= driver.find_elements_by_xpath("//h4[text()='LEVEL 17 COV% (PPV)']//..//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
                print("Level 17: "+(CL2)[k].text)
                time.sleep(2)
                ActionChains(driver).click((CL2)[k]).perform()
                time.sleep(5)
                print("DrillDown to Level 20")
                det2=bu_getlist()
                kpi2=KPI()
                print(kpi2)
                P_ok2=det2[2]
                print("Level 20 List: "+str(P_ok2))
                driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
                print(kpi2[0],kpi2[1],det2[3][0],det2[4][0])
                if kpi2[0] != det2[3][0]:
                    bud = "Budget not matching for Level 20"
                    print(bud)
                if kpi2[1] != det2[4][0]:
                    ppv = "PPV not matching for Level 20"
                    print(ppv)
                print("DrillUP to Level 17")
                driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
                time.sleep(3)
                driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
                time.sleep(3)
            except (RuntimeError, TypeError, NameError, Exception,IndexError):
                time.sleep(5)
                DD2= driver.find_elements_by_xpath("//h4[text()='LEVEL 17 PPV']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
                print(k)
                ActionChains(driver).move_to_element_with_offset((DD2)[k],xoffset=1, yoffset=1).perform()
                CL2= driver.find_elements_by_xpath("//h4[text()='LEVEL 17 PPV']//..//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
                print("Level 17 Group: "+(CL2)[k].text)
                time.sleep(2)
                ActionChains(driver).click((CL2)[k]).perform()
                time.sleep(8)
                print("DrillDown to Level 20")
                det2=bu_getlist()
                kpi2=KPI()
                print(kpi2)
                P_ok2=det2[2]
                print("Level 20 List: "+str(P_ok2))
                time.sleep(2)
                driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
                print(kpi2[0],kpi2[1],det2[3][0],det2[4][0])
                if kpi2[0] != det2[3][0]:
                    bud = "Budget not matching for Level 20"
                    print(bud)
                if kpi2[1] != det2[4][0]:
                    ppv = "PPV not matching for Level 20"
                    print(ppv)
                print("DrillUP to Level 17")
                driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
                time.sleep(3)
                driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
                time.sleep(3)
        time.sleep(5)
        MoveEle=driver.find_element_by_xpath("(//div[@class='verticalCenter'])[5]")
        action = ActionChains(driver)
        action.move_to_element(MoveEle).perform()
        time.sleep(3)
        driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
        print(kpi1[0],kpi1[1],det1[3][0],det1[4][0])
        if kpi1[0] != det1[3][0]:
            bud = "Budget not matching for Level 17"
            print(bud)
        if kpi1[1] != det1[4][0]:
            ppv = "PPV not matching for Level 17"
            print(ppv)
        print("DrillUP to BU Sub Group")
        driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
        time.sleep(3)
        driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
        time.sleep(3)


#MEA,NA,JP,GCG (0,2,4,6)
def DD_Geo_MEA_NA_JP_GCG():
    GH1= driver.find_elements_by_xpath("//h4[text()='GEO COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
    # TP=driver.find_element_by_xpath("//*[name()='ngx-tooltip-content']")
    s=len(GH1)
    st=[]
    stDD1=[]
    stDD2=[]
    stDD3=[]
    stDD4=[]
    # i=1
    det=getlist()
    kpi=KPI()
    print(kpi)
    print("GEO "+str(det))
    print(kpi[0],kpi[1],det[3][0],det[4][0])
    if kpi[0] != det[3][0]:
        bud = "Budget not matching for Geo"
        print(bud)
    if kpi[1] != det[4][0]:
        ppv = "PPV not matching for Geo"
        print(ppv)
    P_ok=det[0]
    # print("BU List: "+str(P_ok))
    # for i in P_ok:
    for i in [0,2,4,6]:
        time.sleep(5)
        GH1= driver.find_elements_by_xpath("//h4[text()='GEO COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
        print(i)
        time.sleep(3)
        ActionChains(driver).move_to_element_with_offset((GH1)[i],xoffset=1, yoffset=1).perform()
        time.sleep(5)
        CL= driver.find_elements_by_xpath("//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
        print(i)
        print("Geo: "+(CL)[i].text)
    #     print(i)
    #     print(type(i))
        ActionChains(driver).click((CL)[i]).perform()
        time.sleep(5)
        print("DrillDown to GBS 2nd Level")
        det1=getlist()
        kpi1=KPI()
        print(det1)
        print(kpi1)
    #     print("BU Sub Group: "+str(det1))
        P_ok1=det1[0]
        print("GBS 2nd Level List: "+str(det1[2]))

        for k in P_ok1:
            try:
                time.sleep(5)
                DD2= driver.find_elements_by_xpath("//h4[text()='GBS BU 2nd LEVEL COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
                print(k)
                ActionChains(driver).move_to_element((DD2)[k]).perform()
                CL3= driver.find_elements_by_xpath("//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
                print("GBS BU 2nd: "+(CL3)[k].text)
                time.sleep(2)
    #                 print(k)
                ActionChains(driver).click((CL3)[k]).perform()
    #                 print(k)
    #                 print(type(k))
                time.sleep(5)
                print("DrillDown to GBS Business Unit")
                det3=getlist()
                kpi2=KPI()
                print(kpi2)
                print("GBS Business Unit: "+str(det3))
                P_ok3=det3[0]
                print("GBS Business Unit List: "+str(det3[2]))
                driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
                print(kpi2[0],kpi2[1],det3[3][0],det3[4][0])
                if kpi2[0] != det3[3][0]:
                    bud = "Budget not matching for GBS Business Unit"
                    print(bud)
                if kpi2[1] != det3[4][0]:
                    ppv = "PPV not matching for GBS Business Unit"
                    print(ppv)
                print("DrillUP to GBS BU 2nd")
                driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
                time.sleep(3)
                driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
                time.sleep(3)
            except (RuntimeError, TypeError, NameError, Exception,IndexError):
                time.sleep(5)
                DD2= driver.find_elements_by_xpath("//h4[text()='GBS BU 2nd LEVEL PPV']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
                print(k)
                ActionChains(driver).move_to_element((DD2)[k]).perform()
                CL3= driver.find_elements_by_xpath("//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
                print("GBS BU 2nd LEVEL: "+(CL3)[k].text)
                time.sleep(2)
    #                 print(k)
                ActionChains(driver).click((CL3)[k]).perform()
    #                 print(k)
    #                 print(type(k))
                time.sleep(5)
                print("DrillDown to GBS Business Unit")
                det3=getlist()
                kpi2=KPI()
                print("GBS Business Unit: "+str(det3))
                P_ok3=det3[0]
                print("GBS Business Unit List: "+str(det3[2]))
                driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
                print(kpi2[0],kpi2[1],det3[3][0],det3[4][0])
                if kpi2[0] != det3[3][0]:
                    bud = "Budget not matching for GBS Business Unit"
                    print(bud)
                if kpi2[1] != det3[4][0]:
                    ppv = "PPV not matching for GBS Business Unit"
                    print(ppv)
                print("DrillUP to GBS BU 2nd LEVEL")
                driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
                time.sleep(3)
                driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
                time.sleep(3)
        time.sleep(5)
        MoveEle=driver.find_element_by_xpath("(//div[@class='verticalCenter'])[5]")
        action = ActionChains(driver)
        action.move_to_element(MoveEle).perform()
        time.sleep(3)
        driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
        print(kpi1[0],kpi1[1],det1[3][0],det1[4][0])
        if kpi1[0] != det1[3][0]:
            bud = "Budget not matching for GBS BU 2nd LEVEL"
            print(bud)
        if kpi1[1] != det1[4][0]:
            ppv = "PPV not matching for GBS BU 2nd LEVEL"
            print(ppv)
        print("DrillUP to GEO")
        driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
        time.sleep(3)
        driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
        time.sleep(3)


#Europe mkt=="BeNeLux" ,"France Market","Italy Market","UKI"
def DD_Geo_EuropeMkt_BeNeLux_FranceMarket_ItalyMarket_UKI():
    GH1= driver.find_elements_by_xpath("//h4[text()='GEO COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
    # TP=driver.find_element_by_xpath("//*[name()='ngx-tooltip-content']")
    s=len(GH1)
    st=[]
    stDD1=[]
    stDD2=[]
    stDD3=[]
    stDD4=[]
    # i=1
    det=getlist()
    kpi=KPI()
    print(kpi)
    print("GEO "+str(det))
    print(kpi[0],kpi[1],det[3][0],det[4][0])
    if kpi[0] != det[3][0]:
        bud = "Budget not matching for Geo"
        print(bud)
    if kpi[1] != det[4][0]:
        ppv = "PPV not matching for Geo"
        print(ppv)
    P_ok=det[0]
    # print("BU List: "+str(P_ok))
    # for i in P_ok:
    for i in [1]:
        time.sleep(5)
        GH1= driver.find_elements_by_xpath("//h4[text()='GEO COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
        print(i)
        time.sleep(3)
        ActionChains(driver).move_to_element_with_offset((GH1)[i],xoffset=1, yoffset=1).perform()
        time.sleep(5)
        CL= driver.find_elements_by_xpath("//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
        print(i)
        print("Geo: "+(CL)[i].text)
    #     print(i)
    #     print(type(i))
        ActionChains(driver).click((CL)[i]).perform()
        time.sleep(5)
        print("DrillDown to Market")
        det1=getlist()
        kpi1=KPI()
        print(det1)
        print(kpi1)
    #     print("BU Sub Group: "+str(det1))
        P_ok1=det1[0]
        print("Market List: "+str(det1[2]))
    #     for j in P_ok1:
        for j in [0,3,4,7]:
    #         try:
            time.sleep(5)
            DD1= driver.find_elements_by_xpath("//h4[text()='MARKET COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
            print(j)
            ActionChains(driver).move_to_element_with_offset((DD1)[j],xoffset=1, yoffset=1).perform()
            CL2= driver.find_elements_by_xpath("//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
            print("Market Group: "+(CL2)[j].text)
            mkt=(CL2)[j].text
            time.sleep(2)
            ActionChains(driver).click((CL2)[j]).perform()
            time.sleep(5)
            if mkt=="BeNeLux" or mkt=="France Market" or mkt=="Italy Market" or mkt=="UKI":
                print("DrillDown to GBS BU 2nd LEVEL")
                det2=getlist()
                kpi2=KPI()
                P_ok2=det2[0]
                print("GBS BU 2nd LEVEL List: "+str(det2[2]))
                for k in P_ok2:
                    try:
                        time.sleep(5)
                        DD2= driver.find_elements_by_xpath("//h4[text()='GBS BU 2nd LEVEL COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
                        print(k)
                        ActionChains(driver).move_to_element((DD2)[k]).perform()
                        CL3= driver.find_elements_by_xpath("//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
                        print("GBS BU 2nd: "+(CL3)[k].text)
                        time.sleep(2)
            #                 print(k)
                        ActionChains(driver).click((CL3)[k]).perform()
            #                 print(k)
            #                 print(type(k))
                        time.sleep(5)
                        print("DrillDown to GBS Business Unit")
                        det3=getlist()
                        kpi3=KPI()
                        print(kpi2)
                        print("GBS Business Unit: "+str(det3))
                        P_ok3=det3[0]
                        print("GBS Business Unit List: "+str(det3[2]))
                        driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
                        print(kpi3[0],kpi3[1],det3[3][0],det3[4][0])
                        if kpi3[0] != det3[3][0]:
                            bud = "Budget not matching for GBS Business Unit"
                            print(bud)
                        if kpi3[1] != det3[4][0]:
                            ppv = "PPV not matching for GBS Business Unit"
                            print(ppv)
                        print("DrillUP to GBS BU 2nd")
                        driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
                        time.sleep(3)
                        driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
                        time.sleep(3)
                    except (RuntimeError, TypeError, NameError, Exception,IndexError):
                        time.sleep(5)
                        DD2= driver.find_elements_by_xpath("//h4[text()='GBS BU 2nd LEVEL PPV']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
                        print(k)
                        ActionChains(driver).move_to_element((DD2)[k]).perform()
                        CL3= driver.find_elements_by_xpath("//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
                        print("GBS BU 2nd LEVEL: "+(CL3)[k].text)
                        time.sleep(2)
            #                 print(k)
                        ActionChains(driver).click((CL3)[k]).perform()
            #                 print(k)
            #                 print(type(k))
                        time.sleep(5)
                        print("DrillDown to GBS Business Unit")
                        det3=getlist()
                        kpi3=KPI()
                        print("GBS Business Unit: "+str(det3))
                        P_ok3=det3[0]
                        print("GBS Business Unit List: "+str(det3[2]))
                        driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
                        print(kpi2[0],kpi2[1],det3[3][0],det3[4][0])
                        if kpi3[0] != det3[3][0]:
                            bud = "Budget not matching for GBS Business Unit"
                            print(bud)
                        if kpi3[1] != det3[4][0]:
                            ppv = "PPV not matching for GBS Business Unit"
                            print(ppv)
                        print("DrillUP to GBS BU 2nd LEVEL")
                        driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
                        time.sleep(3)
                        driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
                        time.sleep(3)

            time.sleep(5)
            MoveEle=driver.find_element_by_xpath("(//div[@class='verticalCenter'])[5]")
            action = ActionChains(driver)
            action.move_to_element(MoveEle).perform()
            time.sleep(3)
            driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
            print(kpi2[0],kpi2[1],det2[3][0],det2[4][0])
            if kpi2[0] != det2[3][0]:
                bud = "Budget not matching for GBS BU 2nd LEVEL"
                print(bud)
            if kpi2[1] != det2[4][0]:
                ppv = "PPV not matching for GBS BU 2nd LEVEL"
                print(ppv)
            print("DrillUP to Market")
            driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
            time.sleep(3)
            driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
            time.sleep(3)
        time.sleep(5)
        MoveEle=driver.find_element_by_xpath("(//div[@class='verticalCenter'])[5]")
        action = ActionChains(driver)
        action.move_to_element(MoveEle).perform()
        time.sleep(3)
        driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
        print(kpi1[0],kpi1[1],det1[3][0],det1[4][0])
        if kpi1[0] != det1[3][0]:
            bud = "Budget not matching for Market"
            print(bud)
        if kpi1[1] != det1[4][0]:
            ppv = "PPV not matching for Market"
            print(ppv)
        print("DrillUP to GEO")
        driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
        time.sleep(3)
        driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
        time.sleep(3)



#Europe mkt=="DACH","Nordic","SPGI"
def DD_Geo_EuropeMkt_DACH_Nordic_SPGI():
    GH1= driver.find_elements_by_xpath("//h4[text()='GEO COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
    # TP=driver.find_element_by_xpath("//*[name()='ngx-tooltip-content']")
    s=len(GH1)
    st=[]
    stDD1=[]
    stDD2=[]
    stDD3=[]
    stDD4=[]
    # i=1
    det=getlist()
    kpi=KPI()
    print(kpi)
    print("GEO "+str(det))
    print(kpi[0],kpi[1],det[3][0],det[4][0])
    if kpi[0] != det[3][0]:
        bud = "Budget not matching for Geo"
        print(bud)
    if kpi[1] != det[4][0]:
        ppv = "PPV not matching for Geo"
        print(ppv)
    P_ok=det[0]
    # print("BU List: "+str(P_ok))
    # for i in P_ok:
    for i in [1]:
        time.sleep(5)
        GH1= driver.find_elements_by_xpath("//h4[text()='GEO COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
        print(i)
        time.sleep(3)
        ActionChains(driver).move_to_element_with_offset((GH1)[i],xoffset=1, yoffset=1).perform()
        time.sleep(5)
        CL= driver.find_elements_by_xpath("//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
        print(i)
        print("Geo: "+(CL)[i].text)
    #     print(i)
    #     print(type(i))
        ActionChains(driver).click((CL)[i]).perform()
        time.sleep(5)
        print("DrillDown to Market")
        det1=getlist()
        kpi1=KPI()
        print(det1)
        print(kpi1)
    #     print("BU Sub Group: "+str(det1))
        P_ok1=det1[0]
        print("Market List: "+str(det1[2]))
    #     for j in P_ok1:
        for j in [2,5,6]:
    #         try:
            time.sleep(5)
            DD1= driver.find_elements_by_xpath("//h4[text()='MARKET COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
            print(j)
            ActionChains(driver).move_to_element_with_offset((DD1)[j],xoffset=1, yoffset=1).perform()
            CL2= driver.find_elements_by_xpath("//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
            print("Market Group: "+(CL2)[j].text)
            mkt=(CL2)[j].text
            time.sleep(2)
            ActionChains(driver).click((CL2)[j]).perform()
            time.sleep(5)
            if mkt=="DACH" or mkt=="Nordic" or mkt=="SPGI":
    #         elif mkt=="CEE Mkt":
                print("DrillDown to Country")
                det2=getlist()
                kpi2=KPI()
                P_ok2=det2[0]
                print("Country List: "+str(det2[2]))
                driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
                print(kpi2[0],kpi2[1],det2[3][0],det2[4][0])
                if kpi2[0] != det2[3][0]:
                    bud = "Budget not matching for Country"
                    print(bud)
                if kpi2[1] != det2[4][0]:
                    ppv = "PPV not matching for Country"
                    print(ppv)
                print("DrillUP to Market")
    #             driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
    #             time.sleep(3)
    #             driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
                time.sleep(3)
        time.sleep(5)
        MoveEle=driver.find_element_by_xpath("(//div[@class='verticalCenter'])[5]")
        action = ActionChains(driver)
        action.move_to_element(MoveEle).perform()
        time.sleep(3)
        driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
        print(kpi1[0],kpi1[1],det1[3][0],det1[4][0])
        if kpi1[0] != det1[3][0]:
            bud = "Budget not matching for Market"
            print(bud)
        if kpi1[1] != det1[4][0]:
            ppv = "PPV not matching for Market"
            print(ppv)
        print("DrillUP to GEO")
    #     driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
    #     time.sleep(3)
    #     driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
        time.sleep(3)


# Europe
def DD_Geo_EuropeMKT_CEE():
    GH1 = driver.find_elements_by_xpath(
        "//h4[text()='GEO COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
    # TP=driver.find_element_by_xpath("//*[name()='ngx-tooltip-content']")
    s = len(GH1)
    # i=1
    det = getlist()
    kpi = KPI()
    print(kpi)
    print("GEO " + str(det))
    print(kpi[0], kpi[1], det[3][0], det[4][0])
    if kpi[0] != det[3][0]:
        bud = "Budget not matching for Geo"
        print(bud)
    if kpi[1] != det[4][0]:
        ppv = "PPV not matching for Geo"
        print(ppv)
    P_ok = det[0]
    # print("BU List: "+str(P_ok))
    # for i in P_ok:
    for i in [1]:
        time.sleep(5)
        GH1 = driver.find_elements_by_xpath(
            "//h4[text()='GEO COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
        print(i)
        time.sleep(3)
        ActionChains(driver).move_to_element_with_offset((GH1)[i], xoffset=1, yoffset=1).perform()
        time.sleep(5)
        CL = driver.find_elements_by_xpath("//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
        print(i)
        print("Geo: " + (CL)[i].text)
        #     print(i)
        #     print(type(i))
        ActionChains(driver).click((CL)[i]).perform()
        time.sleep(5)
        print("DrillDown to Market")
        det1 = getlist()
        kpi1 = KPI()
        print(det1)
        print(kpi1)
        #     print("BU Sub Group: "+str(det1))
        P_ok1 = det1[0]
        print("Market List: " + str(det1[2]))
        for j in [1]:
            #     for j in [1]:
            #         try:
            time.sleep(5)
            DD1 = driver.find_elements_by_xpath(
                "//h4[text()='MARKET COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
            print(j)
            ActionChains(driver).move_to_element_with_offset((DD1)[j], xoffset=1, yoffset=1).perform()
            CL2 = driver.find_elements_by_xpath("//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
            print("Market Group: " + (CL2)[j].text)
            mkt = (CL2)[j].text
            time.sleep(2)
            ActionChains(driver).click((CL2)[j]).perform()
            time.sleep(5)
            if mkt == "CEE Mkt":
                print("DrillDown to BRANCH EBU")
                det2 = getlist()
                kpi2 = KPI()
                P_ok2 = det2[0]
                print("GBS BRANCH EBU List: " + str(det2[2]))
                for k1 in P_ok2:
                    try:
                        time.sleep(5)
                        DD2 = driver.find_elements_by_xpath(
                            "//h4[text()='BRANCH (EBU) COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
                        print(k1)
                        ActionChains(driver).move_to_element((DD2)[k1]).perform()
                        CL3 = driver.find_elements_by_xpath(
                            "//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
                        print("EBU: " + (CL3)[k1].text)
                        time.sleep(2)
                        #                 print(k)
                        ActionChains(driver).click((CL3)[k1]).perform()
                        #                 print(k)
                        #                 print(type(k))
                        time.sleep(5)
                        print("DrillDown to GBS BU 2nd LEVEL")
                        det4 = getlist()
                        kpi4 = KPI()
                        print("GBS BU 2nd LEVEL: " + str(det4))
                        P_ok4 = det4[0]
                        print("GBS BU 2nd LEVEL List: " + str(det4[2]))
                        for k in P_ok4:
                            try:
                                time.sleep(5)
                                DD2 = driver.find_elements_by_xpath(
                                    "//h4[text()='GBS BU 2nd LEVEL COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
                                print(k)
                                ActionChains(driver).move_to_element((DD2)[k]).perform()
                                CL3 = driver.find_elements_by_xpath(
                                    "//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
                                print("GBS BU 2nd: " + (CL3)[k].text)
                                time.sleep(2)
                                #                 print(k)
                                ActionChains(driver).click((CL3)[k]).perform()
                                #                 print(k)
                                #                 print(type(k))
                                time.sleep(5)
                                print("DrillDown to GBS Business Unit")
                                det3 = getlist()
                                kpi3 = KPI()
                                print(kpi2)
                                print("GBS Business Unit: " + str(det3))
                                P_ok3 = det3[0]
                                print("GBS Business Unit List: " + str(det3[2]))
                                driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
                                print(kpi3[0], kpi3[1], det3[3][0], det3[4][0])
                                if kpi3[0] != det3[3][0]:
                                    bud = "Budget not matching for GBS Business Unit"
                                    print(bud)
                                if kpi3[1] != det3[4][0]:
                                    ppv = "PPV not matching for GBS Business Unit"
                                    print(ppv)
                                print("DrillUP to GBS BU 2nd")
                                driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
                                time.sleep(3)
                                driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
                                time.sleep(3)
                            except (RuntimeError, TypeError, NameError, Exception, IndexError):
                                time.sleep(5)
                                DD2 = driver.find_elements_by_xpath(
                                    "//h4[text()='GBS BU 2nd LEVEL PPV']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
                                print(k)
                                ActionChains(driver).move_to_element((DD2)[k]).perform()
                                CL3 = driver.find_elements_by_xpath(
                                    "//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
                                print("GBS BU 2nd LEVEL: " + (CL3)[k].text)
                                time.sleep(2)
                                #                 print(k)
                                ActionChains(driver).click((CL3)[k]).perform()
                                #                 print(k)
                                #                 print(type(k))
                                time.sleep(5)
                                print("DrillDown to GBS Business Unit")
                                det3 = getlist()
                                kpi3 = KPI()
                                print("GBS Business Unit: " + str(det3))
                                P_ok3 = det3[0]
                                print("GBS Business Unit List: " + str(det3[2]))
                                driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
                                print(kpi3[0], kpi3[1], det3[3][0], det3[4][0])
                                if kpi3[0] != det3[3][0]:
                                    bud = "Budget not matching for GBS Business Unit"
                                    print(bud)
                                if kpi3[1] != det3[4][0]:
                                    ppv = "PPV not matching for GBS Business Unit"
                                    print(ppv)
                                print("DrillUP to GBS BU 2nd LEVEL")
                                driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
                                time.sleep(3)
                                driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
                                time.sleep(3)
                        time.sleep(5)
                        MoveEle = driver.find_element_by_xpath("(//div[@class='verticalCenter'])[5]")
                        action = ActionChains(driver)
                        action.move_to_element(MoveEle).perform()
                        time.sleep(3)
                        driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
                        print(kpi4[0], kpi4[1], det4[3][0], det4[4][0])
                        if kpi4[0] != det4[3][0]:
                            bud = "Budget not matching for GBS BU 2nd LEVEL"
                            print(bud)
                        if kpi4[1] != det4[4][0]:
                            ppv = "PPV not matching for GBS BU 2nd LEVEL"
                            print(ppv)
                        print("DrillUP to EBU")
                        driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
                        time.sleep(3)
                        driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
                        time.sleep(3)
                    except (RuntimeError, TypeError, NameError, Exception, IndexError):
                        time.sleep(5)
                        DD2 = driver.find_elements_by_xpath(
                            "//h4[text()='BRANCH (EBU) COV']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
                        print(k1)
                        ActionChains(driver).move_to_element((DD2)[k1]).perform()
                        CL3 = driver.find_elements_by_xpath(
                            "//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
                        print("EBU: " + (CL3)[k1].text)
                        time.sleep(2)
                        #                 print(k)
                        ActionChains(driver).click((CL3)[k1]).perform()
                        #                 print(k)
                        #                 print(type(k))
                        time.sleep(5)
                        print("DrillDown to GBS BU 2nd LEVEL")
                        det4 = getlist()
                        kpi4 = KPI()
                        print("GBS BU 2nd LEVEL: " + str(det4))
                        P_ok4 = det4[0]
                        print("GBS BU 2nd LEVEL List: " + str(det4[2]))
                        for k in P_ok4:
                            try:
                                time.sleep(5)
                                DD2 = driver.find_elements_by_xpath(
                                    "//h4[text()='GBS BU 2nd LEVEL COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
                                print(k)
                                ActionChains(driver).move_to_element((DD2)[k]).perform()
                                CL3 = driver.find_elements_by_xpath(
                                    "//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
                                print("GBS BU 2nd: " + (CL3)[k].text)
                                time.sleep(2)
                                #                 print(k)
                                ActionChains(driver).click((CL3)[k]).perform()
                                #                 print(k)
                                #                 print(type(k))
                                time.sleep(5)
                                print("DrillDown to GBS Business Unit")
                                det3 = getlist()
                                kpi3 = KPI()
                                print(kpi2)
                                print("GBS Business Unit: " + str(det3))
                                P_ok3 = det3[0]
                                print("GBS Business Unit List: " + str(det3[2]))
                                driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
                                print(kpi3[0], kpi3[1], det3[3][0], det3[4][0])
                                if kpi3[0] != det3[3][0]:
                                    bud = "Budget not matching for GBS Business Unit"
                                    print(bud)
                                if kpi3[1] != det3[4][0]:
                                    ppv = "PPV not matching for GBS Business Unit"
                                    print(ppv)
                                print("DrillUP to GBS BU 2nd")
                                driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
                                time.sleep(3)
                                driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
                                time.sleep(3)
                            except (RuntimeError, TypeError, NameError, Exception, IndexError):
                                time.sleep(5)
                                DD2 = driver.find_elements_by_xpath(
                                    "//h4[text()='GBS BU 2nd LEVEL PPV']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
                                print(k)
                                ActionChains(driver).move_to_element((DD2)[k]).perform()
                                CL3 = driver.find_elements_by_xpath(
                                    "//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
                                print("GBS BU 2nd LEVEL: " + (CL3)[k].text)
                                time.sleep(2)
                                #                 print(k)
                                ActionChains(driver).click((CL3)[k]).perform()
                                #                 print(k)
                                #                 print(type(k))
                                time.sleep(5)
                                print("DrillDown to GBS Business Unit")
                                det3 = getlist()
                                kpi3 = KPI()
                                print("GBS Business Unit: " + str(det3))
                                P_ok3 = det3[0]
                                print("GBS Business Unit List: " + str(det3[2]))
                                driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
                                print(kpi3[0], kpi3[1], det3[3][0], det3[4][0])
                                if kpi3[0] != det3[3][0]:
                                    bud = "Budget not matching for GBS Business Unit"
                                    print(bud)
                                if kpi3[1] != det3[4][0]:
                                    ppv = "PPV not matching for GBS Business Unit"
                                    print(ppv)
                                print("DrillUP to GBS BU 2nd LEVEL")
                                driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
                                time.sleep(3)
                                driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
                                time.sleep(3)
                        time.sleep(5)
                        MoveEle = driver.find_element_by_xpath("(//div[@class='verticalCenter'])[5]")
                        action = ActionChains(driver)
                        action.move_to_element(MoveEle).perform()
                        time.sleep(3)
                        driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
                        print(kpi4[0], kpi4[1], det4[3][0], det4[4][0])
                        if kpi4[0] != det4[3][0]:
                            bud = "Budget not matching for GBS BU 2nd LEVEL"
                            print(bud)
                        if kpi4[1] != det4[4][0]:
                            ppv = "PPV not matching for GBS BU 2nd LEVEL"
                            print(ppv)
                        print("DrillUP to EBU")
                        driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
                        time.sleep(3)
                        driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
                        time.sleep(3)
                time.sleep(5)
                MoveEle = driver.find_element_by_xpath("(//div[@class='verticalCenter'])[5]")
                action = ActionChains(driver)
                action.move_to_element(MoveEle).perform()
                time.sleep(3)
                driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
                print(kpi2[0], kpi2[1], det2[3][0], det2[4][0])
                if kpi2[0] != det2[3][0]:
                    bud = "Budget not matching for EBU"
                    print(bud)
                if kpi2[1] != det2[4][0]:
                    ppv = "PPV not matching for EBU"
                    print(ppv)
                print("DrillUP to Market")
                driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
                time.sleep(3)
                driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
                time.sleep(3)
        time.sleep(5)
        MoveEle = driver.find_element_by_xpath("(//div[@class='verticalCenter'])[5]")
        action = ActionChains(driver)
        action.move_to_element(MoveEle).perform()
        time.sleep(3)
        driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
        print(kpi1[0], kpi1[1], det1[3][0], det1[4][0])
        if kpi1[0] != det1[3][0]:
            bud = "Budget not matching for Market"
            print(bud)
        if kpi1[1] != det1[4][0]:
            ppv = "PPV not matching for Market"
            print(ppv)
        print("DrillUP to Geo")
        driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
        time.sleep(3)
        driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
        time.sleep(3)

#===



#Latin America
def DD_Geo_LA():
    GH1= driver.find_elements_by_xpath("//h4[text()='GEO COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
    # TP=driver.find_element_by_xpath("//*[name()='ngx-tooltip-content']")
    s=len(GH1)
    st=[]
    stDD1=[]
    stDD2=[]
    stDD3=[]
    stDD4=[]
    # i=1
    det=getlist()
    kpi=KPI()
    print(kpi)
    print("GEO "+str(det))
    print(kpi[0],kpi[1],det[3][0],det[4][0])
    if kpi[0] != det[3][0]:
        bud = "Budget not matching for Geo"
        print(bud)
    if kpi[1] != det[4][0]:
        ppv = "PPV not matching for Geo"
        print(ppv)
    P_ok=det[0]
    # print("BU List: "+str(P_ok))
    # for i in P_ok:
    for i in [5]:
        time.sleep(5)
        GH1= driver.find_elements_by_xpath("//h4[text()='GEO COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
        print(i)
        time.sleep(3)
        ActionChains(driver).move_to_element_with_offset((GH1)[i],xoffset=1, yoffset=1).perform()
        time.sleep(5)
        CL= driver.find_elements_by_xpath("//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
        print(i)
        print("Geo: "+(CL)[i].text)
    #     print(i)
    #     print(type(i))
        ActionChains(driver).click((CL)[i]).perform()
        time.sleep(5)
        print("DrillDown to Market")
        det1=getlist()
        kpi1=KPI()
        print(det1)
        print(kpi1)
    #     print("BU Sub Group: "+str(det1))
        P_ok1=det1[0]
        print("Market List: "+str(det1[2]))
        for j in P_ok1:
    #     for j in [0,1]:
    #         try:
            time.sleep(5)
            DD1= driver.find_elements_by_xpath("//h4[text()='MARKET COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
            print(j)
            ActionChains(driver).move_to_element_with_offset((DD1)[j],xoffset=1, yoffset=1).perform()
            CL2= driver.find_elements_by_xpath("//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
            print("Market Group: "+(CL2)[j].text)
            mkt=(CL2)[j].text
            time.sleep(2)
            ActionChains(driver).click((CL2)[j]).perform()
            time.sleep(5)
            if mkt=="Brazil Market" or mkt=="Mexico Market":
                print("DrillDown to GBS BU 2nd LEVEL")
                det2=getlist()
                kpi2=KPI()
                P_ok2=det2[0]
                print("GBS BU 2nd LEVEL List: "+str(det2[2]))
                for k in P_ok2:
                    try:
                        time.sleep(5)
                        DD2= driver.find_elements_by_xpath("//h4[text()='GBS BU 2nd LEVEL COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
                        print(k)
                        ActionChains(driver).move_to_element((DD2)[k]).perform()
                        CL3= driver.find_elements_by_xpath("//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
                        print("GBS BU 2nd: "+(CL3)[k].text)
                        time.sleep(2)
            #                 print(k)
                        ActionChains(driver).click((CL3)[k]).perform()
            #                 print(k)
            #                 print(type(k))
                        time.sleep(5)
                        print("DrillDown to GBS Business Unit")
                        det3=getlist()
                        kpi3=KPI()
                        print(kpi2)
                        print("GBS Business Unit: "+str(det3))
                        P_ok3=det3[0]
                        print("GBS Business Unit List: "+str(det3[2]))
                        driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
                        print(kpi3[0],kpi3[1],det3[3][0],det3[4][0])
                        if kpi3[0] != det3[3][0]:
                            bud = "Budget not matching for GBS Business Unit"
                            print(bud)
                        if kpi3[1] != det3[4][0]:
                            ppv = "PPV not matching for GBS Business Unit"
                            print(ppv)
                        print("DrillUP to GBS BU 2nd")
                        driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
                        time.sleep(3)
                        driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
            #                     time.sleep(3)
                    except (RuntimeError, TypeError, NameError, Exception,IndexError):
                        time.sleep(5)
                        DD2= driver.find_elements_by_xpath("//h4[text()='GBS BU 2nd LEVEL PPV']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
                        print(k)
                        ActionChains(driver).move_to_element((DD2)[k]).perform()
                        CL3= driver.find_elements_by_xpath("//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
                        print("GBS BU 2nd LEVEL: "+(CL3)[k].text)
                        time.sleep(2)
            #                 print(k)
                        ActionChains(driver).click((CL3)[k]).perform()
            #                 print(k)
            #                 print(type(k))
                        time.sleep(5)
                        print("DrillDown to GBS Business Unit")
                        det3=getlist()
                        kpi3=KPI()
                        print("GBS Business Unit: "+str(det3))
                        P_ok3=det3[0]
                        print("GBS Business Unit List: "+str(det3[2]))
                        driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
                        print(kpi2[0],kpi2[1],det3[3][0],det3[4][0])
                        if kpi3[0] != det3[3][0]:
                            bud = "Budget not matching for GBS Business Unit"
                            print(bud)
                        if kpi3[1] != det3[4][0]:
                            ppv = "PPV not matching for GBS Business Unit"
                            print(ppv)
                        print("DrillUP to GBS BU 2nd LEVEL")
                        driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
                        time.sleep(3)
                        driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
    #                     time.sleep(3)
    #         time.sleep(3)
                time.sleep(5)
                MoveEle=driver.find_element_by_xpath("(//div[@class='verticalCenter'])[5]")
                action = ActionChains(driver)
                action.move_to_element(MoveEle).perform()
                time.sleep(3)
                driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
                print(kpi2[0],kpi2[1],det2[3][0],det2[4][0])
                if kpi2[0] != det2[3][0]:
                    bud = "Budget not matching for GBS BU 2nd LEVEL"
                    print(bud)
                if kpi2[1] != det2[4][0]:
                    ppv = "PPV not matching for GBS BU 2nd LEVEL"
                    print(ppv)
                print("DrillUP to Market")
                driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
                time.sleep(3)
                driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
                time.sleep(3)

            if mkt=="Spanish S. Ameri...":
    #         elif mkt=="CEE Mkt":
                print("DrillDown to Country")
                det2=getlist()
                kpi2=KPI()
                P_ok2=det2[0]
                print("Country List: "+str(det2[2]))
                driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
                print(kpi2[0],kpi2[1],det2[3][0],det2[4][0])
                if kpi2[0] != det2[3][0]:
                    bud = "Budget not matching for Country"
                    print(bud)
                if kpi2[1] != det2[4][0]:
                    ppv = "PPV not matching for Country"
                    print(ppv)
                print("DrillUP to Market")
    #             driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
    #             time.sleep(3)
    #             driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
                time.sleep(3)
        time.sleep(5)
        MoveEle=driver.find_element_by_xpath("(//div[@class='verticalCenter'])[5]")
        action = ActionChains(driver)
        action.move_to_element(MoveEle).perform()
        time.sleep(3)
        driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
        print(kpi1[0],kpi1[1],det1[3][0],det1[4][0])
        if kpi1[0] != det1[3][0]:
            bud = "Budget not matching for Market"
            print(bud)
        if kpi1[1] != det1[4][0]:
            ppv = "PPV not matching for Market"
            print(ppv)
        print("DrillUP to GEO")
        driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
        time.sleep(3)
        driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
        time.sleep(3)


#Asia Pacific
def DD_Geo_AP():
    GH1= driver.find_elements_by_xpath("//h4[text()='GEO COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
    # TP=driver.find_element_by_xpath("//*[name()='ngx-tooltip-content']")
    s=len(GH1)
    st=[]
    stDD1=[]
    stDD2=[]
    stDD3=[]
    stDD4=[]
    # i=1
    det=getlist()
    kpi=KPI()
    print(kpi)
    print("GEO "+str(det))
    print(kpi[0],kpi[1],det[3][0],det[4][0])
    if kpi[0] != det[3][0]:
        bud = "Budget not matching for Geo"
        print(bud)
    if kpi[1] != det[4][0]:
        ppv = "PPV not matching for Geo"
        print(ppv)
    P_ok=det[0]
    # print("BU List: "+str(P_ok))
    # for i in P_ok:
    for i in [3]:
        time.sleep(5)
        GH1= driver.find_elements_by_xpath("//h4[text()='GEO COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
        print(i)
        time.sleep(3)
        ActionChains(driver).move_to_element_with_offset((GH1)[i],xoffset=1, yoffset=1).perform()
        time.sleep(5)
        CL= driver.find_elements_by_xpath("//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
        print(i)
        print("Geo: "+(CL)[i].text)
    #     print(i)
    #     print(type(i))
        ActionChains(driver).click((CL)[i]).perform()
        time.sleep(5)
        print("DrillDown to Market")
        det1=getlist()
        kpi1=KPI()
        print(det1)
        print(kpi1)
    #     print("BU Sub Group: "+str(det1))
        P_ok1=det1[0]
        print("Market List: "+str(det1[2]))
        for j in P_ok1:
    #     for j in [0,1]:
    #         try:
            time.sleep(5)
            DD1= driver.find_elements_by_xpath("//h4[text()='MARKET COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
            print(j)
            ActionChains(driver).move_to_element_with_offset((DD1)[j],xoffset=1, yoffset=1).perform()
            CL2= driver.find_elements_by_xpath("//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
            print("Market Group: "+(CL2)[j].text)
            mkt=(CL2)[j].text
            time.sleep(2)
            ActionChains(driver).click((CL2)[j]).perform()
            time.sleep(5)
            if mkt=="Australia/NZ" or mkt=="India-South Asia" or mkt=="Korea Market":
                print("DrillDown to GBS BU 2nd LEVEL")
                det2=getlist()
                kpi2=KPI()
                P_ok2=det2[0]
                print("GBS BU 2nd LEVEL List: "+str(det2[2]))
                for k in P_ok2:
                    try:
                        time.sleep(5)
                        DD2= driver.find_elements_by_xpath("//h4[text()='GBS BU 2nd LEVEL COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
                        print(k)
                        ActionChains(driver).move_to_element((DD2)[k]).perform()
                        CL3= driver.find_elements_by_xpath("//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
                        print("GBS BU 2nd: "+(CL3)[k].text)
                        time.sleep(2)
            #                 print(k)
                        ActionChains(driver).click((CL3)[k]).perform()
            #                 print(k)
            #                 print(type(k))
                        time.sleep(5)
                        print("DrillDown to GBS Business Unit")
                        det3=getlist()
                        kpi3=KPI()
                        print(kpi2)
                        print("GBS Business Unit: "+str(det3))
                        P_ok3=det3[0]
                        print("GBS Business Unit List: "+str(det3[2]))
                        driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
                        print(kpi3[0],kpi3[1],det3[3][0],det3[4][0])
                        if kpi3[0] != det3[3][0]:
                            bud = "Budget not matching for GBS Business Unit"
                            print(bud)
                        if kpi3[1] != det3[4][0]:
                            ppv = "PPV not matching for GBS Business Unit"
                            print(ppv)
                        print("DrillUP to GBS BU 2nd")
                        driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
                        time.sleep(3)
                        driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
            #                     time.sleep(3)
                    except (RuntimeError, TypeError, NameError, Exception,IndexError):
                        time.sleep(5)
                        DD2= driver.find_elements_by_xpath("//h4[text()='GBS BU 2nd LEVEL PPV']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']")
                        print(k)
                        ActionChains(driver).move_to_element((DD2)[k]).perform()
                        CL3= driver.find_elements_by_xpath("//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']")
                        print("GBS BU 2nd LEVEL: "+(CL3)[k].text)
                        time.sleep(2)
            #                 print(k)
                        ActionChains(driver).click((CL3)[k]).perform()
            #                 print(k)
            #                 print(type(k))
                        time.sleep(5)
                        print("DrillDown to GBS Business Unit")
                        det3=getlist()
                        kpi3=KPI()
                        print("GBS Business Unit: "+str(det3))
                        P_ok3=det3[0]
                        print("GBS Business Unit List: "+str(det3[2]))
                        driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
                        print(kpi2[0],kpi2[1],det3[3][0],det3[4][0])
                        if kpi3[0] != det3[3][0]:
                            bud = "Budget not matching for GBS Business Unit"
                            print(bud)
                        if kpi3[1] != det3[4][0]:
                            ppv = "PPV not matching for GBS Business Unit"
                            print(ppv)
                        print("DrillUP to GBS BU 2nd LEVEL")
                        driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
                        time.sleep(3)
                        driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
    #                     time.sleep(3)
    #         time.sleep(3)
                time.sleep(5)
                MoveEle=driver.find_element_by_xpath("(//div[@class='verticalCenter'])[5]")
                action = ActionChains(driver)
                action.move_to_element(MoveEle).perform()
                time.sleep(3)
                driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
                print(kpi2[0],kpi2[1],det2[3][0],det2[4][0])
                if kpi2[0] != det2[3][0]:
                    bud = "Budget not matching for GBS BU 2nd LEVEL"
                    print(bud)
                if kpi2[1] != det2[4][0]:
                    ppv = "PPV not matching for GBS BU 2nd LEVEL"
                    print(ppv)
                print("DrillUP to Market")
                driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
                time.sleep(3)
                driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
                time.sleep(3)

            if mkt=="ASEAN Mkt":
    #         elif mkt=="CEE Mkt":
                print("DrillDown to Country")
                det2=getlist()
                kpi2=KPI()
                P_ok2=det2[0]
                print("Country List: "+str(det2[2]))
                driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
                print(kpi2[0],kpi2[1],det2[3][0],det2[4][0])
                if kpi2[0] != det2[3][0]:
                    bud = "Budget not matching for Country"
                    print(bud)
                if kpi2[1] != det2[4][0]:
                    ppv = "PPV not matching for Country"
                    print(ppv)
                print("DrillUP to Market")
    #             driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
    #             time.sleep(3)
    #             driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
                time.sleep(3)


        time.sleep(5)
        MoveEle=driver.find_element_by_xpath("(//div[@class='verticalCenter'])[5]")
        action = ActionChains(driver)
        action.move_to_element(MoveEle).perform()
        time.sleep(3)
        driver.find_element_by_xpath("(//*[@class='enableSingleArrow'])[2]").click()
        print(kpi1[0],kpi1[1],det1[3][0],det1[4][0])
        if kpi1[0] != det1[3][0]:
            bud = "Budget not matching for Market"
            print(bud)
        if kpi1[1] != det1[4][0]:
            ppv = "PPV not matching for Market"
            print(ppv)
        print("DrillUP to GEO")
        driver.find_element_by_xpath("//span[text()='Aggregated Pipeline']").click()
        time.sleep(3)
        driver.find_element_by_xpath("//span[text()='Executive Summary']").click()
        time.sleep(3)

# ----------------------Call Code Below-------------------
#Make GBS as Default Profile
Login()


# BU Drill Down
BU_toggle()
DD_BuSub_to_Level20()

#Geo
# DD_Geo_MEA_NA_JP_GCG()
# DD_Geo_EuropeMkt_BeNeLux_FranceMarket_ItalyMarket_UKI()
# DD_Geo_EuropeMkt_DACH_Nordic_SPGI()
# DD_Geo_EuropeMKT_CEE()
# DD_Geo_LA()
# DD_Geo_AP()


