from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
import re
from selenium.webdriver.common.action_chains import ActionChains
from datetime import date
from datetime import datetime
from datetime import timedelta
import locators
import Login_Page
import Common
import Constants

driver = Login_Page.driver



def MESChecking():
    time.sleep(2)
    driver.find_element_by_xpath(locators.MES_Icon).click()
    time.sleep(2)
    driver.find_element_by_xpath(locators.MES_Newfilter).click()
    time.sleep(2)
    def_mes=driver.find_elements_by_xpath("//*[@class='img-responsive']")
    print(len(def_mes))
    for i in range(len(def_mes)):
        ActionChains(driver).move_to_element(def_mes[i]).perform()
        time.sleep(3)
        driver.find_element_by_xpath("//*[@class='btn btn-sm btn-cancel position-absolute btn-primary hideBtn showBtn']").click()

    mes_grh_cnt=driver.find_elements_by_xpath("//*[@id='col-rightpartImg']")
    print(len(mes_grh_cnt))

    src=driver.find_element_by_xpath("(//*[@id='col-rightpartImg'])[1]")
    dst=driver.find_element_by_xpath("(//*[@class='graph-target'])[1]")
    dst2 = driver.find_element_by_xpath("(//*[@class='graph-target'])[2]")
    dst3 = driver.find_element_by_xpath("(//*[@class='graph-target'])[3]")
    dst4 = driver.find_element_by_xpath("(//*[@class='graph-target'])[4]")
    time.sleep(3)

    print(dst.location)
    print(dst2.location)
    print(dst3.location)
    print(dst4.location)


    ActionChains(driver).drag_and_drop(src,dst).perform()
    # ActionChains(driver).click_and_hold(src).move_to_element(dst).release().perform()
    # ActionChains(driver).click_and_hold(src).move_by_offset(153,175).release().perform()
    # ActionChains(driver).click_and_hold(src).perform()
    # ActionChains(driver).move_to_element(dst).perform()
    # ActionChains(driver).release(dst).perform()
    # MES= driver.find_element_by_xpath(locators.MES_breadcrumb).text
    # print("Modify executive summary: "+MES)
    # driver.find_element_by_xpath(locators.MES_cancel).click()
    #
#        assert MES==('Executive Summary > Modify Executive Summary'), "Text is not matching"
#         print(MES)
#     return MES




##---------------------------call code below-------------------------##

#
Login_Page.open_ISD()
MESChecking()