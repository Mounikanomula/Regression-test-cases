from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
import re
from selenium.webdriver.common.action_chains import ActionChains
from datetime import date
from datetime import datetime
from datetime import timedelta
import locators
import Login_Page
import Common

driver = Login_Page.driver

def EStop_nav():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle=driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    time.sleep(2)
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :"+str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-1):
        time.sleep(2)
        GH1[i].click()
        time.sleep(2)
        Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
        print(Topnav.text)
        listLegend1.append(Topnav.text)
        driver.find_element_by_xpath(locators.dropdown_wrapper).click()
    # print(listLegend1)
    for i in listLegend1:
            listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    assert listLegend2==[['NQ'], ['Signings', 'Signings-ACV'], ['All', 'Americas', 'EMEA', 'Japan', 'APAC', 'UNASSIGNED', 'INVALID'], ['All', 'Systems w/TPS', 'Cloud & Data Platform', 'Security', 'Cognitive Applications', 'Watson Health']],  "Not expected"
    return listLegend2

# Drilldown to EBR and Drill up one level at a time
def DrillDown_UP_one_level():
    GH1= driver.find_elements_by_xpath(locators.ES_Graph1_DS)
    s=len(GH1)
    det=Common.getlist()
    print("Geo "+str(det))
    P_ok=det[0]
    for i in P_ok:
        time.sleep(10)
        GH1= driver.find_elements_by_xpath(locators.ES_Graph1_DS)
        ActionChains(driver).move_to_element(GH1[i]).perform()
        time.sleep(10)
        CL= driver.find_elements_by_xpath(locators.Drilldown)
        print(i)
        print(type(i))
        ActionChains(driver).click(CL[i]).perform()
        time.sleep(5)
        print("DrillDown to Market")
        det1=Common.getlist()
        print("Market: "+str(det1))
        P_ok1=det1[0]
        for j in P_ok1:
            time.sleep(5)
            DD1= driver.find_elements_by_xpath(locators.ES_Graph1_1_DSMK)
            ActionChains(driver).move_to_element(DD1[j]).perform()
            time.sleep(5)
            CL= driver.find_elements_by_xpath(locators.Drilldown)
            print(j)
            print(type(j))
            ActionChains(driver).click(CL[j]).perform()
            time.sleep(5)
            print("DrillDown to EBR")
            break
        driver.find_element_by_xpath(locators.DrillUP).click()
        time.sleep(5)
        print("DrillUP to Market")
        break
    driver.find_element_by_xpath(locators.DrillUP).click()
    print("DrillUP to Geo")


# Drilldown to EBR and Drill up Top level
def DrillDown_UP_Top_level():
    driver.find_element_by_xpath(locators.ES).click()
    time.sleep(10)
    GH1= driver.find_elements_by_xpath(locators.ES_Graph1_DS)
    s=len(GH1)
    det=Common.getlist()
    print("Geo "+str(det))
    P_ok=det[0]
    for i in P_ok:
        time.sleep(5)
        GH1= driver.find_elements_by_xpath(locators.ES_Graph1_DS)
        ActionChains(driver).move_to_element(GH1[i]).perform()
        time.sleep(5)
        CL= driver.find_elements_by_xpath(locators.Drilldown)
        print(i)
        print(type(i))
        ActionChains(driver).click(CL[i]).perform()
        time.sleep(5)
        print("DrillDown to Market")
        det1=Common.getlist()
        print("Market: "+str(det1))
        P_ok1=det1[0]
        for j in P_ok1:
            time.sleep(5)
            DD1= driver.find_elements_by_xpath(locators.ES_Graph1_1_DSMK)
            ActionChains(driver).move_to_element(DD1[j]).perform()
            time.sleep(5)
            CL= driver.find_elements_by_xpath(locators.Drilldown)
            print(j)
            print(type(j))
            ActionChains(driver).click(CL[j]).perform()
            time.sleep(5)
            print("DrillDown to EBR")
            break
        break
    driver.find_element_by_xpath(locators.DrillTop).click()
    print("DrillTOP to Geo")


def APtop_nav():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle=driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    time.sleep(2)
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :"+str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-2):
        time.sleep(2)
        GH1[i].click()
        time.sleep(2)
        Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
        print(Topnav.text)
        listLegend1.append(Topnav.text)
        driver.find_element_by_xpath(locators.dropdown_wrapper).click()
    # print(listLegend1)
    for i in listLegend1:
            listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    assert listLegend2==[['NQ'], ['Signings', 'Signings-ACV'], ['All', 'Americas', 'EMEA', 'Japan', 'APAC', 'UNASSIGNED', 'INVALID'], ['All', 'Systems w/TPS', 'Cloud & Data Platform', 'Security', 'Cognitive Applications', 'Watson Health'],['UNIT']],"Not expected"
    return listLegend2

def aggPipe_GraphOne_Title_BU():
    global agg_GrOne_Title
    budgetVerify = driver.find_element_by_xpath(locators.common_KPI_Budget_Val).text
    print(budgetVerify)
    if budgetVerify != 'N/A':
        agg_GrOne_Title = driver.find_element_by_xpath(locators.agg_GraphOne_Title_BUCov2)
    elif budgetVerify == 'N/A':
        agg_GrOne_Title = driver.find_element_by_xpath(locators.agg_GraphOne_Title_BUPPV2)
    print(agg_GrOne_Title.text)
    print(agg_GrOne_Title.text)
    return agg_GrOne_Title

#Segmented - Buyer Group for Digital Sales
def segPipe_View_Buyer():
    driver.find_element_by_xpath(locators.seg_View_Arrow).click()
    time.sleep(1)
    driver.find_element_by_xpath(locators.seg_View_Buyer).click()

def SPtop_nav():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle=driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    time.sleep(2)
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :"+str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)):
        time.sleep(2)
        GH1[i].click()
        time.sleep(2)
        Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
        print(Topnav.text)
        listLegend1.append(Topnav.text)
        driver.find_element_by_xpath(locators.dropdown_wrapper).click()
    # print(listLegend1)
    for i in listLegend1:
            listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    assert listLegend2==[['NQ'], ['Signings', 'Signings-ACV'], ['All', 'Americas', 'EMEA', 'Japan', 'APAC', 'UNASSIGNED', 'INVALID'], ['All', 'Systems w/TPS', 'Cloud & Data Platform', 'Security', 'Cognitive Applications', 'Watson Health'], ['BUYER GROUP', 'DEAL SIZE', 'CHANNEL', 'JTC/RHS', 'JTC', 'RHS', 'OI GROUP']],"Not expected"
    return listLegend2

def RMtop_nav():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle = driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    # driver.find_element_by_xpath(locators.RMTab).click()
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :" + str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-5):
        time.sleep(2)
        GH1[i].click()
        time.sleep(2)
        Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
        print(Topnav.text)
        listLegend1.append(Topnav.text)
        driver.find_element_by_xpath(locators.dropdown_wrapper).click()
    for i in listLegend1:
        listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    assert listLegend2== [['NQ'], ['Signings', 'Signings-ACV'], ['All', 'Americas', 'EMEA', 'Japan', 'APAC', 'UNASSIGNED', 'INVALID'], ['All', 'Systems w/TPS', 'Cloud & Data Platform', 'Security', 'Cognitive Applications', 'Watson Health'], ['LIO']],"not expected"
    return listLegend2


def kdtop_nav():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle = driver.find_element_by_xpath(locators.MoveElementkd)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :" + str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-8):
        time.sleep(2)
        GH1[i].click()
        time.sleep(2)
        Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
        print(Topnav.text)
        listLegend1.append(Topnav.text)
        driver.find_element_by_xpath(locators.dropdown_wrapper).click()
    for i in listLegend1:
        listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    time.sleep(5)
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    assert listLegend2 == [['NQ'], ['Signings', 'Signings-ACV'], ['All', 'Americas', 'EMEA', 'Japan', 'APAC', 'UNASSIGNED', 'INVALID'], ['All', 'Systems w/TPS', 'Cloud & Data Platform', 'Security', 'Cognitive Applications', 'Watson Health'], ['LIO'], ['CLIENT AGGREGATION', 'ALL LINE ITEMS'], ['By BU group', 'By BU Sub group', 'By Level 17', 'By WSR', 'By Dealsize', 'By SAQ', 'By SAQ Quadrant', 'By Market', 'By Branch Group (EBR)', 'By Branch (EBU)', 'By Branch Unit (ESU)', 'By Client Type', 'By Client Sub Type', 'By Client Set', 'By Channel', 'By Reporting Country', 'By Roadmap Status', 'By Close/Bill Week', 'By Close/Bill Month', 'By OI Source', 'By ISU Group', 'By ISU', 'By Geo']],"not expected"
    return listLegend2


def Mitop_nav():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle = driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :" + str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-4):
        time.sleep(2)
        GH1[i].click()
        time.sleep(2)
        Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
        print(Topnav.text)
        listLegend1.append(Topnav.text)
        driver.find_element_by_xpath(locators.dropdown_wrapper).click()
    for i in listLegend1:
        listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    time.sleep(3)
    driver.find_element_by_xpath(locators.common_GlobalFilterXicon).click()
    assert listLegend2 == [['NQ'], ['Signings', 'Signings-ACV'], ['All', 'Americas', 'EMEA', 'Japan', 'APAC', 'UNASSIGNED', 'INVALID'], ['All', 'Systems w/TPS', 'Cloud & Data Platform', 'Security', 'Cognitive Applications', 'Watson Health'], ['LIO'], ['ALL LINE ITEMS'], ['Identifying (1)', 'Validated (4)', 'Qualifying (7)', 'Gaining Agreement (6)']], "is not expected"
    return listLegend2

def buyer_loop():
    driver.find_element_by_xpath(locators.filter_icon).click()
    driver.find_element_by_xpath(locators.seg_View_Arrow).click()
    time.sleep(2)
    driver.find_element_by_xpath(locators.seg_View_Buyer).click()
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    time.sleep(3)
    V = []
    for j in range(3):
        driver.find_element_by_xpath(locators.max1 + '[' + str(j + 1) + ']').click()
        driver.find_element_by_xpath(locators.sp_showhide).click()
        vp_all_values= driver.find_elements_by_xpath("//div[@class='datatable-row-center datatable-row-group ng-star-inserted']//div[@class='datatable-body-cell-label']//span[@class='ng-star-inserted']")
        for i in range(len(vp_all_values)):
            vp_get_all = vp_all_values[i].text
            # vp_get_all = vp_get_all.replace("")
            vp_get_all = re.findall(r'[0-9]+[.]?[0-9]+', vp_get_all)
            vp_get_all = vp_get_all[0]

            print(vp_get_all)
            V.append(float(vp_get_all))
        sum_summary = sum(V)
        print(sum_summary)
        driver.find_element_by_xpath(locators.sp_showhide).click()
        driver.find_element_by_xpath(locators.min1).click()
    return V




def buyer_loop_VP():
    driver.find_element_by_xpath(locators.filter_icon).click()
    driver.find_element_by_xpath(locators.seg_View_Arrow).click()
    time.sleep(2)
    driver.find_element_by_xpath(locators.seg_View_Buyer).click()
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    time.sleep(3)
    B_VP = []
    for j in range(1):
        driver.find_element_by_xpath(locators.max1 + '[' + str(j + 1) + ']').click()
        driver.find_element_by_xpath(locators.sp_showhide).click()
        vp_all_values = driver.find_elements_by_xpath(
            "//div[@class='datatable-row-center datatable-row-group ng-star-inserted']//div[@class='datatable-body-cell-label']//span[@class='ng-star-inserted']")
        for i in range(len(vp_all_values)):
            vp_get_all = vp_all_values[i].text
            # vp_get_all = vp_get_all.replace("")
            vp_get_all = re.findall(r'[0-9]+[.]?[0-9]+', vp_get_all)
            vp_get_all = vp_get_all[0]

            print(vp_get_all)
            B_VP.append(float(vp_get_all))
        sum_summary = sum(B_VP)
        print("Buyer VP :", sum_summary)
        driver.find_element_by_xpath(locators.sp_showhide).click()
        driver.find_element_by_xpath(locators.min1).click()
    return B_VP



def buyer_loop_QP():
    Common.GlobFilterRestoreDefaults()
    Common.GlobFilterXiconClick()
    driver.find_element_by_xpath(locators.filter_icon).click()
    driver.find_element_by_xpath(locators.seg_View_Arrow).click()
    time.sleep(2)
    driver.find_element_by_xpath(locators.seg_View_Buyer).click()
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    time.sleep(3)
    B_QP = []
    for j in range(1,2):
        driver.find_element_by_xpath(locators.max1 + '[' + str(j + 1) + ']').click()
        driver.find_element_by_xpath(locators.sp_showhide).click()
        vp_all_values = driver.find_elements_by_xpath(
                "//div[@class='datatable-row-center datatable-row-group ng-star-inserted']//div[@class='datatable-body-cell-label']//span[@class='ng-star-inserted']")
        for i in range(len(vp_all_values)):
            qp_get_all = vp_all_values[i].text
            # vp_get_all = vp_get_all.replace("")
            qp_get_all = re.findall(r'[0-9]+[.]?[0-9]+', qp_get_all)
            qp_get_all = qp_get_all[0]

            print(qp_get_all)
            B_QP.append(float(qp_get_all))
        sum_summary = sum(B_QP)
        print("Buyer QP :", sum_summary)
        driver.find_element_by_xpath(locators.sp_showhide).click()
        driver.find_element_by_xpath(locators.min1).click()
    return B_QP