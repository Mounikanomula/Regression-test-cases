# TEST URL
url = "https://skylinepreprod.epm-sales-production.us-south.containers.appdomain.cloud/sales/management-dashboard/"
#prestag = "https://skylineprestag.epm-sales-staging.us-south.containers.appdomain.cloud/esa-skyline-ibm-dev/epmsales/"
# No Auth URL Test
# url = "https://skyline.epm-sales-staging.us-south.containers.appdomain.cloud/esa-skyline-ibm-dev/uiappltest//esa-skyline-ibm-dev/uiappltest/?email=skytesti@in.ibm.com&firstname=Functional ID 3&bluegroups=ARDE_ALL&uid=07820E744&noauthentication=true"
# url = "https://skyline.epm-sales-staging.us-south.containers.appdomain.cloud/esa-skyline-ibm-dev/uiappltest//esa-skyline-ibm-dev/uiappltest/?email=sltestin@in.ibm.com&firstname=Functional ID 1&bluegroups=ARDE_ALL&uid=07820E744&noauthentication=true"
#No Auth URL_Ptest
# url="https://skylinep.epm-sales-staging.us-south.containers.appdomain.cloud/esa-skyline-ibm-dev/uiappltestparallel//esa-skyline-ibm-dev/uiappltestparallel/?email=skytesti@in.ibm.com&firstname=Functional ID 3&bluegroups=ARDE_ALL&uid=07820E744&noauthentication=true"
# No Auth URL_Staging
# url="https://skylinestag.epm-sales-staging.us-south.containers.appdomain.cloud/esa-skyline-ibm-dev/epmsales/esa-skyline-ibm-dev/epmsales/?email=skytesti@in.ibm.com&firstname=Functional ID 3&bluegroups=ARDE_ALL&uid=07820E744&noauthentication=true"
# No Auth URL_Pre Prod
# url="https://w3-pre.ibm.com/sales/management-dashboard//sales/management-dashboard/?email=skytesti@in.ibm.com&firstname=Functional ID 3&bluegroups=ARDE_ALL&uid=07820E744&noauthentication=true"
# # No Auth Pre-staging my id
# url="http://skylineprestag.epm-sales-staging.us-south.containers.appdomain.cloud/esa-skyline-ibm-dev/epmsales//esa-skyline-ibm-dev/epmsales/?email=sramamu3@in.ibm.com&firstname=Functional ID 3&bluegroups=ARDE_ALL&uid=07820E744&noauthentication=true"
# No Auth Prod
# url="https://w3.ibm.com/sales/management-dashboard//sales/management-dashboard/?email=skytesti@in.ibm.com&firstname=Functional ID 3&bluegroups=ARDE_ALL&uid=07820E744&noauthentication=true"
# No Auth Pre-Dev
# url="https://skylinepredev.epm-sales-development.us-south.containers.appdomain.cloud/esa-skyline-ibm-dev/uiapplpredev//esa-skyline-ibm-dev/uiapplpredev?email=skytesti@in.ibm.com&firstname=Functional ID 3&bluegroups=ARDE_ALL&uid=07820E744&noauthentication=true"


user = "madbasin@in.ibm.com"
password = "lordlokakarta2912"
# breadcrumb = "//span[@class='txtColorBlue ng-star-inserted']" #ES_AP Breadcrumb
breadcrumb ="//span[contains(@class,'txtColorBlue')]"
breadcrumb2 ="//span[@class='txtColorBlue ng-star-inserted']"
# filter_icon="//*[@class='new-filter-icon']"  #Global Filter icon Open
filter_icon="//*[@id='newfilterIcon-span']"  #Global Filter icon Open
filter_icon_close="//*[@name='close']" #Global Filter icon Close
clksomewhere="//*[@class='text-center title']"

#----------------------------------------------------------------------

# KPI
KPI_ALL = "//div[@class='row tileMargin']"
Budget = "(//div[@class='verticalCenter'])[1]"
PPV = "(//div[@class='verticalCenter'])[2]"
Cov = "(//div[@class='verticalCenter'])[3]"
BW_OBJ = "(//div[@class='verticalCenter'])[4]"
VP = "(//div[@class='verticalCenter'])[5]"
WSR = "(//div[@class='verticalCenter'])[3]"
WON = "(//div[@class='verticalCenter'])[7]"
Fostream = "(//div[@class='verticalCenter'])[8]"  # Specific to System Hardware
QP = "(//div[@class='verticalCenter'])[6]"  ## Aggregated & Segmented Tab
rd_WSR = "(//div[@class='verticalCenter'])[2]"  ## roadmap
rd_DTB = "(//div[@class='verticalCenter'])[4]"  ## roadmap Delta to Budget
rd_WON = "(//div[@class='verticalCenter'])[5]"  ## roadmap WON
rd_STR = "(//div[@class='verticalCenter'])[6]"  ## roadmap Solid + AT Risk
rd_WKS = "(//div[@class='verticalCenter'])[7]"  ## roadmap WSR + Key Strech
RD_WKS_ST = "(//div[@class='verticalCenter'])[8]"  ## roadmap WSR + Key Strech+ Strech
QTD = "(//div[@class='verticalCenter'])[2]"
PPV2 = "(//div[@class='verticalCenter'])[4]"
Cov2 = "(//div[@class='verticalCenter'])[5]"
VP2 = "(//div[@class='verticalCenter'])[6]"
QP2 = "(//div[@class='verticalCenter'])[7]"
WON2 = "(//div[@class='verticalCenter'])[8]"
VP_val= "//div[text()='VP ']/../div[@class='value isCircle']"  ## in order to get vp value without any hardcording
QP_Val = "//div[text()='QP ']/../div[@class='value isCircle']"
QTDACTUALSTrans = "(//div[@class='verticalCenter'])[2]"
#--------------------------------------------------------------------------

# Executive Summary Tab
ES = "//span[text()='Executive Summary']" #Tab
Logo="logoIcon"
Logo2="ibm-title-text"
Need_help="cursorPointer"
Need_help2="modalHeader"
Need_help_close="//*[@class='bx--modal-close__icon ng-star-inserted']//*[@fill-rule='nonzero']"
Prof_Pic="profilePic"
# Prof_Pic_New="(//DIV[@_ngcontent-c4=''])[1]"
Prof_Pic_New="(//*[text()=' NEW PROFILE '])"
Prof_Page="welcomToIBM"
Prof_Page_AH="//DIV[@class='col-md-12 accesshub-details']"
# Prof_Page_Prv="(//DIV[@_ngcontent-c4=''])[5]"
# Prof_Page_Prv="//*[text()= ' PRIVACY ']"
Prof_Page_Prv="Privacylable-carbon"
# Prv="(//H4[@_ngcontent-c6=''][text()='Privacy Statement and Terms of Use'][text()='Privacy Statement and Terms of Use'])[1]"
Prv="(//*[text()='Privacy Statement and Terms of Use'])[1]"
# Prv2="(//P[@_ngcontent-c6=''])[4]"
Prv2="(//*[text()='PrivacyQ@ca.ibm.com'])[1]"
# Prv_Cls="bx--modal-close__icon"
Prv_Cls="//div[@class='bx--modal-container']//button[@class='bx--modal-close']"
# Prof_Pic_Abt="(//DIV[@_ngcontent-c4=''])[7]"
Prof_Pic_Abt="//*[text()= ' About ISD ']"
# Abt="//H1[@_ngcontent-c7=''][text()='About SMS IBM Sales Dashboard']"
Abt="//*[text()='About EO IBM Sales Dashboard']"
# Abt_cls="(//BUTTON[@_ngcontent-c0=''])[6]"
Abt_cls="//*[@id='modal-8foc6fnqyys']/div/div[1]/button"
PP_down="//li[@class='header-dropdown']"
# PP_Cur="//P[@_ngcontent-c0=''][text()='CURRENT PROFILE']"
PP_Cur="//*[text()='CURRENT PROFILE']"
# PP_Oth="//P[@_ngcontent-c0=''][text()='OTHER PROFILES']"
PP_Oth="//*[text()='OTHER PROFILES']"
Default_Prof="menuItem"
# Left_Expand="(//DIV[@_ngcontent-c0=''])[@class='relative icon-wrap']"
Left_Expand="//div[@class='expand-icon']"
Left_Expand_text="//div[@class='tooltip'][1]"
ES_Graph1="//h4[text()='GEO COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']"
ES_Graph1_1="//h4[text()='MARKET COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']"
GH1="(//*[@class='text-center title'])[1]"
GH2="(//*[@class='text-center title'])[2]"
GH2_AP="(//*[@class='text-center title'])[1]"
GH3="(//*[@class='text-center title'])[3]"
GH4="(//*[@class='text-center title'])[4]"
GH1_SP="(//*[@class='text-center title ng-star-inserted'])[1]"
GH2_SP="(//*[@class='text-center title ng-star-inserted'])[2]"
GH3_SP="(//*[@class='text-center title ng-star-inserted'])[3]"
GH4_SP="(//*[@class='text-center title ng-star-inserted'])[4]"
MadanOldGH1Date="(//h4[@class='text-center title'])[1]/..//*[@class='text-center sub-head-font-color subHead-padding']"
GH1Date="(//h4[@class='text-center title'])[1]/..//*[@id='subhdingEm']"
GH2Date="(//*[@class='text-center title'])[2]/..//*[@class='text-center sub-head-font-color subHead-padding-RM']"
MadanOldGH3Date="(//h4[@class='text-center title'])[3]/..//*[@class='text-center sub-head-font-color subHead-padding']"
GH3Date="(//h4[@class='text-center title'])[3]/..//*[@id='subhdingEm']"
GH4Date="(//h4[@class='text-center title'])[4]/..//*[@class='text-center sub-head-font-color subHead-padding-RM']"
hover_text="//*[name()='ngx-tooltip-content']"
ES_Graph2="//h4[text()='BUSINESS UNIT GROUP COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']"
max1="(//*[@name='icon--maximize'])"
max1_1="(//*[@name='icon--maximize']/*[@class='ng-star-inserted'])"
max2 = "(//*[@name='icon--maximize'])"
# max1_1="(//*[@class='expandOrCollapseGraphIcons ng-star-inserted'])"
showhide="//*[@class='buttonShowHide']"
sp_showhide="//*[@class='buttonShowHide ng-star-inserted']"
sp_showhide2="//*[contains(@class,'buttonShowHide')]"
sp_showhide3="//*[contains(@class,'jtcBtnShowHide')]"
firstrow="//*[@class='datatable-body-row datatable-row-even ng-star-inserted']"
min1="(//*[@name='icon--minimize'])"
Graphs="//*[@class='title text-center']"
Graphs1="//*[@class='text-center title']"
SAQ_Graph="//*[@class='text-center graphTitle']"
Track="//*[@class='text-center title ng-star-inserted']"
# max1 = "(//*[@name='icon--maximize'])"
# showhide = "//*[@class='buttonShowHide']"
# firstrow = "//*[@class='datatable-body-row datatable-row-even ng-star-inserted']"
# min1 = "(//*[@name='icon--minimize'])"
Drilldown="//*[@class='customDrillDownCursor bx--link bx--tooltip__trigger']"
DrillUP="(//*[@class='ng-star-inserted enableSingleArrow'])[2]"
Drilup_updated = "//*[@title='Drill up One Level']"
DrillTop="//*[@title='Go to Top']"
topnav_View = "//*[@id='bread_VIEW']"
topnav_altView = "//*[@id='bread_VIEW']//..//*[@role='option']"
MoveElementSomewhere="(//*[text()='Page Specific Filters'])[2]"
# MES_Icon="//*[@class='new-filter-icon']/..//*[@id='bx--overflow-menu__icon_not']"
MES_Icon="//*[@class='gear-icon']/..//*[@id='bx--overflow-menu__icon_not']"
MES_Newfilter="//*[text()=' NEW VIEW ']"
MES_breadcrumb="//*[text()='Executive Summary > Modify Executive Summary']"
MES_cancel= "//*[text()='CANCEL']"

Vp_KPI_txt = "//div[text()='VP']"
Vp_KPI_Val = "//div[text()='VP']/../div[@class='value']"
Def_Grp="//div[@class='col-md-4 searchGroup']//div[@class='ng-value-container']"
Summary_deal_header_val = "(//p[@class='headertext'])[1]"
Detailed_list="#skylineDealListModal .datatable-row-wrapper div.col-md-2:nth-of-type(2)"
Detailed_list_close="(//carbon-icon[@name='close'])[3]"
# ------------------GIMD-------------------------------------
GIMD_g1 = "//h4[text()='SECTOR GM COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']"
GIMD_g1_1= "//h4[text()='GEO COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']"
GIMD_g2 = "//h4[text()='BUDGET Vs QTD ACTUALS (Trans.)']//..//*[@id='qtdGraphSvg']//..//*[@class='budgetBar']"
G2_hover = "//*[@class='d3-tip n']"
QTD_Graph_GIMD = "(//*[@name='icon--maximize']//*[name()='path'])"
agg_GraphOne_Title_SGMCov = "//*[text()='SECTOR GM COV% (PPV)']"
agg_GraphOne_Title_SGMPPV = "//*[text()='SECTOR GM COV% (PPV)']"

# __________________________________________________ IPE_BPOI_______________________________________
Summary_headers = "//h4[contains(@class,'text-center title')]"
View_GF = "//div[@class='searchGroup isSingleSelect ng-star-inserted'][starts-with(.,'View : ')]//carbon-dropdown"
View_dropdown = "//div[@class='ng-dropdown-panel-items scroll-host']//div[@role='option']"
view_Scroll_host = "//div[@class='ng-dropdown-panel-items scroll-host']"

Inline_filters = "//div[@class='dropDownPosition ng-star-inserted dynamic-collapse-graph-dropdown']"
Inline_Scroll_Host = "//div[@class='ng-dropdown-panel-items scroll-host']"
Inline_filter_options = "//div[@class='ng-dropdown-panel-items scroll-host']//div[@role='option']"
Inline_arrow_graph1 = "(//span[@class='ng-arrow-wrapper'])[6]"

Inline_filter_options_click = "//div[contains(@class,'dropDownPosition')]"
Header_graph_1 = "(//h4[@class='text-center title'])[1]"
Expand_graph_1 = "//carbon-icon[@name='icon--maximize']/*[@class='ng-star-inserted']"
Expand_header_graph_1 = "//h4[@class='text-center title']"

Inline_filter_options_clk_2 = "(//div[contains(@class,'dropDownPosition')])[2]"
Inline_arrow_graph_2 = "(//span[@class='ng-arrow-wrapper'])[7]"
Inline_click_2 = "(//div[contains(@class,'dropDownPosition')])[2]"

Graph_header_2 = "(//h4[contains(@class,'text-center title')])[2]"
Expand_graph_2 = "(//carbon-icon[@name='icon--maximize']/*[@class='ng-star-inserted'])[2]"
Header_graph_2 = "(//h4[contains(@class,'text-center title')])[2]"

Inline_filter_options_clk_3 = "(//div[contains(@class,'dropDownPosition')])[3]"
Inline_arrow_graph_3 = "(//span[@class='ng-arrow-wrapper'])[8]"
Graph_header_3 = "(//h4[contains(@class,'text-center title')])[3]"
Expand_graph_3 = "(//carbon-icon[@name='icon--maximize']/*[@class='ng-star-inserted'])[3]"
Expand_Graph_header = "(//h4[contains(@class,'text-center title')])[3]"

Vp_KPI_val_BPOI = "//div[text()='VP']/../div[@class='value ng-star-inserted']"
Qp_KPI_val_BPOI = "//div[text()='QP']/../div[@class='value ng-star-inserted']"
Inline_filter_option_clk_4 = "(//div[contains(@class,'dropDownPosition')])[4]"
Inline_arrow_graph_4 = "(//span[@class='ng-arrow-wrapper'])[9]"
Header_4 = "(//h4[contains(@class,'text-center title')])[4]"
Expand_Graph_4 = "(//carbon-icon[@name='icon--maximize']/*[@class='ng-star-inserted'])[4]"
Expand_graph_header_4 = "(//h4[contains(@class,'text-center title')])[4]"

Expand_graph_icon = "//carbon-icon[@name='icon--maximize']/*[@class='ng-star-inserted']"
Show_table_clk = "//*[@class='buttonShowHide']"
Hide_table_clk = "//button[@class='buttonShowHide ng-star-inserted']"
Expand_minimize = "//carbon-icon[@name='icon--minimize']"

Reset_Default = "//button[text()='RESET TO DEFAULT']"
Graph_headers = "//h4[@class='text-center title']"

Page_specific_arrow = "(//carbon-icon[@name='icon--chevron--down'])[2]"

Opp_iden_label = "//label[text()='Opp Identifier Group : ']"
opp_iden_txt = "//div[@class='searchGroup ng-star-inserted'][starts-with(.,'Opp Identifier Group : ')]//carbon-dropdown"

View_arrow_clk = "//label[contains(text(),'View : ')]//..//*[@class='ng-arrow-wrapper']"

Opp_ident_arrow_clk = "//label[contains(text(),'Opp Identifier Group : ')]//..//*[@class='ng-arrow-wrapper']"

BPOI_bar_clks = "(//*[@class='card ng-star-inserted'])[1]//*[@class='bar my-classpointer myClass']"
Bpoi_default_bar_clk = "//div[@class='col-md-4 searchGroup']//div[@class='ng-value-container']"
Bar_close_icon = "(//carbon-icon[@name='close'])[3]"

Opp_iden_BP_clk = "(//div[@class='ng-dropdown-panel-items scroll-host']//div[@role='option'])[2]"

Opp_ident_option_4 = "(//div[@class='ng-dropdown-panel-items scroll-host']//div[@role='option'])[4]"
opp_ident_option_1 = "(//div[@class='ng-dropdown-panel-items scroll-host']//div[@role='option'])[1]"


#-----------------------------------------------------------------------------

# Aggregated Pipeline Tab
ap = "//span[text()='Aggregated Pipeline']" #Tab
# ap_b = "(//span[text()='Aggregated Pipeline'])[2]"  #Breadcrumb
agg_GraphOne_Title_BU = "//*[text()='BUSINESS UNIT GROUP COV% (PPV)']"
agg_Graph1 = "(//*[@class='card'])[1]"
agg_graphxAxis = "//..//*[@class='x axis']//*[@class='ng-star-inserted']//*[@class='tick ng-star-inserted']//*[@text-anchor='end']"
agg_GraphThree_SubTitle = "//*[@class='pipelineGraph']//*[@class=' text-center ng-option-label pqsublabel']"
agg_Graph3 = "(//*[@class='card'])[3]"
agg_PPQ_Bars = "//*[@class='pipelineGraph']//*[contains(@class,'expandGraphLabel')]"
agg_Chart_Inline_Click = "//*[@class='pipelineGraph']//*[@class='ng-arrow-wrapper']"
agg_Chart_Inlines = "//*[@class='ng-dropdown-panel-items scroll-host']//*[@role='option']"
agg_GraphThree_Title = "//*[text()='PIPELINE QUALITY']"
agg_Track_Chart_Title = "//*[@class='text-center title ng-star-inserted']"
agg_Track_Legend = "//*[@class='aggPipGraph']//*[@class='legends']"
agg_Track_Legend_Indi = "(//*[@class='legend'])[4]"
agg_VPTrack_MoveOnLine = "//*[@class='roadmapTrackGraph']//*[@fill-opacity=0]"
agg_VPTrack_Chart_Inline_Click = "//*[@class='aggPipGraph']//*[@class='ng-arrow-wrapper']"
agg_Inline_PPA_Select = "//*[@class='ng-dropdown-panel-items scroll-host']//*[text()='PPA']"
agg_PPA_VelocityAvg = "//*[@class='aggPipGraph']//*[@class='bk-annotation']"
agg_PPA_Toy = "//*[@class='bk-canvas-wrapper']"
MadanOldAPGH1Date="(//h4[@class='text-center title'])[1]//..//*[@class='text-center sub-head-font-color subHead-padding']"
APGH1Date="(//h4[@class='text-center title'])[1]/..//*[@id='subhdingEm']"
SAQGraphDate="//*[@class='text-center graphTitle']/..//*[@class='text-center sub-head-font-color subHead-padding-RM']"
APGH2Date="(//*[@class='text-center title'])[2]/..//*[@class='text-center sub-head-font-color subHead-padding-PP']"
VPtrackHeader="//*[text()=' VP TRACK']"
VPTrack_Date="(//*[@class='text-center sub-head-font-color subHead-padding-RM'])[2]"
SAQGraphHeader="//*[@class='text-center graphTitle']"
SAQ_Probe="//h4[text()='SALES ACTION QUADRANTS']//..//*[text()='PROBE']"
SAQ_Probe_txt="(//h4[text()='SALES ACTION QUADRANTS']//..//*[text()='PROBE']//..//*[name()='text'])[2]"
SAQ_Probe_Dl="(//p[@class='headertext'])[1]"
SAQ_Close="//h4[text()='SALES ACTION QUADRANTS']//..//*[text()='CLOSE']"
SAQ_Close_txt="(//h4[text()='SALES ACTION QUADRANTS']//..//*[text()='CLOSE']//..//*[name()='text'])[2]"
SAQ_Refine="//h4[text()='SALES ACTION QUADRANTS']//..//*[text()='REFINE']"
SAQ_Refine_txt="(//h4[text()='SALES ACTION QUADRANTS']//..//*[text()='REFINE']//..//*[name()='text'])[2]"
SAQ_Advance="//h4[text()='SALES ACTION QUADRANTS']//..//*[text()='ADVANCE']"
SAQ_Advance_txt="(//h4[text()='SALES ACTION QUADRANTS']//..//*[text()='ADVANCE']//..//*[name()='text'])[2]"
# agg_GraphOne_Title_BUCov = "//*[text()='BUSINESS UNIT SUBGROUP COV% (PPV)']"
agg_GraphOne_Title_BUCov = "(//*[@class='text-center title'])[1]"
agg_GraphOne_Title_BUPPV = "//*[text()='BUSINESS UNIT GROUP PPV']"


#-----------------------------------------------------------------------------

# Segmented Pipeline Tab
sp = "//span[text()='Segmented Pipeline']" #Tab
sp_b = "//span[text()='Segmented Pipeline ']"  #Breadcrumb
seg_bread = "//*[@class='breadcrum-left']"
sp_view="(//*[@class='ng-input'])[5]"
sp_view2="(//*[@class='ng-input'])[7]"
sp_view_count="//*[@class='ng-option-label ng-star-inserted']"
sp_view_opt="//*[@class='ng-dropdown-panel-items scroll-host']//div[@role='option']"
sp_view_opt_clk="(//*[@class='ng-option-label ng-star-inserted'])"
sp_view_sum_clck="(//*[@class='ng-option-label ng-star-inserted'])"
SP_View_Summary_CLK = "//div[@class='ng-dropdown-panel-items scroll-host']//div[@role='option']"
sp_view3="(//*[@class='ng-input'])[6]"


seg_View_Arrow = "//*[@id = 'bread_VIEW']//*[@class='ng-arrow-wrapper']"
seg_View_StratImp = "//*[text()='SOLUTIONS - Strategic Imperatives']"
seg_View_IndSol = "//*[text()='INDUSTRY SOLUTIONS']"
seg_RevType_Arrow = "//*[@id = 'bread_REVENUE TYPE']//*[@class='ng-arrow-wrapper']"
seg_RevType_Option_ALL = "downshift-2-item-0"

seg_All_Chart_Titles = "//*[@class='text-center title ng-star-inserted']"
seg_KPI_Labels = "//*[@class='paddingGraph col-md-12']//*[@class='tile-label ng-star-inserted']"
# Seg_KPI_SI_labels = "//*[@class='paddingGraph tile-cols']//*[@class='tile-label ng-star-inserted']"
Seg_KPI_SI_labels = "//*[@class='tile-label ng-star-inserted']"
# seg_KPI_Labels = "//*[@class='paddingGraph col-md-12']//*[@class='tile-label ng-star-inserted']"
seg_KPI_Labels = "//*[@class='tile-label ng-star-inserted']"
seg_KPI_Tiles = "//*[@class='verticalCenter']"

SPGH1Date="(//*[@class='text-center sub-head-font-color subHead-padding-RM'])[1]"
SPGH2Date="(//*[@class='text-center sub-head-font-color subHead-padding-RM'])[2]"
SPGH3Date="(//*[@class='text-center sub-head-font-color subHead-padding-RM'])[3]"
SPGH4Date="(//*[@class='text-center sub-head-font-color subHead-padding-RM'])[4]"

#-----------------------------------------------------------------------------
# tp="//*[@id='interior-menu-item-4']" # Transactional Pipeline click
tp="//*[text()='Transactional Pipeline']" # Transactional Pipeline click
# Roadmap Tab
rd = "//span[text()='Roadmap']" #Roadmap tab
rd_b = "//div[@class='breadcrum-left']" #RD Breadcrumb
rM_Track_Chart_Title = "//*[@class='text-center title ng-star-inserted']"
rM_Track_Legend = "//*[@class='roadmapTrackGraph']//*[@class='legends']"
rM_Track_Chart_Inline_Click = "(//*[@class='card'])[3]//*[@class='ng-arrow-wrapper']"
rM_Track_Inline_setToWSR = "(//*[@class='card'])[3]//*[@class='ng-dropdown-panel-items scroll-host']//*[text()='WSR']"
RMBudgetKPI="(//*[@class='value ng-star-inserted'])[1]"
RMTrendExpandGraph="(//*[@name='icon--maximize'])[4]"
# RMTrendExpandGraph = "(//*[@name='icon--maximize']//*[name()='path'])[4]"
RMTrendgraph_showtable="//*[text()=' Show Table ']"
RMTrendbudgetCellvalue="(//*[@class='datatable-body-cell-label'])[2]"
RMTrendbudgetCellvalue2 = "(//datatable-body-row[@class='datatable-body-row datatable-row-even ng-star-inserted'])[11]"
RMTrendexpandtable_hidebutton="//*[text()=' Hide Table ']"
bread_view="//*[@id='bread_VIEW']"
ele="//*[@class='ng-dropdown-panel-items scroll-host']//div[@role='option']"
RMLegend = "//*[@class='roadmapTempGraph']//*[@class='legend']"# RMLegend
RMGT1="(//*[@class='text-center title'])[1]" # Roadmap graph1 title
RMGT2="(//*[@class='text-center title'])[2]" # Roadmap graph2 title
RMGT3="//*[@class='text-center title ng-star-inserted']" # Roadmap graph3 title
RMGT4="(//*[@class='text-center title'])[3]" # Roadmap graph4 title
RMGraphDate1="//*[text()='ROADMAP TO BUDGET']/..//*[@class='text-center sub-head-font-color subHead-padding-RM']" # RM Graph date1
MadanOldRMGraphDate2="//*[@class='text-center sub-head-font-color subHead-padding']" # RM Graph date2
RMGraphDate2="//*[@id='subhdingEm']" # RM Graph date2
RMGraphDate3="(//*[@class='text-center sub-head-font-color subHead-padding-RM'])[2]" # RM Graph date3
RMGraphDate4="//*[@id='wb-subHeading']" #RM Graph date4
# RMGraphDate4="//*[text()='WEEKLY BUILD - WSR']/..//*[@class='text-center sub-head-font-color subHead-padding-RM']" #RM Graph date4
# Wkly_Build_Chart_Title="(//*[@class='text-center title'])[2]"
Wkly_Build_Legend = "//*[@class='qtlChart']//*[@class='legends-area']"
Wkly_Build_Chart_Inline_Click = "//*[@class='graph-container ng-star-inserted card']//*[@class='ng-arrow-wrapper']"
WKly_build_chart_inline_filter_clk_2 = "//*[@id='weeklyBuildDropdown_12']//*[@class='ng-arrow-wrapper']"
Wkly_Build_Inline_setToWSR = "//*[@class='graph-container ng-star-inserted card']//*[@class='ng-dropdown-panel-items scroll-host']//*[text()='WSR']"

# ------------ KEY DEALS ---------------------------------------------

Deal_list_manmnt ="//*[text()='Deal Management']"
KD_tab = "//*[text()='DEALS LIST']"
KD_Default_View="//*[@id='bread_GROUP']"
KD_Modal_Txt = "//*[text()='Customize Deal List - Modify Columns / Define Filters']"
KD_Modal_Duplicate_btn = "//*[@id='savedView']//img[@src='assets/images/Duplicate.svg']/.."
KD_Modal_Delete_btn = "//*[@id='savedView']//img[@src='assets/images/Delete.svg']/.."
KD_Modal_ChkBox = "*//input[@class='bx--checkbox']"
KD_Modal_Filter_lbl = "//div[@class='col-md-6 col-sm-6 col-xs-6 deallistLabel ng-star-inserted']//label"
KD_Modal_Filter_icons = "//img[@src='assets/images/Filter.svg']"
KD_Modal_Filter_Placeholder = "//*[@id='dealList']//*[@class='ng-placeholder']"
KD_Modal_Fitler_SliderPlaceholder = "//*[@class='custom-filters']//*[@class='bx--Headerlabel']"
KD_Modal_ChkBox_Clicks = "*//*[@class='checkBoxDeallist']"
KD_Modal_ChkBox_Labels = "//*[@class='col-md-6 col-sm-6 col-xs-6 deallistLabel ng-star-inserted']"
KD_Modal_Filter_Arrow = "//*[@id='dealList']//*[@class='ng-arrow-wrapper']"
KD_Modal_Filter_Slider_Min = "//*[@role='slider']"
KD_Modal_Filter_Slider_Max = "(//*[@role='slider'])[2]"
KD_Modal_Filter_ListItemClick = "downshift-2-item-0"
KD_Modal_Cancel_btn = "//*[text()='Cancel']"
KD_Modal_Save_btn = "//*[text()=' Save']"
KD_Refresh_Icon = "//*[@class='refreshIcon']"
KD_Modal_Input_Name = "(//*[@id='savedView']//*[@type='text'])[2]"
#KD_Custom_Name = "//*[@class='savedViewsList modifyItemList ng-star-inserted']//*[text()='Test_KD ']"
KDTest_Edit = "//*[text()='Test_KD ']//..//*[@class='edit_icon']"
KD_Delete_Alert = "//*[contains(text(),'Permanently Delete ')]"
KD_Delete = "//*[text()='Delete']"
KD_Won="//b[@_ngcontent-c54=''][text()='Won']"
# KD_First_Row="(//*[@class='datatable-body-row datatable-row-even'])[1]"
KD_First_Row="(//*[@class='datatable-body-row datatable-row-even ng-star-inserted'])[1]"
# (//*[@class='datatable-body-row datatable-row-even ng-star-inserted'])[1]
MoveElementkd="(//*[text()='Aggregation : '])[2]"
KDDate="//span[@class='headertext']"
KD_Expandall="//*[@title='Expand All']"
# __________________________________paginations__________________________________
KD_page_caret_clk = "//carbon-icon[@name='caret--right']"
Kd_right_arrowclk = "//button[@class='bx--pagination__button bx--pagination__button--forward']"
Kd_data_list = "//datatable-body-row[@class='datatable-body-row datatable-row-even ng-star-inserted']"
KD_Minus_btn = "//img[@class='minusIcon plusandminusicon']"
KD_left_arrowclk = "//button[@class='bx--pagination__button bx--pagination__button--backward']"
Opp_val_txt = "#skylineTransactionalKeydealsTable .datatable-row-wrapper div .col-md-3:nth-of-type(3)"
KD_arrow_dpdwn_clk = "//div[@id='sk-pagenation-select']//..//span[@class='ng-arrow-wrapper']"
KD_input_txt_val = "//div[@id='sk-pagenation-select']//child::input"
KD_Group_options = "//*[@class='ng-dropdown-panel-items scroll-host']//..//*[@class='ng-option ng-star-inserted']"
KD_All_Groups="(//*[@class='ng-dropdown-panel-items scroll-host']//..//*[@class='ng-option ng-star-inserted'])"
KD_Expand_collapse = "//img[@class='plusIcon plusandminusicon']"
KD_Expand_collapse2 = "//img[@class='minusIcon plusandminusicon']"
KD_Li_table_list_txt = "#skylineTransactionalKeydealsTable .datatable-row-wrapper div .col-md-3:nth-of-type(2)"
KD_Li_Summary_Lival = "(//p[@class='headertext'])[2]"

########################################## CX-NPS ############################################
NPS_tab = "//*[text()='Net Promoter Score']"
Nps_exe_clk= "//*[text()='NPS']"
Sales_survey = "//*[@id='filtersearchGroupouter-div1']//..//*[@role='listbox']"
Survey_drp= "//div[@class='ng-dropdown-panel-items scroll-host']//div[@role='option']"

# ------------- COMMON --------------------
common_GlobalFilterXicon = "//*[@class='overlay-filters']//*[@name='close']"
common_GlobalFilterRestore = "//*[@class='overlay-filters']//*[text()='RESET TO DEFAULT']"
common_GlobalFilterChevron2 = "(//*[@class='overlay-filters']//*[@name='icon--chevron--down'])[2]"
common_GlobalFilter_View = "//*[@class='filter-on-hover-body']//*[contains(text(),'View')]"
common_gear = "//*[@class='gear-icon']"
common_gear_NewFilters = "//*[text()=' NEW VIEW ']"
common_gear_deleted_layouts = "//*[@class='gear-icon']//..//button[@class='delete_icon']"
common_delete_popup = "//button[@id='deleteViewDelete-btn']"
Bars_Tooltip = "//*[@class = 'ngx-charts-tooltip-content position-top type-tooltip animate']"
Tracks_Tooltip = "//*[@class='ngx-charts-tooltip-content']"
topnav_dropdown =   "//*[@class='ng-select-container ng-has-value']" #top nav filter
topnav_dropdownElements = "//*[@class='ng-dropdown-panel-items scroll-host']" # top nav dropdown elements
dropdown_wrapper="//*[text()='Revenue Type : ']/..//*[@class='ng-arrow-wrapper']"
dropdown_wrapper2="//*[@class='ng-arrow-wrapper']"
# common_KPI_Budget_Val = "//*[text()='BUDGET']//..//*[@class='value ng-star-inserted']"
common_KPI_Budget_Val = "(//*[@class='value isCircle ng-star-inserted'])[1]"
common_KPI_WSR_Val = "(//*[@class='value isCircle ng-star-inserted'])[2]"

# ------------ MILESTONE ---------------------------------------------
MI_tab = "//*[text()='MILESTONE']"
Customer_jrny = "//*[text()='CUSTOMER JOURNEY']"
Refresh_icon="refreshIcon"
Refresh_datetime="//span[@class='headertext milestoneDate']"
MIDate="//span[text()='MILESTONE']"
MiDate="//span[@class='headertext milestoneDate']"
# MI_opp_val = "//div[@class='col-md-3 col-md-offset-1']"
MI_opp_val = "//*[@id='totalOppCountpara']"
#------------------------CnC----------------------------
dropdown_wrapper2="//*[@class='ng-arrow-wrapper']"
common_Profile_Name = "//*[@class='header-selected-dropdown']"
agg_GraphOne_Title_Common = "//*[@class='text-center title']"
#----------------------------------------------------------
ES_Graph11="(//*[contains(@class, 'text-center title')])[1]//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']"
ES_Graph11_1="(//*[contains(@class, 'text-center title')])[2]//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']"
agg_GraphOne_Title_BUCov1 = "(//*[@class='text-center title'])[1]"
agg_GraphOne_Title_BUPPA = "(//*[@class='text-center title'])[1]"
agg_GraphOne_Title_BUCov2 = "//*[text()='LEVEL17 COV% (PPA)']"
agg_GraphOne_Title_BUPPA = "//*[text()='BUSINESS UNIT GROUP PPA']"
agg_GraphOne_Title_BUCov11 = "//*[text()='LEVEL 17 COV% (PPV)']"

#------------------------GTS_IS_Dual---------------------------

agg_Graph_Card_One = "//*[@class='card']//*[contains(@class,'title')]"
seg_View_SolXaas = "//*[text()='SOLUTIONS - XaaS']"
seg_View_PubCloud = "//*[text()='PUBLIC CLOUD']"
seg_View_PubCloudArrow = "//*[@id='bread_PUBLIC CLOUD']"
seg_View_ServiceType = "//*[text()='SERVICE TYPE']"
seg_View_ServiceTypeArrow = "//*[@id='bread_SERVICE TYPE']"
seg_GTSIS_PubCloudView = "//*[@class='filters-body']//*[text()='Public Cloud : ']//..//*[@class='ng-arrow-wrapper']"
seg_GTSIS_ServiceTypeView = "//*[@class='filters-body']//*[text()='Service Type : ']//..//*[@class='ng-arrow-wrapper']"
seg_GTSIS_PubCloudViewItems = "//*[@class='filters-body']//*[text()='Public Cloud : ']//..//*[@class='ng-dropdown-panel-items scroll-host']"
seg_GTSIS_ServiceTypeViewItems = "//*[@class='filters-body']//*[text()='Service Type : ']//..//*[@class='ng-dropdown-panel-items scroll-host']"


#-------------------- DS - Commercial----

agg_GraphOne_Title_BUCov2 = "//*[text()='BUSINESS UNIT GROUP COV% (PPA)']"
agg_GraphOne_Title_BUPPV2 = "//*[text()='BUSINESS UNIT GROUP PPA']"


# Buyer Group for Digital sales - Please update in "locators.py"

seg_View_Arrow = "//*[@id = 'bread_VIEW']//*[@class='ng-arrow-wrapper']"
seg_View_Buyer = "//*[text()='BUYER GROUP']"


ES_Graph1_DS="//h4[text()='GEO COV% PPA (Adj.)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']"
ES_Graph1_1_DSMK="//h4[text()='MARKET COV% PPA (Adj.)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']"


#---------------------GTS TSS------------
WSR1    = "(//div[@class='verticalCenter'])[2]"
WON3   = "(//div[@class='verticalCenter'])[7]"
VP3        = "(//div[@class='verticalCenter'])[5]"
QP3       = "(//div[@class='verticalCenter'])[6]"

#---------------------System H/W------------
dropdown_wrapperViewType="//*[text()='View Type : ']/..//*[@class='ng-arrow-wrapper']"
totalSummarySelection = "//span[.='Total Summary']"
transactionalOnlySelection = "//span[.='Transactional Only']"

#-------------------Coveragre--------------------
ES_Graph1_1_Cov  = "//h4[text()='BRANCH (EBU) COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']"
ES_Graph1_1_Cov1 = "//h4[text()='BRANCH UNIT (ESU) COV% (PPV)']//..//*[@id='executiveSummaryId']//*[@class='bar my-classpointer myClass']"

#=============================

rev_dd="(//*[@class='ng-select-container ng-has-value'])[2]"
rev_sub_dd="(//*[@class='ng-dropdown-panel-items scroll-host']//*[@class='ng-option-label ng-star-inserted'])"
# rev_txt="(//*[@class='ng-value ng-star-inserted'])[2]"
rev_txt="(//*[@id='bread_REVENUE TYPE'])"

