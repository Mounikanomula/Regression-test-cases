from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
import re
from selenium.webdriver.common.action_chains import ActionChains
from datetime import date
from datetime import datetime
from datetime import timedelta

import SP_Page
import locators
import Login_Page
import Common


driver = Login_Page.driver

# Drilldown to EBR and Drill up one level at a time
def DrillDown_UP_one_level():
    GH1= driver.find_elements_by_xpath(locators.ES_Graph11)
    s=len(GH1)
    det=Common.getlist()
    print("Geo "+str(det))
    P_ok=det[0]
    for i in P_ok:
        time.sleep(5)
        GH1= driver.find_elements_by_xpath(locators.ES_Graph11)
        time.sleep(5)
        ActionChains(driver).move_to_element(GH1[i]).perform()
        time.sleep(5)
        CL= driver.find_elements_by_xpath(locators.Drilldown)
        print(i)
        print(type(i))
        ActionChains(driver).click(CL[i]).perform()
        time.sleep(5)
        print("DrillDown to Market")
        det1=Common.getlist()
        print("Market: "+str(det1))
        P_ok1=det1[0]
        for j in P_ok1:
            time.sleep(5)
            DD1= driver.find_elements_by_xpath(locators.ES_Graph11_1)
            ActionChains(driver).move_to_element(DD1[j]).perform()
            time.sleep(5)
            CL= driver.find_elements_by_xpath(locators.Drilldown)
            print(j)
            print(type(j))
            ActionChains(driver).click(CL[j]).perform()
            time.sleep(5)
            print("DrillDown to EBR")
            break
        driver.find_element_by_xpath(locators.DrillUP).click()
        time.sleep(5)
        print("DrillUP to Market")
        break
    driver.find_element_by_xpath(locators.DrillUP).click()
    print("DrillUP to Geo")

# Drilldown to EBR and Drill up Top level
def DrillDown_UP_Top_level():
    driver.find_element_by_xpath(locators.ES).click()
    time.sleep(10)
    GH1= driver.find_elements_by_xpath(locators.ES_Graph11)
    s=len(GH1)
    det=Common.getlist()
    print("Geo "+str(det))
    P_ok=det[0]
    for i in P_ok:
        time.sleep(5)
        GH1= driver.find_elements_by_xpath(locators.ES_Graph11)
        ActionChains(driver).move_to_element(GH1[i]).perform()
        time.sleep(5)
        CL= driver.find_elements_by_xpath(locators.Drilldown)
        print(i)
        print(type(i))
        ActionChains(driver).click(CL[i]).perform()
        time.sleep(5)
        print("DrillDown to Market")
        det1=Common.getlist()
        print("Market: "+str(det1))
        P_ok1=det1[0]
        for j in P_ok1:
            time.sleep(5)
            DD1= driver.find_elements_by_xpath(locators.ES_Graph11_1)
            ActionChains(driver).move_to_element(DD1[j]).perform()
            time.sleep(5)
            CL= driver.find_elements_by_xpath(locators.Drilldown)
            print(j)
            print(type(j))
            ActionChains(driver).click(CL[j]).perform()
            time.sleep(5)
            print("DrillDown to EBR")
            break
        break
    driver.find_element_by_xpath(locators.DrillTop).click()
    print("DrillTOP to Geo")

def EStop_nav():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle=driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    time.sleep(2)
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :"+str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-1):
        time.sleep(2)
        GH1[i].click()
        time.sleep(2)
        Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
        print(Topnav.text)
        listLegend1.append(Topnav.text)
        driver.find_element_by_xpath(locators.dropdown_wrapper2).click()
    # print(listLegend1)
    for i in listLegend1:
            listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    assert listLegend2==[['NQ'], ['COMMERCIAL'], ['All', '<$250K', '$250K - <$1M', '$1M - <$5M', '$5M - <$10M', '>$10M'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'IBM Logo Services', 'Multivendor Services']],  "Not expected"
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    return listLegend2

# def aggPipe_GraphThree_xAxis():
#     agg_PPqXaxis = driver.find_elements_by_xpath((locators.agg_Graph3)+(locators.agg_graphxAxis))
#     geoList=[]
#     for geo in agg_PPqXaxis:
#         geoList.append(geo.text)
#     return geoList

def APtop_nav():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle=driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    time.sleep(2)
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :"+str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-2):
    # for i in [0,2,3,4]:
        try:
            # print(i)
            time.sleep(2)
            GH1[i].click()
            time.sleep(2)
            Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
            print(Topnav.text)
            listLegend1.append(Topnav.text)
            driver.find_element_by_xpath(locators.dropdown_wrapper2).click()
        except(RuntimeError, TypeError, NameError, Exception):
            print("Top Nav failed for : "+str(i))
            print("Not Clickable")
            pass
    # print(listLegend1)
    for i in listLegend1:
            listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    assert listLegend2==[['NQ'], ['COMMERCIAL'], ['All', '<$250K', '$250K - <$1M', '$1M - <$5M', '$5M - <$10M', '>$10M'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'IBM Logo Services', 'Multivendor Services'], ['UNIT']],"Not expected"
    return listLegend2



def loop_view(): #lopping accross views opts and coming back to summary view. Checking with KPI's, failing for Dealsize,Channel Budget graph1 not mathcing as 0,for INDUSTRY SOLUTIONS - Budget and VP not matching as 0
    bp_res = ""
    vpqp_res=""
    vpG4_res=""
    driver.find_element_by_xpath(locators.filter_icon).click()
    driver.find_element_by_xpath(locators.sp_view2).click()
    lb=driver.find_elements_by_xpath(locators.sp_view_count)
    len(lb)
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    time.sleep(10)
    for i in range(len(lb)):
        driver.find_element_by_xpath(locators.sp).click()
        driver.find_element_by_xpath(locators.filter_icon).click()
        driver.find_element_by_xpath(locators.sp_view2).click()
        option=driver.find_element_by_xpath('(' + locators.sp_view_opt + ')' + "[" + str(i + 1) + "]").text
        print("View: "+option)
        time.sleep(3)
        driver.find_element_by_xpath('(' + locators.sp_view_opt_clk + ')'+"["+str(i+1)+"]").click()
        driver.find_element_by_xpath(locators.filter_icon_close).click()
        time.sleep(5)
        Common.Graphs()
        kpi = SP_Page.SP_KPI()
        if option!="SOLUTIONS - Strategic Imperatives":
            bp=SP_Page.Budget_PPV()
            # print(kpi[0])
            # print(kpi[1])
            # print(bp[0][0])
            # print(bp[1][0])
            if (kpi[0]!=bp[0][0]) or (kpi[1]!=bp[1][0]):
                bp_res="Budget or PPV not matching for Graph1"
                print(bp_res)
            # SP_KPI()
            vpqp=SP_Page.VP_QP()
            # print(kpi[4])
            # print(vpqp[0])
            # print(kpi[5])
            # print(vpqp[1])
            if (kpi[4]!=vpqp[0]) or (kpi[5]!=vpqp[1]):
                vpqp_res="VP Graph2 or QP Graph3 not matching"
                print(vpqp_res)
            # SP_KPI()
            vpG4=SP_Page.VP_graph4()
            # print(kpi[4])
            # print(vpG4[0])
            if kpi[4]!=vpG4[0]:
                vpG4_res="VP not matching for Graph4"
                print(vpG4_res)
        else:
            print("At present Not checking for the view : SOLUTIONS - Strategic Imperatives")
            pass
            # SP_KPI()
    #     time.sleep(5)
    #     print(driver.find_element_by_xpath("(//*[@class='ng-value-label ng-star-inserted'])[3]").text) # after clicking get the text

    driver.find_element_by_xpath(locators.filter_icon).click()
    driver.find_element_by_xpath(locators.sp_view2).click()
    time.sleep(8)
    driver.find_element_by_xpath('(' + locators.sp_view_sum_clck+ ')'+"["+str(1)+"]").click()
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    time.sleep(10)
    print(bp_res,vpqp_res,vpG4_res)
    return bp_res,vpqp_res,vpG4_res

def SPtop_nav():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle=driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    time.sleep(2)
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :"+str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)):
        try:
            time.sleep(2)
            GH1[i].click()
            time.sleep(2)
            Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
            print(Topnav.text)
            listLegend1.append(Topnav.text)
            driver.find_element_by_xpath(locators.dropdown_wrapper2).click()
        except(RuntimeError, TypeError, NameError, Exception):
            print("Top Nav failed for : "+str(i))
            print("Not Clickable")
            pass
    # print(listLegend1)
    for i in listLegend1:
            listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    assert listLegend2 == [['NQ'], ['COMMERCIAL'], ['All', '<$250K', '$250K - <$1M', '$1M - <$5M', '$5M - <$10M', '>$10M'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'IBM Logo Services', 'Multivendor Services'], ['SUMMARY', 'DEAL SIZE', 'CHANNEL']], "Not expected"
    return listLegend2

def kdtop_nav():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle = driver.find_element_by_xpath(locators.MoveElementkd)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :" + str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-8):
        try:
            time.sleep(2)
            GH1[i].click()
            time.sleep(2)
            Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
            print(Topnav.text)
            listLegend1.append(Topnav.text)
            driver.find_element_by_xpath(locators.dropdown_wrapper2).click()
        except(RuntimeError, TypeError, NameError, Exception):
            print("Top Nav failed for : "+str(i))
            print("Not Clickable")
            pass
    for i in listLegend1:
        listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    time.sleep(5)
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    assert listLegend2 == [['NQ'], ['COMMERCIAL'], ['All', '<$250K', '$250K - <$1M', '$1M - <$5M', '$5M - <$10M', '>$10M'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'IBM Logo Services', 'Multivendor Services'], ['LIO'], ['CLIENT AGGREGATION', 'ALL LINE ITEMS'], ['By BU group', 'By BU Sub group', 'By Level 17', 'By WSR', 'By Dealsize', 'By SAQ', 'By SAQ Quadrant', 'By Market', 'By Branch Group (EBR)', 'By Branch (EBU)', 'By Branch Unit (ESU)', 'By Client Type', 'By Client Sub Type', 'By Client Set', 'By Channel', 'By Reporting Country', 'By Roadmap Status', 'By Close/Bill Week', 'By Close/Bill Month', 'By OI Source', 'By ISU Group', 'By ISU', 'By Geo']],  "not expected"
    return listLegend2

def RMtop_nav():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle = driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    # driver.find_element_by_xpath(locators.RMTab).click()
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :" + str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-5):
        try:
            time.sleep(2)
            GH1[i].click()
            time.sleep(2)
            Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
            print(Topnav.text)
            listLegend1.append(Topnav.text)
            driver.find_element_by_xpath(locators.dropdown_wrapper2).click()
        except(RuntimeError, TypeError, NameError, Exception):
            print("Top Nav failed for : "+str(i))
            print("Not Clickable")
            pass
    for i in listLegend1:
        listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    assert listLegend2 == [['NQ'], ['COMMERCIAL'], ['All', '<$250K', '$250K - <$1M', '$1M - <$5M', '$5M - <$10M', '>$10M'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'IBM Logo Services', 'Multivendor Services'], ['LIO'], ['LEVEL17', 'LEVEL 20', 'DEAL SIZE', 'CONTRACT TYPE']],"not expected"
    return listLegend2

def Mitop_nav():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle = driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :" + str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-4):
        try:
            time.sleep(2)
            GH1[i].click()
            time.sleep(2)
            Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
            print(Topnav.text)
            listLegend1.append(Topnav.text)
            driver.find_element_by_xpath(locators.dropdown_wrapper2).click()
        except(RuntimeError, TypeError, NameError, Exception):
            print("Top Nav failed for : "+str(i))
            print("Not Clickable")
            pass
    for i in listLegend1:
        listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    time.sleep(3)
    driver.find_element_by_xpath(locators.common_GlobalFilterXicon).click()
    assert listLegend2 == [['NQ'], ['COMMERCIAL'], ['All', '<$250K', '$250K - <$1M', '$1M - <$5M', '$5M - <$10M', '>$10M'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'IBM Logo Services', 'Multivendor Services'], ['LIO'], ['ALL LINE ITEMS'], ['Identifying (1)', 'Validated (4)', 'Qualifying (7)', 'Gaining Agreement (6)']], "is not expected"
    return listLegend2

def Tss_aggPipe_GraphOne_Title_BU():
    global agg_GrOne_Title
    budgetVerify = driver.find_element_by_xpath(locators.common_KPI_Budget_Val).text
    print(budgetVerify)
    if budgetVerify != 'N/A':
        agg_GrOne_Title = driver.find_element_by_xpath(locators.agg_GraphOne_Title_BUCov2)
    elif budgetVerify == 'N/A':
        agg_GrOne_Title = driver.find_element_by_xpath(locators.agg_GraphOne_Title_BUPPV)
    print(agg_GrOne_Title.text)
    print(agg_GrOne_Title.text)
    return agg_GrOne_Title
##---------------------------call code below-------------------------##


# Login_Page.open_ISD()
# ISDLOGO()
# NEEDHELP()
# Profile_Page_AH()
# PRIVACY()
# ABOUTISD()
# PROFILEINFO()
# LEXPANDICON()
# LEXPANDICON_close()
# es_breadcrumb()
# ES_KPI()
# es_budget(Graph1()) #(ingore for now)
# es_ppv(Graph1()) #(ingore for now)
# geo_check(Graph1()) #(ingore for now)
# #graph2()   # Giving error due to "N/A" #(ingore for now)
# G1_G2_Budget_PPV()
# G3_G4_Budget_WSR_WON()
# DrillDown_UP_one_level()
# DrillDown_UP_Top_level()
# EStop_nav()
# MESChecking()
# ESGraphDate1()
# ESGraphDate2()
# ESGraphDate3()
# ESGraphDate4()

# VP_KPI_DF_Grp()
# VP_KPI_vs_Summary_DealList()
# VP_KPI_Summary_DealList_vs_Sum_Detailed_List()
#
# WSR_KPI_DF_Grp()
# WSR_KPI_vs_Summary_DealList()
# WSR_KPI_Summary_DealList_vs_Sum_Detailed_List()
#
# WON_KPI_DF_Grp()
# WON_KPI_vs_Summary_DealList()
# WON_KPI_Summary_DealList_vs_Sum_Detailed_List()