from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
import re
from selenium.webdriver.common.action_chains import ActionChains
from datetime import date
from datetime import datetime
from datetime import timedelta
import locators
import Login_Page
import Common
import Constants
import ES_Page
import AP_Page
import SP_Page
import RD_Page
import KD_Page
import MI_Page

# Description:
#  GIMD Requirement profile selections is with IA

driver = Login_Page.driver

# ---------------------Executive Summary---------------------------------------------
def GIMD_Graph1():
    time.sleep(10)
    MoveEle = driver.find_element_by_xpath("(//div[@class='verticalCenter'])[5]")
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()

    gh1 = driver.find_elements_by_xpath(locators.GIMD_g1)
    st = []

    for i in range(len(gh1)):
        ActionChains(driver).move_to_element(gh1[i]).perform()
        time.sleep(2)
        tp = (driver.find_element_by_xpath(locators.hover_text)).text
        print(tp)  # Getting the Raw details of Geo
        st.append(tp)
    print(st)          # Details in List format
    g1 = ""
    for x in st:
        g1 = g1 + x
    print(g1)
    return g1

def es_budget(g1):
    budget1 = re.findall(r'Budget : \$(.*)M', g1)
    budget_isd = []
    for i in budget1:
        i = str(i).replace('M', '')
        i = round(float(str(i).replace(",", "")))
        budget_isd.append(i)
    print("G1 Budget: "+str(budget_isd))   # Budget details in List format
    sum_budget_g1 = sum(budget_isd)
    print("G1 Sum Budget: "+str(sum_budget_g1))  # Sum of Budget for bars
    return [budget_isd,sum_budget_g1]

def es_Radiobuttonswitch():

    # Radio_btn = driver.find_element_by_xpath("//h4[text()='SECTOR GM COV% (PPV)']//..//div[@class='radio-buttons ng-star-inserted']")
    Radio_btn = driver.find_element_by_xpath(
        "//h4[text()='SECTOR GM COV% (PPV)']//..//label[@class='bx--radio-button__label']")
    assert Radio_btn.is_displayed()
    if (Radio_btn.is_displayed()):
        print(Radio_btn.text)
    else:
        print("Radio button text is not displayed")

def view_switch_RB():
    Bu_switch = driver.find_element_by_xpath("(//h4[text()='SECTOR GM COV% (PPV)']//..//label[@class='bx--radio-button__label'])[2]")
    # Radio_btn = driver.find_element_by_xpath("//h4[text()='SECTOR GM COV% (PPV)']//..//div[@class='radio-buttons ng-star-inserted']")
    Title_header = driver.find_element_by_xpath("//h4[text()='SECTOR GM COV% (PPV)']")

    if 'BU' in Bu_switch.text:
        print("Selected Radio button is "+ str(Bu_switch.text))
        Bu_switch.click()

        assert Title_header!= "BUSINESS UNIT GROUP COV% (PPV)", "For BU radio button, Header is incorrect"

    else:
        print("Toggle button is not working and is not selected")
    time.sleep(2)
    Geo_switch = driver.find_element_by_xpath("(//h4[text()='BUSINESS UNIT GROUP COV% (PPV)']//..//label[@class='bx--radio-button__label'])[1]")
    Geo_switch.click()
    assert Title_header != "SECTOR GM COV% (PPV)", "For Geo radio button, Header is incorrect"

def graph2(): # Giving error due to "N/A"
    gh2 = driver.find_elements_by_xpath(locators.GIMD_g2)
    st2 = []

    for i in range(len(gh2)):
        ActionChains(driver).move_to_element(gh2[i]).perform()
        time.sleep(5)
        tp = (driver.find_element_by_xpath(locators.G2_hover)).text
        print(tp)  # Getting the Raw details of Geo
        st2.append(tp)
    print(st2)          # Details in List format
    g2 = ""
    for x in st2:
        g2 = g2 + x
    print(g2)
    return g2

def GIMD_G1_Budget_PPV():
    B = []
    P = []
    G=[]
    bud=""
    ppv=""
    Sector_GM=""
    ESKPI = ES_Page.ES_KPI()
    # print(ESKPI)
    for j in [1]:
    # for j in [2]:
    #     driver.find_element_by_xpath(locators.max1 + '[' + str(j + 1) + ']').click()
        driver.find_element_by_xpath(locators.max1 + '[' + str(j) + ']').click()
        driver.find_element_by_xpath(locators.showhide).click()
        tx = driver.find_elements_by_xpath(locators.firstrow) # gives the total number of Rows in the table
        print(len(tx))
        t = 0
        t2 = 0
        for i in range(len(tx)):
            tx = driver.find_element_by_xpath('(' + locators.firstrow + ')' + '[' + str(i + 1) + ']').text
            tx = tx.split('\n')
            tx1 = tx[1].replace(",", "")
            tx1 = float(tx1) if tx1 != "N/A" else 0  #Inline if Function
            t = t + tx1
            tx2 = tx[3].replace(",", "")
            tx2 = float(tx2) if tx2 != "N/A" else 0
            t2 = t2 + tx2
            tx3=tx[0]
            G.append(tx3)

        #     print("Budget Graph"+str(j+1)+" : "+str(t)) # give values in list
        print("Sum Budget Graph_" + str(j) + " : " + str(t))
        B.append(round(t))
        #     print("PPV Graph"+str(j+1)+" : "+str(t2)) # give values in list
        print("Sum PPV Graph_" + str(j) + " : " + str(t2))
        P.append(round(t2))
        print("GIMD-Axis :"+str(G))
        driver.find_element_by_xpath(locators.showhide).click()
        driver.find_element_by_xpath(locators.min1).click()
    print(B, P,G)
    if ESKPI[0] != B[0]:
        bud = "Budget not matching for Graph1"
    if ESKPI[3] != P[0]:
        ppv = "PPV not matching for Graph1"
    if Constants.GIMD_Sector_list!=G:
        SectorGM="SectorGM not matching"
    print(bud, ppv,Sector_GM)
    assert ((bud != "Budget not matching for Graph1") & (
                ppv != "PPV not matching for Graph1")& (
        Sector_GM != "SectorGM not matching")), "Budget or PPV or Sector_GM not matching for Graph1"

def G2_Budget_QTD_Actuals_GIMD():
    B = []
    Q = []
    bud=""
    qtd=""
    ESKPI = ES_Page.ES_KPI()
    # for j in range(2):
    for j in [2]:
        # driver.find_element_by_xpath(locators.max1 + '[' + str(j + 1) + ']').click()
        time.sleep(5)
        # driver.find_element_by_xpath(locators.max1 + '[' + str(j) + ']').click()
        ActionChains(driver).move_to_element(locators.QTD_Graph_GIMD[j]).perform()
        driver.find_element_by_xpath(locators.QTD_Graph_GIMD + '[' + str(j) + ']').click()
        # driver.find_element_by_xpath(locators.QTD_Graph_GIMD).click()
        driver.find_element_by_xpath(locators.showhide).click()
        tx = driver.find_elements_by_xpath(locators.firstrow) # gives the total number of Rows in the table
        print(len(tx))
        t = 0
        t2 = 0
        for i in range(len(tx)):
            tx = driver.find_element_by_xpath('(' + locators.firstrow + ')' + '[' + str(i + 1) + ']').text
            tx = tx.split('\n')
            tx1 = tx[1].replace(",", "")
            tx1 = float(tx1) if tx1 != "N/A" else 0  #Inline if Function
            t = t + tx1
            tx2 = tx[3].replace(",", "")
            tx2 = float(tx2) if tx2 != "N/A" else 0
            t2 = t2 + tx2
        #     print("Budget Graph"+str(j+1)+" : "+str(t)) # give values in list
        print("Sum Budget Graph_" + str(j) + " : " + str(t))
        B.append(round(t))
        #     print("PPV Graph"+str(j+1)+" : "+str(t2)) # give values in list
        print("Sum QTD Actuals Graph_" + str(j) + " : " + str(t2))
        Q.append(round(t2))
        driver.find_element_by_xpath(locators.showhide).click()
        driver.find_element_by_xpath(locators.min1).click()
    print(B, Q)
    if ESKPI[0] != B[0]:
        bud = "Budget not matching for Graph2"
    if ESKPI[1] != Q[0]:
        qtd = "QTD Actuals not matching for Graph2"
    print(bud, qtd)
    assert ((bud != "Budget not matching for Graph2") & (
            qtd != "QTD Actuals not matching for Graph2")), "Budget or QTD Actuals not matching for Graph2"

def GIMD_DrillDown_UP_one_level():
    GH1= driver.find_elements_by_xpath(locators.GIMD_g1)
    s=len(GH1)
    det=Common.getlist()
    print("SGM "+str(det))
    P_ok=det[0]
    # print(P_ok)
    for i in P_ok:
        time.sleep(5)
        GH1= driver.find_elements_by_xpath(locators.GIMD_g1)
        print(i)
        ActionChains(driver).move_to_element(GH1[i]).perform()
        time.sleep(5)
        CL= driver.find_elements_by_xpath(locators.Drilldown)
        print(i)
        print(type(i))
        ActionChains(driver).click(CL[i]).perform()
        time.sleep(5)
        print("DrillDown to GEO")
        det1=Common.getlist()
        print("GEO: "+str(det1))
        P_ok1=det1[0]
        for j in P_ok1:
            time.sleep(5)
            DD1= driver.find_elements_by_xpath(locators.GIMD_g1_1)
            ActionChains(driver).move_to_element(DD1[j]).perform()
            time.sleep(5)
            CL= driver.find_elements_by_xpath(locators.Drilldown)
            print(j)
            print(type(j))
            ActionChains(driver).click(CL[j]).perform()
            time.sleep(5)
            print("DrillDown to Market")
            break
        driver.find_element_by_xpath(locators.Drilup_updated).click()
        time.sleep(5)
        print("DrillUP to GEO")
        break
    driver.find_element_by_xpath(locators.Drilup_updated).click()
    print("DrillUP to SGM")

# Drilldown to IA and Drill up Top level
def GIMD_DrillDown_UP_Top_level():
    driver.find_element_by_xpath(locators.ES).click()
    time.sleep(10)
    GH1= driver.find_elements_by_xpath(locators.GIMD_g1)
    s=len(GH1)
    det=Common.getlist()
    print("SGM "+str(det))
    P_ok=det[0]
    for i in P_ok:
        time.sleep(5)
        GH1= driver.find_elements_by_xpath(locators.GIMD_g1)
        ActionChains(driver).move_to_element(GH1[i]).perform()
        time.sleep(5)
        CL= driver.find_elements_by_xpath(locators.Drilldown)
        print(i)
        print(type(i))
        ActionChains(driver).click(CL[i]).perform()
        time.sleep(5)
        print("DrillDown to GEO")
        det1=Common.getlist()
        print("Market: "+str(det1))
        P_ok1=det1[0]
        for j in P_ok1:
            time.sleep(5)
            DD1= driver.find_elements_by_xpath(locators.GIMD_g1_1)
            ActionChains(driver).move_to_element(DD1[j]).perform()
            time.sleep(5)
            CL= driver.find_elements_by_xpath(locators.Drilldown)
            print(j)
            print(type(j))
            ActionChains(driver).click(CL[j]).perform()
            time.sleep(5)
            print("DrillDown to Market")
            break
        break
    driver.find_element_by_xpath(locators.DrillTop).click()
    print("DrillTOP to Geo")

def EStop_nav_GIMD():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle=driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    time.sleep(2)
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :"+str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-1):
        time.sleep(2)
        GH1[i].click()
        time.sleep(2)
        Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
        print(Topnav.text)
        listLegend1.append(Topnav.text)
        driver.find_element_by_xpath(locators.dropdown_wrapper).click()
    # print(listLegend1)
    for i in listLegend1:
            listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    assert listLegend2==[['NQ'], ['Signings', 'Signings-ACV'], ['All', 'Communications', 'Distribution', 'FSS: Insurance', 'FSS: NALASIA', 'FSS: US&E', 'Industrial', 'Public'], ['All', 'IA Direct', 'IA Delegated'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'Systems w/TPS', 'Cloud & Data Platform', 'Security', 'Cognitive Applications', 'Watson Health', 'Industry Platforms']]
    return listLegend2



def APtop_nav_GIMD():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle=driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    time.sleep(2)
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :"+str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-2):
        time.sleep(2)
        GH1[i].click()
        time.sleep(2)
        Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
        print(Topnav.text)
        listLegend1.append(Topnav.text)
        driver.find_element_by_xpath(locators.dropdown_wrapper).click()
    # print(listLegend1)
    for i in listLegend1:
            listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    assert listLegend2==[['NQ'], ['Signings', 'Signings-ACV'], ['All', 'Communications', 'Distribution', 'FSS: Insurance', 'FSS: NALASIA', 'FSS: US&E', 'Industrial', 'Public'], ['All', 'IA Direct', 'IA Delegated'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'Systems w/TPS', 'Cloud & Data Platform', 'Security', 'Cognitive Applications', 'Watson Health', 'Industry Platforms'], ['GEO', 'UNIT']],"Not expected"
    return listLegend2


# def Topnav_Reset():          wILL PERFORM AFTER EVERY ACTIVITY IS COMPLETED-0- IN PROGRESS
#     view_click = driver.find_element_by_xpath("//label[text()='View : ']//..//span[@class='ng-arrow-wrapper']").click()

def aggPipe_GraphOne_xAxis_GIMD():
    #agg_geoXaxis = driver.find_elements_by_xpath(locators.agg_geoCovGraphxAxis)
    view_txt = driver.find_element_by_xpath(locators.common_GlobalFilter_View).text
    agg_geoXaxis = driver.find_elements_by_xpath((locators.agg_Graph1)+(locators.agg_graphxAxis))
    Sector_Agg_list = []
    for SGM in agg_geoXaxis:
        Sector_Agg_list.append(SGM.text)
    return Sector_Agg_list

def aggPipe_GraphOne_Title_BU_GIMD():
    global agg_GrOne_Title
    budgetVerify = driver.find_element_by_xpath(locators.common_KPI_Budget_Val).text
    print(budgetVerify)
    if budgetVerify != 'N/A':
        agg_GrOne_Title = driver.find_element_by_xpath(locators.agg_GraphOne_Title_SGMCov)
    elif budgetVerify == 'N/A':
        agg_GrOne_Title = driver.find_element_by_xpath(locators.agg_GraphOne_Title_SGMPPV)
    print(agg_GrOne_Title.text)
    print(agg_GrOne_Title.text)
    return agg_GrOne_Title

def SPtop_nav_GIMD():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle=driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    time.sleep(2)
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :"+str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)):
        time.sleep(2)
        GH1[i].click()#segPipe_KPI_Labels()
        time.sleep(2)
        Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
        print(Topnav.text)
        listLegend1.append(Topnav.text)
        driver.find_element_by_xpath(locators.dropdown_wrapper).click()
    # print(listLegend1)
    for i in listLegend1:
            listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    assert listLegend2 == [['NQ'], ['Signings', 'Signings-ACV'],  ['All', 'Communications', 'Distribution', 'FSS: Insurance', 'FSS: NALASIA', 'FSS: US&E', 'Industrial', 'Public'], ['All', 'IA Direct', 'IA Delegated'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'Systems w/TPS', 'Cloud & Data Platform', 'Security', 'Cognitive Applications', 'Watson Health', 'Industry Platforms'], ['DEAL SIZE', 'CHANNEL', 'JTC/RHS', 'JTC', 'RHS', 'SOLUTIONS - Strategic Imperatives', 'SECTOR GM', 'INTEGRATED ACCOUNTS', 'INDUSTRY SOLUTIONS','OI GROUP']], "Not expected"
    return listLegend2

def segPipe_KPI_Labels_GIMD():
    lbl_KPI = driver.find_elements_by_xpath(locators.Seg_KPI_SI_labels)
    print(len(lbl_KPI))
    lblKPIlist = []
    for i in range(len(lbl_KPI)):
        eachKPIlbl = driver.find_element_by_xpath("("+locators.Seg_KPI_SI_labels+")"+"["+str(i+1)+"]")
        lblKPIlist.append(eachKPIlbl.text)
    print(lblKPIlist)
    return lblKPIlist

def SP_KPI_Labels_StratImp_GIMD():
    # ------ to verify if all Strategic Imperatives-related KPI are present -----------
    actualKPIlabels = locators.Seg_KPI_SI_labels
    print(actualKPIlabels)
    assert actualKPIlabels == Constants.SP_SI_KPI_Labels_GIMD, "One or more of the labels does not match the expected"

# def segPipe_KPI_Labels_GIMD():
#     time.sleep(10)
#     lbl_KPI = driver.find_elements_by_xpath(locators.Seg_KPI_SI_labels)
#     print(len(lbl_KPI))
#     lblKPIlist = []
#     for i in range(len(lbl_KPI)):
#         eachKPIlbl = driver.find_element_by_xpath("("+locators.Seg_KPI_SI_labels+")"+"["+str(i+1)+"]")
#         lblKPIlist.append(eachKPIlbl.text)
#     print(lblKPIlist)
#     return lblKPIlist

def summ_view():
    # Back to Summary View
    driver.find_element_by_xpath(locators.filter_icon).click()
    driver.find_element_by_xpath(locators.sp_view2).click()
    time.sleep(3)
    driver.find_element_by_xpath("(" + locators.sp_view_sum_clck + ")" + "[" + str(1) + "]").click()
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    time.sleep(2)

def sp_expand_showhide_colapase():
    # Expand graph show table get first row the hide table then close expand
    time.sleep(5)
    max2=driver.find_elements_by_xpath(locators.max1)
    print(max2)
    for i in range(len(max2)-1): # In Summary view there are only 3 graphs but showing 4 expand icons
        try:
            driver.find_element_by_xpath(locators.max1+str([i+1])).click()
            driver.find_element_by_xpath(locators.sp_showhide).click()
        #     time.sleep(5)
            val=driver.find_element_by_xpath(locators.firstrow).text
        #     print(val)
            assert type(val)==str,"No Values"
            driver.find_element_by_xpath(locators.sp_showhide).click()
            driver.find_element_by_xpath(locators.min1).click()
        except(RuntimeError, TypeError, NameError, ValueError, Exception):
            print("No Data Available")
            driver.find_element_by_xpath(locators.min1).click()

def Graphs1():
    # Get the graphs title in each section
    gh = driver.find_elements_by_xpath(locators.Graphs1)
    len(gh)
    g1 = []
    for i in range(len(gh)): # In Summary view there are only 3 graphs but showing 4 title showing
        g = driver.find_element_by_xpath('('+locators.Graphs1+')' + '[' + str(i + 1) + ']').text
        g1.append(g)
    print(g1)
    return g1


def loop_view_SP_GIMD(): #lopping accross views opts and coming back to summary view. Checking with KPI's, failing for Dealsize,Channel Budget graph1 not mathcing as 0,for INDUSTRY SOLUTIONS - Budget and VP not matching as 0
    bp_res = ""
    vpqp_res=""
    vpG4_res=""
    driver.find_element_by_xpath(locators.filter_icon).click()
    driver.find_element_by_xpath(locators.sp_view).click()
    lb=driver.find_elements_by_xpath(locators.sp_view_count)
    len(lb)
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    time.sleep(10)
    for i in range(len(lb)):
        driver.find_element_by_xpath(locators.sp).click()
        driver.find_element_by_xpath(locators.filter_icon).click()
        driver.find_element_by_xpath(locators.sp_view).click()
        option=driver.find_element_by_xpath('(' + locators.sp_view_opt + ')' + "[" + str(i + 1) + "]").text
        print("View: "+option)
        driver.find_element_by_xpath('(' + locators.sp_view_opt_clk + ')'+"["+str(i+1)+"]").click()
        driver.find_element_by_xpath(locators.filter_icon_close).click()

        if option!="SOLUTIONS - Strategic Imperatives" and option!="JTC/RHS" and option!="JTC" and option!="RHS":
            time.sleep(5)
            Common.Graphs1()
            kpi = SP_Page.SP_KPI()
            bp=SP_Page.Budget_PPV()
            # print(kpi[0])
            # print(kpi[1])
            # print(bp[0][0])
            # print(bp[1][0])
            if (kpi[0]!=bp[0][0]) or (kpi[1]!=bp[1][0]):
                bp_res="Budget or PPV not matching for Graph1"
                print(bp_res)
            # SP_KPI()
            vpqp=SP_Page.VP_QP()
            # print(kpi[4])
            # print(vpqp[0])
            # print(kpi[5])
            # print(vpqp[1])
            if (kpi[4]!=vpqp[0]) or (kpi[5]!=vpqp[1]):
                vpqp_res="VP Graph2 or QP Graph3 not matching"
                print(vpqp_res)
            # SP_KPI()
            vpG4=SP_Page.VP_graph4()
            # print(kpi[4])
            # print(vpG4[0])
            if kpi[4]!=vpG4[0]:
                vpG4_res="VP not matching for Graph4"
                print(vpG4_res)
        elif option=="JTC/RHS":
            time.sleep(5)
            Common.Graphs1()
            # SP_KPI()
            # Common.sp_expand_showhide_colapase3()
        elif option=="JTC" or option=="RHS":
            time.sleep(5)
            Common.Graphs1()
            # SP_KPI2()
            # Common.sp_expand_showhide_colapase2()
        else:
            time.sleep(5)
            Common.Graphs1()
            print("At present Not checking for the view : SOLUTIONS - Strategic Imperatives")
            pass
            # SP_KPI()
    #     time.sleep(5)
    #     print(driver.find_element_by_xpath("(//*[@class='ng-value-label ng-star-inserted'])[3]").text) # after clicking get the text

    driver.find_element_by_xpath(locators.filter_icon).click()
    driver.find_element_by_xpath(locators.sp_view).click()
    time.sleep(2)
    driver.find_element_by_xpath('(' + locators.SP_View_Summary_CLK+ ')'+"["+str(1)+"]").click()
    time.sleep(3)
    Reset_btn_clk = driver.find_element_by_xpath("//button[text()='RESET TO DEFAULT']")
    Reset_btn_clk.click()
    time.sleep(3)
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    time.sleep(10)
    print(bp_res,vpqp_res,vpG4_res)
    return bp_res,vpqp_res,vpG4_res


def RMtop_nav_GIMD():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle = driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    # driver.find_element_by_xpath(locators.RMTab).click()
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :" + str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-4):
        time.sleep(2)
        GH1[i].click()
        time.sleep(2)
        Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
        print(Topnav.text)
        listLegend1.append(Topnav.text)
        driver.find_element_by_xpath(locators.dropdown_wrapper).click()
    for i in listLegend1:
        listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    assert listLegend2== [['NQ'], ['Signings', 'Signings-ACV'],  ['All', 'Communications', 'Distribution', 'FSS: Insurance', 'FSS: NALASIA', 'FSS: US&E', 'Industrial', 'Public'], ['All', 'IA Direct', 'IA Delegated'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'Systems w/TPS', 'Cloud & Data Platform', 'Security', 'Cognitive Applications', 'Watson Health', 'Industry Platforms'], ['LIO'], ['GEO', 'BU', 'INTEGRATED ACCOUNTS']],"not expected"
    return listLegend2

def Wkly_Build_Inline_Clicks_GIMD():
    # ------- default view (Wkly_Build) ------------------
    print("Chart Title:", driver.find_element_by_xpath(locators.RMGT4).text)
    print("Legend:", driver.find_element_by_xpath(locators.Wkly_Build_Legend).text)

    # -------- inline clicks and corresponding views ------------
    arrow_Click = driver.find_element_by_xpath(locators.Wkly_Build_Chart_Inline_Click)
    arrow_Click.click()
    agg_Chart_Inline = driver.find_elements_by_xpath(locators.agg_Chart_Inlines)
    print("Element Size:", len(agg_Chart_Inline))
    for i in range(len(agg_Chart_Inline)):
        dropItem = driver.find_element_by_xpath("(" + locators.agg_Chart_Inlines + ")" + "[" + str(i + 1) + "]")
        print("Dropdown Item:", dropItem.text)
        dropItem.click()
        time.sleep(1)
        print(driver.find_element_by_xpath(locators.RMGT4).text)
        print("Chart Title", driver.find_element_by_xpath(locators.RMGT4).text)
        print("Legend:", driver.find_element_by_xpath(locators.Wkly_Build_Legend).text)
        # legendIndi = driver.find_element_by_xpath(locators.agg_Track_Legend_Indi)
        # print("Related Legend:", legendIndi.text)
        time.sleep(1)
        RD_Page.RMBudgetcomparison()
        RD_Page.Wkly_Build_WSR_KPI()
        arrow_Click.click()
        time.sleep(1)
    arrow_Click.click()
    driver.find_element_by_xpath(locators.Wkly_Build_Chart_Inline_Click).click()
    driver.find_element_by_xpath(locators.Wkly_Build_Inline_setToWSR).click()
    time.sleep(1)

def segPipe_KPI_Tiles_VP_Onwards_StratImp():
    tile_KPI = driver.find_elements_by_xpath(locators.seg_KPI_Tiles)
    print(len(tile_KPI))
    VPonwards=""
    for i in range(5,len(tile_KPI)+1):
        print(i)
        VPonwards = driver.find_element_by_xpath("("+locators.seg_KPI_Tiles+")"+"["+str(i)+"]")
        print(VPonwards.text)
        VPonwards.click()
        time.sleep(1)
        assert VPonwards.is_displayed(), "Modal should not open, but it may have"
    # Back to Summary View
    driver.find_element_by_xpath(locators.filter_icon).click()
    driver.find_element_by_xpath(locators.sp_view2).click()
    time.sleep(3)
    driver.find_element_by_xpath("(" + locators.sp_view_sum_clck + ")" + "[" + str(1) + "]").click()
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    time.sleep(2)

def kdtop_nav_GIMD():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle = driver.find_element_by_xpath(locators.MoveElementkd)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :" + str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-9):
        time.sleep(2)
        GH1[i].click()
        time.sleep(2)
        Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
        print(Topnav.text)
        listLegend1.append(Topnav.text)
        driver.find_element_by_xpath(locators.dropdown_wrapper).click()
    for i in listLegend1:
        listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    time.sleep(5)
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    assert listLegend2 == [['NQ'], ['Signings', 'Signings-ACV'],  ['All', 'Communications', 'Distribution', 'FSS: Insurance', 'FSS: NALASIA', 'FSS: US&E', 'Industrial', 'Public'], ['All', 'IA Direct', 'IA Delegated'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'Systems w/TPS', 'Cloud & Data Platform', 'Security', 'Cognitive Applications', 'Watson Health', 'Industry Platforms'], ['LIO'], ['CLIENT AGGREGATION', 'ALL LINE ITEMS']],"not expected"
    return listLegend2

def Mitop_nav_GIMD():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle = driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :" + str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-4):
        time.sleep(2)
        GH1[i].click()
        time.sleep(2)
        Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
        print(Topnav.text)
        listLegend1.append(Topnav.text)
        driver.find_element_by_xpath(locators.dropdown_wrapper).click()
    for i in listLegend1:
        listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    time.sleep(3)
    driver.find_element_by_xpath(locators.common_GlobalFilterXicon).click()
    assert listLegend2 == [['NQ'], ['Signings', 'Signings-ACV'],  ['All', 'Communications', 'Distribution', 'FSS: Insurance', 'FSS: NALASIA', 'FSS: US&E', 'Industrial', 'Public'], ['All', 'IA Direct', 'IA Delegated'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'Systems w/TPS', 'Cloud & Data Platform', 'Security', 'Cognitive Applications', 'Watson Health', 'Industry Platforms'], ['LIO'], ['ALL LINE ITEMS'], ['Identifying (1)', 'Validated (4)', 'Qualifying (7)', 'Gaining Agreement (6)']], "is not expected"
    return listLegend2


def test_close():
    driver.close()

# Login_Page.open_ISD()
# time.sleep(5)
# GIMD_Graph1()
# es_Radiobuttonswitch()
#
# view_switch_RB()
# time.sleep(5)
# #
# # graph2()
# GIMD_G1_Budget_PPV()
# G2_Budget_QTD_Actuals_GIMD()
# GIMD_DrillDown_UP_one_level()
# GIMD_DrillDown_UP_Top_level()
# EStop_nav_GIMD()
# # test_close()
# AP_Page.Aggregated()
# # APtop_nav_GIMD()
# time.sleep(5)
# SP_Page.Segmented_tab()
# loop_view_SP_GIMD()
# SPtop_nav_GIMD()
# RD_Page.Roadmap()
# RMtop_nav_GIMD()
# KD_Page.KD_tab_Click()
# kdtop_nav_GIMD()
# MI_Page.MI_tab_Click()
# Mitop_nav_GIMD()
# Topnav_Reset()
