from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
import re
from selenium.webdriver.common.action_chains import ActionChains
from datetime import date
from datetime import datetime
from datetime import timedelta
import locators
import Login_Page
import Common
import Constants
import pytest

driver = Login_Page.driver
action = ActionChains(driver)



def CX_tab():
    time.sleep(4)
    driver.find_element_by_xpath(locators.NPS_tab).click()

    time.sleep(2)

def Cx_clk():
    driver.find_element_by_xpath(locators.Nps_exe_clk).click()
    driver.implicitly_wait(20)

def Breadcrumb():
    print("############################ To check breadcrumb is based on geo/market #########################3")
    time.sleep(3)
    cx_br = driver.find_element_by_xpath(locators.breadcrumb)
    print(cx_br.text)
    time.sleep(3)
    if driver.find_element_by_xpath(locators.common_Profile_Name).text == 'Cx_Geo':
        assert cx_br.text == Constants.Cx_Breadcrumb_geo, "Not expected"
    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'Cx_Market':
        assert cx_br.text == Constants.Cx_Breadcrumb_market, "Not expected"
    # return cx_br
    else:
        print(cx_br.text)


def KPI_tiles_headers_relational():
    print("############################# To Check KPI Tiles is based on survey types ##################################3")
    filter_hover = driver.find_element_by_xpath("//*[@id='newfilterIcon-span']")
    action.move_to_element(filter_hover).perform()
    hover_txt = driver.find_element_by_xpath("//div[@class='filter-on-hover']")
    time.sleep(2)
    if "Survey Type" in hover_txt.text:
        Common.GlobFilterClick()
        driver.find_element_by_xpath("//*[@class='overlay-filters']//*[@name='icon--chevron--down']").click()
        driver.find_element_by_xpath("//*[@class='overlay-filters']//*[@name='icon--chevron--down']").click()
        global Sales_survey
        Sales_survey = driver.find_element_by_xpath(locators.Sales_survey)
        print(Sales_survey.text)
        Gf_cls = driver.find_element_by_xpath(locators.common_GlobalFilterXicon).click()
        time.sleep(2)

        filter_hover = driver.find_element_by_xpath("//*[@id='newfilterIcon-span']")
        action.move_to_element(filter_hover).perform()
        hover_txt= driver.find_element_by_xpath("//div[@class='filter-on-hover']")
        time.sleep(2)
        print(hover_txt.text)
        KPi_head= driver.find_elements_by_xpath("//*[@class='tile-label ng-star-inserted']")
        Kpi_label=[]
        for i in range(len(KPi_head)):
            Kpi_head_txt= KPi_head[i].text
            Kpi_head_txt1=Kpi_head_txt.split('\n')
            Kpi_label.append(Kpi_head_txt)

        print(Kpi_label)
        print(Kpi_label==Constants.Cx_KPI_Relat)
        if "IBM Relationship" in hover_txt.text or driver.find_element_by_xpath(locators.common_Profile_Name).text == 'Cx_Geo':
            assert Kpi_label==Constants.Cx_KPI_Relat

        elif  "IBM Relationship" in hover_txt.text or driver.find_element_by_xpath(locators.common_Profile_Name).text == 'Cx_Market':
            assert Kpi_label == Constants.Cx_KPI_Relat
    else:
        print("This is not related to IBM relationship profile")

def KPI_Deal_list_Promoter():
    DL_prom= driver.find_element_by_xpath("//*[text()='PROMOTERS ']//..//*[@class='value isCircle ng-star-inserted']")
    DL_prom.click()
    time.sleep(2)
    # assert DL_prom.click()==True,"Deal list is not clickable"
    Likely_recomm = driver.find_elements_by_xpath("//*[@class='datatable-body-cell textCenter sort-active ng-star-inserted']")
    for i in range(len(Likely_recomm)):
        lik_recom_txt=Likely_recomm[i].text
        print(lik_recom_txt)
        if float(lik_recom_txt)>10 or float(lik_recom_txt)<9:
            print("LTR for promoter is not as per the logic")
    KPI_table_headers()


def KPI_table_headers():
    test_title=driver.find_element_by_xpath("//h4[@class='text-center title ng-star-inserted']")
    print(test_title.text)
    Prom_head= driver.find_elements_by_xpath("//*[@class='datatable-header-cell-template-wrap']")
    prom_list=[]
    for i in range(len(Prom_head)):
        prom_head_txt= Prom_head[i].text
        time.sleep(1)
        prom_list.append(prom_head_txt)
    print(prom_list)
    time.sleep(2)
    Common.common_Close_dealList()
    time.sleep(2)
    if driver.find_element_by_xpath(locators.common_Profile_Name).text == 'Cx_Geo' and test_title.text=="IBM RELATIONSHIP NPS SUMMARY":
        assert prom_list==Constants.Cx_deal_headers_Global,"Headers not expected "+str(Constants.Cx_deal_headers_Global)+""
    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'Cx_Geo' and test_title.text=="SALES TRANSACTION NPS SUMMARY":
        assert prom_list == Constants.CX_deal_header_survey_Global, "Headers not expected " + str(Constants.CX_deal_header_survey_Global) + ""
    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'Cx_Bu_GBS' and test_title.text=="SALES TRANSACTION NPS SUMMARY":
        assert prom_list == Constants.Cx_deal_header_survery_uits, "Headers not expected " + str(Constants.CX_deal_header_survey_Global) + ""
    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'Cx_Bu_systps'and test_title.text=="SALES TRANSACTION NPS SUMMARY":
        assert prom_list == Constants.Cx_deal_header_survery_uits, "Headers not expected " + str(Constants.CX_deal_header_survey_Global) + ""




def KPI_Deal_list_Passives():
    DL_pass = driver.find_element_by_xpath("//*[text()='PASSIVES ']//..//*[@class='value isCircle ng-star-inserted']")
    DL_pass.click()
    # assert DL_prom.click()==True,"Deal list is not clickable"
    Likely_recomm = driver.find_elements_by_xpath("//*[@class='datatable-body-cell textCenter sort-active ng-star-inserted']")
    for i in range(len(Likely_recomm)):
        lik_recom_txt = Likely_recomm[i].text
        print(lik_recom_txt)
        if float(lik_recom_txt) > 8 or float(lik_recom_txt) < 7:
            print("LTR for PASSIVES  is not as per the logic")

    KPI_table_headers()



def KPI_Deal_list_DETRACTORS():
    DL_Det = driver.find_element_by_xpath("//*[text()='DETRACTORS ']//..//*[@class='value isCircle ng-star-inserted']")
    DL_Det.click()
    # assert DL_prom.click()==True,"Deal list is not clickable"
    Likely_recomm = driver.find_elements_by_xpath("//*[@class='datatable-body-cell textCenter sort-active ng-star-inserted']")
    for i in range(len(Likely_recomm)):
        lik_recom_txt = Likely_recomm[i].text
        print(lik_recom_txt)
        if float(lik_recom_txt) > 6 or float(lik_recom_txt) < 0:
            print("LTR for DETRACTORS is not as per the logic")
    KPI_table_headers()

def GF_validation():
    test_title = driver.find_element_by_xpath("//h4[@class='text-center title ng-star-inserted']")
    print(test_title.text)
    time.sleep(2)
    Common.GlobFilterClick()
    driver.find_element_by_xpath("//*[@class='overlay-filters']//*[@name='icon--chevron--down']").click()
    driver.find_element_by_xpath("//*[@class='overlay-filters']//*[@name='icon--chevron--down']").click()
    time.sleep(2)
    Gf_pagespcf = driver.find_elements_by_xpath("//*[@class='labels ng-star-inserted']")
    list=[]
    for i in range(len(Gf_pagespcf)):
        Gf_pagespcf_txt = Gf_pagespcf[i].text
        Gf_pagespcf_txt2=Gf_pagespcf_txt.split('\n')
        list.append(Gf_pagespcf_txt)
        time.sleep(2)

    print(list)
    driver.find_element_by_xpath(locators.common_GlobalFilterXicon).click()

    if driver.find_element_by_xpath(locators.common_Profile_Name).text == 'Cx_Geo' and test_title.text=="IBM RELATIONSHIP NPS SUMMARY":
        assert list==Constants.Cx_Gf_Rel,"GD's not expected "+str(Constants.Cx_Gf_Rel)+""
    elif  driver.find_element_by_xpath(locators.common_Profile_Name).text == 'Cx_Bu_GBS' and test_title.text=="SALES TRANSACTION NPS SUMMARY":
        assert list==Constants.CX_Gf_Sales,"GD's not expected "+str(Constants.CX_Gf_Sales)+""
    elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'Cx_Bu_systps' and test_title.text == "SALES TRANSACTION NPS SUMMARY":
        assert list == Constants.CX_Gf_Sales, "Headers not expected " + str(Constants.CX_Gf_Sales) + ""

    return list

def Expand_collapse():
    Expandgraph = driver.find_elements_by_xpath(locators.Expand_graph_icon)
    for i in range(len(Expandgraph)):
        maximize = driver.find_element_by_xpath("(" + "(//*[@name='icon--maximize'])" + ")" + "[" + str(i + 1) + "]")
        maximize.click()
        # assert maximize.click()!=True , "Expand Graph is not working as expeted unable to click"
        time.sleep(5)
        action = ActionChains(driver)

        Show_table = driver.find_element_by_xpath(locators.Show_table_clk)
        action.move_to_element(Show_table).perform()
        time.sleep(2)
        Show_table.click()
        val = driver.find_element_by_xpath(locators.firstrow).text
        assert type(val) == str, "No Values"
        time.sleep(5)
        assert Show_table.click() != True, "Data table is not clickable and Result is failed"
        Hide_Table = driver.find_element_by_xpath(locators.Show_table_clk)
        time.sleep(5)
        minimize = driver.find_element_by_xpath(locators.min1)
        minimize = minimize.click()
        # assert minimize!=True, "Graph is not able to minimize and the result is failed"
        time.sleep(3)

def Graph1_validation():
    DD_icon= driver.find_element_by_xpath("//*[@class='graphIcon']")
    # assert DD_icon!=True,"DD icon is mising"
    Horizntal_bar = driver.find_element_by_xpath("(//*[@id='nps-cx-main-heading'])[1]//..//*[@class='horizontalBars dotted-bar']")

    if Horizntal_bar.is_displayed():
        bar_dotted= driver.find_element_by_xpath("//*[@class='horizontalBars dotted-bar']//..//*[@class='x axis showForBar']//..//*[@class='horizontalBars showForBar']//..//*[@class='bars']")
        action.move_to_element(bar_dotted).perform()
        time.sleep(2)
        bar_hover = driver.find_element_by_xpath("//div[@class='toolTip']")
        # action.move_to_element(bar_hover).perform()
        # time.sleep(2)
        print(bar_hover.text)
        split=bar_hover.text.split('\n')
        print(split)
        split_comp=split[2]
        print(split_comp)
        split_promoters=split[3]
        split_promoters=re.sub('Promoters: ',  '',    split_promoters)
        split_promoters=split_promoters.replace(" ", "")
        split_promoters=re.findall(r'[0-9]+[.]?[0-9]+', split_promoters)
        split_promoters=round(float(split_promoters[0]))
        print(split_promoters)
        split_passives = split[4]
        split_passives = re.sub('Passives: ', '', split_passives)
        split_passives= split_passives.replace(" ", "")
        # split_passives=round(split_passives)
        print(split_passives)
        split_Detractors = split[4]
        split_Detractors = re.sub('Passives: ', '', split_Detractors)
        split_Detractors=split_Detractors.replace(" ", "")
        split_Detractors=round(float(split_Detractors))
        print(split_Detractors)
        Array_visuals = [split_comp,split_promoters,split_passives,split_Detractors]
        print(Array_visuals)

        KPI_Nps_compar = driver.find_element_by_xpath("//*[text()='NPS ']//..//*[@class='comparison ng-star-inserted']")
        print(KPI_Nps_compar.text)
        KPI_Prom=driver.find_element_by_xpath("//*[text()='PROMOTERS ']//..//*[@class='value isCircle ng-star-inserted']")
        print(KPI_Prom.text)
        KPI_pass=driver.find_element_by_xpath("//*[text()='PASSIVES ']//..//*[@class='value isCircle ng-star-inserted']")
        KPI_Detr=driver.find_element_by_xpath("//*[text()='DETRACTORS ']//..//*[@class='value isCircle ng-star-inserted']")
        Array_KPI= [KPI_Nps_compar.text,KPI_Prom.text,KPI_pass.text,KPI_Detr.text]
        print(Array_KPI)

        assert str(Array_visuals)==str(Array_KPI), "not in sync with visuals vs KPI(dotted)"







def KPI_headers_survery():
    filter_hover = driver.find_element_by_xpath("//*[@id='newfilterIcon-span']")
    action.move_to_element(filter_hover).perform()
    hover_txt = driver.find_element_by_xpath("//div[@class='filter-on-hover']")
    time.sleep(2)
    global KPi_head
    global Kpi_label
    if "Survey Type" in hover_txt.text:
        Common.GlobFilterClick()
        driver.find_element_by_xpath("//*[@class='overlay-filters']//*[@name='icon--chevron--down']").click()
        driver.find_element_by_xpath("//*[@class='overlay-filters']//*[@name='icon--chevron--down']").click()
        time.sleep(2)
        driver.find_element_by_xpath("//*[@id='bread_Survey Type']").click()
        driver.find_element_by_xpath(locators.Survey_drp).click()
        Sales_survey = driver.find_element_by_xpath(locators.Sales_survey)
        print(Sales_survey.text)
        Gf_cls = driver.find_element_by_xpath(locators.common_GlobalFilterXicon).click()
        time.sleep(2)
        filter_hover = driver.find_element_by_xpath("//*[@id='newfilterIcon-span']")
        action.move_to_element(filter_hover).perform()
        hover_txt = driver.find_element_by_xpath("//div[@class='filter-on-hover']")
        time.sleep(2)
        print(hover_txt.text)
        KPi_head = driver.find_elements_by_xpath("//*[@class='tile-label ng-star-inserted']")
        Kpi_label = []
        for i in range(len(KPi_head)):
            Kpi_head_txt = KPi_head[i].text
            Kpi_head_txt1 = Kpi_head_txt.split('\n')
            Kpi_label.append(Kpi_head_txt)

        print(Kpi_label)
        print(Kpi_label == Constants.Cx_KPI_Sales)
        if "Sales Transaction" in hover_txt.text or driver.find_element_by_xpath(locators.common_Profile_Name).text == 'Cx_Geo':
            assert Kpi_label == Constants.Cx_KPI_Sales

    else:
        KPi_head = driver.find_elements_by_xpath("//*[@class='tile-label ng-star-inserted']")
        title_sur=driver.find_element_by_xpath("//*[@class='text-center title ng-star-inserted']")
        print(title_sur.text)
        Kpi_label=[]
        if "SALES TRANSACTION" in title_sur.text:
            for j in range(len(KPi_head)):
                Kpi_head_txt = KPi_head[j].text
                Kpi_head_txt1 = Kpi_head_txt.split('\n')
                Kpi_label.append(Kpi_head_txt)

            print(Kpi_label)
            print(Kpi_label == Constants.Cx_KPI_Sales)
            if driver.find_element_by_xpath(locators.common_Profile_Name).text == 'Cx_Geo':
                assert Kpi_label == Constants.Cx_KPI_Sales
            elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'Cx_Market':
                assert Kpi_label == Constants.Cx_KPI_Sales
            elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'Cx_Bu_GBS':
                assert Kpi_label == Constants.Cx_KPI_Sales
            elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'Cx_Bu_systps':
                assert Kpi_label == Constants.Cx_KPI_Sales
            elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'Cx_Bu_GTS-IS':
                assert Kpi_label == Constants.Cx_KPI_Sales
            elif driver.find_element_by_xpath(locators.common_Profile_Name).text == 'Cx_Bu_GTS-TSS':
                assert Kpi_label == Constants.Cx_KPI_Sales


def kpi_deal_survey_prom():
    KPI_Deal_list_Promoter()

def Kpi_deal_survey_pass():
    KPI_Deal_list_Passives()

def Kpi_deal_survey_Det():
    KPI_Deal_list_DETRACTORS()
# KPI_tiles_headers_Sales()


#
# Login_Page.open_ISD()
# CX_tab()
# Cx_clk()
# GF_validation()