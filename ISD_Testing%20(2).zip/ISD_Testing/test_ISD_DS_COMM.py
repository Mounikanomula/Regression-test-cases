import DS_COMM
'''
Profile Details
User Role : Global Mkt - Digital Business
Role : Commercial & CSP Mission
Client Set : Commercial
Client Sub Type : 
Geo : All
Market : All
BU Level 10 : All
Manager's Node : Not Applicable
'''
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
import re
import Login_Page
import ES_Page
import RD_Page
import AP_Page
import SP_Page
import KD_Page
import MI_Page
import Common
import Constants
import pytest
import locators
from selenium.webdriver.common.action_chains import ActionChains
# pytest ***.py
# pytest -v
#Allure reporting
    #python -m pytest ***.py --alluredir=C:\FilesFolders\Practice\PycharmProjects\2019\Skyline\ISD_Testing\Reports
    # goto the Reports folder from command line
    # in command line : allure generate C:\FilesFolders\Practice\PycharmProjects\2019\Skyline\ISD_Testing\Reports
    # open in Mozilla takes some time

driver = Login_Page.driver
def test_open():
    Login_Page.open_ISD()

### Executive Summary ####
def test_ESopen():
    # Check in Page
    time.sleep(3)
    es_op = ES_Page.es_breadcrumb()
    assert es_op.text=="Executive Summary / DEFAULT VIEW /","Not in Executive Summary Tab"

def test_ISDLOGO():
    ES_Page.ISDLOGO()

def test_NEEDHELP():
    ES_Page.NEEDHELP()

def test_PRIVACY():
    ES_Page.PRIVACY()

def test_ABOUTISD():
    ES_Page.ABOUTISD()

def test_PROFILEINFO():
    ES_Page.PROFILEINFO()

def test_LEXPANDICON_open():
    ES_Page.LEXPANDICON()

def test_LEXPANDICON_Close():
    ES_Page.LEXPANDICON_close()


def test_ESKPI():
    global es_KPI
    es_KPI=ES_Page.ES_KPI()
    assert ((es_KPI[0] != "Budget locator not found") & (es_KPI[1] != "QTD Actuals locator not found") & (es_KPI[2] != "WSR locator not found") & (es_KPI[3] != "PPA locator not found") & (es_KPI[4] != "Cov locator not found") & (es_KPI[5] != "VP locator not found") & (es_KPI[6] != "QP locator not found")& (es_KPI[7] != "WON locator not found")), "ES KPI Failed"

## def test_ES_G1_Bud_PPV_Geo():
##     G1=ES_Page.Graph1()
##     ES_Page.es_budget(G1)
##     ES_Page.es_ppv(G1)
##     ES_Page.geo_check(G1)

def test_ES_expand_showhide_colapase():
    # Expand graph show table get first row the hide table then close expand
    Common.expand_showhide_colapase()

def test_ES_Graphs():
    # Checks all graphs are coming or not
    graph=Common.Graphs1()
    assert graph==['GEO COV% PPA (Adj.)', 'BUDGET Vs QTD ACTUALS (Trans.)', 'GEO COV% (WSR)', 'MONTHLY BUILD - WSR & QTD ACTUALS (Trans.)'],"ES Graphs Missing"

def test_G1_Budget_PPV():
    ES_Page.G1_Budget_PPV()

def test_G2_Budget_QTD_Actuals():
    ES_Page.G2_Budget_QTD_Actuals()

def test_G3_Budget_WSR_WON():
    ES_Page.G3_Budget_WSR_WON()

def test_G4_Budget_WSR():
    ES_Page.G4_Budget_WSR()

## def test_G1_G2_G3_G4_Budget():
##     #Sum of bars vs KPI
##     es_KPI = ES_Page.ES_KPI()
##     Bud=ES_Page.G1_G2_Budget_PPV()
##     Bud2 = ES_Page.G3_G4_Budget_WSR_WON()
##     assert ((es_KPI[0]==Bud[0][0])&(es_KPI[0]==Bud[0][1])&(es_KPI[0]==Bud2[0][0])&(es_KPI[0]==Bud2[0][1])),"Budget Mismatch in graphs"
#
## def test_G1_G2_PPV():
##     # Sum of bars vs KPI
##     es_KPI = ES_Page.ES_KPI()
##     PPV=ES_Page.G1_G2_Budget_PPV()
##     assert ((es_KPI[1]==PPV[1][0])&(es_KPI[1]==PPV[1][1])),"PPV mismatch in graphs"
#
## def test_G3_G4_WSR():
##     # Sum of bars vs KPI
##     WSR = ES_Page.G3_G4_Budget_WSR_WON()
##     assert ((WSR[1][0]==WSR[1][1])),"WSR mismatch in graphs"
#
## def test_G3_G4_WON():
##     # Sum of bars vs KPI
##     WON = ES_Page.G3_G4_Budget_WSR_WON()
##     assert ((WON[2][0]==WON[2][1])),"WON mismatch in graphs"

def test_DrillDown_UP():
    DS_COMM.DrillDown_UP_Top_level()
    # time.sleep(2)
    # es_op = ES_Page.es_breadcrumb()
    # assert es_op.text=="Executive Summary / DEFAULT VIEW /","Drill Down Drill up one level Unsuccessful"

def test_DrillDown_UP_Top_level():
    DS_COMM.DrillDown_UP_Top_level()
    # time.sleep(2)
    # es_op = ES_Page.es_breadcrumb()
    # assert es_op.text=="Executive Summary / DEFAULT VIEW /","Drill Down Drill up to TOP level Unsuccessful"

def test_ESTopna():
    # Check in Page
    listLegend=DS_COMM.EStop_nav()
    # assert listLegend == [['NQ'], ['Signings', 'Signings-ACV'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'Systems Hardware', 'Systems Software', 'C&DP', 'Security', 'Acoustic', 'WCE Mkt&Comm Legacy', 'Watson Health', 'Cognitive Apps', 'Watson Education', 'Indus Platforms Unit']],  "Not expected"

def test_MESChecking():
    MESTEXT=ES_Page.MESChecking()
    assert MESTEXT==('Executive Summary > Modify Executive Summary'), "Text is not matching"

def test_esdate1():
    ES_Page.ESGraphDate1()

def test_esdate2():
    ES_Page.ESGraphDate2()

def test_esdate3():
    ES_Page.ESGraphDate3()

def test_esdate4():
    ES_Page.ESGraphDate4()

def test_VP_KPI_DF_Grp():
    ES_Page.VP_KPI_DF_Grp()

def test_VP_KPI_vs_Summary_DealList():
    ES_Page.VP_KPI_vs_Summary_DealList()

def test_VP_KPI_Summary_DealList_vs_Sum_Detailed_List():
    ES_Page.VP_KPI_Summary_DealList_vs_Sum_Detailed_List()

def test_WSR_KPI_DF_Grp():
    ES_Page.WSR_KPI_DF_Grp()

def test_WSR_KPI_vs_Summary_DealList():
    ES_Page.WSR_KPI_vs_Summary_DealList()

def test_WSR_KPI_Summary_DealList_vs_Sum_Detailed_List():
    ES_Page.WSR_KPI_Summary_DealList_vs_Sum_Detailed_List()

def test_WON_KPI_DF_Grp():
    ES_Page.WON_KPI_DF_Grp()

def test_WON_KPI_vs_Summary_DealList():
    ES_Page.WON_KPI_vs_Summary_DealList()

def test_WON_KPI_Summary_DealList_vs_Sum_Detailed_List():
    ES_Page.WON_KPI_Summary_DealList_vs_Sum_Detailed_List()


## Aggergated Pipeline ####

def test_Aggregated():
    # Check in Page
    ap_op=AP_Page.Aggregated()
    assert ap_op.text == "Aggregated Pipeline / GEO VIEW /", "Not in Aggregated Pipeline Tab"

def test_APKPI():
    global ap_KPI
    ap_KPI=AP_Page.AP_KPI()
    assert ((ap_KPI[0] != "Budget locator not found") & (ap_KPI[1] != "PPV locator not found") & (ap_KPI[2] != "Cov locator not found") & (ap_KPI[3] != "Bw_Obj locator not found") & (ap_KPI[4] != "VP locator not found") & (ap_KPI[5] != "QP locator not found") & (ap_KPI[6] != "WON locator not found")), "AP KPI Failed"


def test_AP_expand_showhide_colapase():
    # Expand graph show table get first row the hide table then close expand
    Common.expand_showhide_colapase()

def test_AP_Graphs():
    # Checks all graphs are coming or not
    graph=AP_Page.AP_Graphs()
    assert graph == ['GEO COV% PPA (Adj.)', 'SALES ACTION QUADRANTS', 'PIPELINE QUALITY', 'VP TRACK'],"AP Graphs Missing"

def test_AP_TopNav_DefView():
    Common.GlobFilterClick()
    Common.common_TopNav_DefView()
    Common.GlobFilterXiconClick()

def test_AP_GraphOne_xAxis():
    actual_Geo_List = AP_Page.aggPipe_GraphOne_xAxis()
    print("Actual:", actual_Geo_List)
    print("Expected:", Constants.geo_List2)
    assert actual_Geo_List == Constants.geo_List2, "Geo List Not as Expected"

def test_AP_GraphThree_xAxis_Geo():
    actual_Geo_List = AP_Page.aggPipe_GraphThree_xAxis()
    print("Actual:", actual_Geo_List)
    print("Expected:", Constants.geo_List2)
    assert actual_Geo_List == Constants.geo_List2, "Geo Not as Expected"

# TopNav Unit View
def test_AP_TopNav_AltView():
    Common.GlobFilterClick()
    Common.common_TopNav_AltView()
    Common.GlobFilterXiconClick()

def test_AP_GraphOne_Title_Unit():
    GrOnetxt = DS_COMM.aggPipe_GraphOne_Title_BU()
    print(GrOnetxt.text)
    budgetVerify = driver.find_element_by_xpath(locators.common_KPI_Budget_Val).text
    print(budgetVerify)
    if budgetVerify !='N/A':
        assert GrOnetxt.text == "BUSINESS UNIT GROUP COV% (PPA)", "Title did not Match"
    elif budgetVerify == 'N/A':
        assert GrOnetxt.text == "BUSINESS UNIT GROUP PPA", "Title did not Match"

def test_AP_GraphOne_xAxis_Unit():
    actual_BU_List = AP_Page.aggPipe_GraphOne_xAxis()
    print("Actual:", actual_BU_List)
    print("Expected:", Constants.bU_List)
 #   assert actual_BU_List == locators.bU_List, "BU List Not as Expected"  --- Inactivated due to varying BUs

def test_AP_GraphThree_xAxis_Unit():
     actual_BU_List = AP_Page.aggPipe_GraphThree_xAxis()
     print("Actual:", actual_BU_List)
     print("Expected:", Constants.bU_List)
#     assert actual_BU_List == locators.bU_List --- --- Inactivated due to varying BUs

def test_GlobalFilterRestoreDefaults():
    Common.GlobFilterRestoreDefaults()
    Common.GlobFilterXiconClick()

def test_AP_PPQ_Bars():
    BarList = AP_Page.aggPipe_Bars_Tooltip()
    print(BarList)

def test_AP_PPQ_Chart_Inlines():
    AP_Page.aggPipe_PPQ_Inline_Clicks()

def test_AP_Track_ChartTitles():
    AP_Page.aggPipe_Track_Chart_Title_Legend()

def test_VPTrack_Chart_Inlines():
    AP_Page.aggPipe_VPTrack_Inline_Clicks()

def test_AP_PPA():
    AP_Page.aggPipe_PPA()

def test_aptopnav():
    listLegend=DS_COMM.APtop_nav()
    # assert listLegend == [['NQ'], ['Signings', 'Signings-ACV'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'Systems Hardware', 'Systems Software', 'C&DP', 'Security', 'Acoustic', 'WCE Mkt&Comm Legacy', 'Watson Health', 'Cognitive Apps', 'Watson Education', 'Indus Platforms Unit'],['UNIT']],"Not expected"

def test_apdate1():
    AP_Page.APGraphDate1()

def test_apdate2():
    AP_Page.APGraphDate2()

def test_apdate3():
    AP_Page.APGraphDate3()

def test_apdate4():
    AP_Page.APGraphDate4()

def test_AP_VP_KPI_DF_Grp():
    AP_Page.AP_VP_KPI_DF_Grp()

def test_AP_VP_KPI_vs_Summary_DealList():
    AP_Page.AP_VP_KPI_vs_Summary_DealList()

def test_AP_VP_KPI_Summary_DealList_vs_Sum_Detailed_List():
    AP_Page.AP_VP_KPI_Summary_DealList_vs_Sum_Detailed_List()

def test_AP_QP_KPI_DF_Grp():
    AP_Page.AP_QP_KPI_DF_Grp()

def test_AP_QP_KPI_vs_Summary_DealList():
    AP_Page.AP_QP_KPI_vs_Summary_DealList()

def test_AP_QP_KPI_Summary_DealList_vs_Sum_Detailed_List():
    AP_Page.AP_QP_KPI_Summary_DealList_vs_Sum_Detailed_List()

def test_AP_WON_KPI_DF_Grp():
    AP_Page.AP_WON_KPI_DF_Grp()

def test_AP_WON_KPI_vs_Summary_DealList():
    AP_Page.AP_WON_KPI_vs_Summary_DealList()

def test_AP_WON_KPI_Summary_DealList_vs_Sum_Detailed_List():
    AP_Page.AP_WON_KPI_Summary_DealList_vs_Sum_Detailed_List()

def test_SAQ_Probe():
    AP_Page.SAQ_Probe()

def test_SAQ_Probe_vs_Summary_DealList():
    AP_Page.SAQ_Probe_vs_Summary_DealList()

def test_SAQ_Probe_Summary_DealList_vs_Sum_Detailed_List():
    AP_Page.SAQ_Probe_Summary_DealList_vs_Sum_Detailed_List()

def test_SAQ_Close():
    AP_Page.SAQ_Close()

def test_SAQ_Close_vs_Summary_DealList():
    AP_Page.SAQ_Close_vs_Summary_DealList()

def test_SAQ_Close_Summary_DealList_vs_Sum_Detailed_List():
    AP_Page.SAQ_Close_Summary_DealList_vs_Sum_Detailed_List()
#
def test_SAQ_Refine():
    AP_Page.SAQ_Refine()

def test_SAQ_Refine_vs_Summary_DealList():
    AP_Page.SAQ_Refine_vs_Summary_DealList()

def test_SAQ_Refine_Summary_DealList_vs_Sum_Detailed_List():
    AP_Page.SAQ_Refine_Summary_DealList_vs_Sum_Detailed_List()

def test_SAQ_Advance():
    AP_Page.SAQ_Advance()

def test_SAQ_Advance_vs_Summary_DealList():
    AP_Page.SAQ_Advance_vs_Summary_DealList()

def test_SAQ_Advance_Summary_DealList_vs_Sum_Detailed_List():
    AP_Page.SAQ_Advance_Summary_DealList_vs_Sum_Detailed_List()


### Segmented Pipeline ####

def test_Segmented():
    # Check in Page
    SP_Page.Segmented_tab()
    sp_op=SP_Page.Segmented_bc()
    assert sp_op.text == "Segmented Pipeline / SUMMARY VIEW /", "Not in Segmented Pipeline Tab"

def test_SPKPI():
    global sp_KPI
    sp_KPI=SP_Page.SP_KPI()
    assert ((sp_KPI[0] != "Budget locator not found") & (sp_KPI[1] != "PPA locator not found") & (sp_KPI[2] != "Cov locator not found") & (sp_KPI[3] != "Bw_Obj locator not found") & (sp_KPI[4] != "VP locator not found") & (sp_KPI[5] != "QP locator not found") & (sp_KPI[6] != "WON locator not found")), "SP KPI Failed"


# def test_SP_Def_KPI():
#     global KPI_Val_Def
#     KPI_Val_Def = SP_Page.segPipe_KPI_ValFetch()
#     print(KPI_Val_Def)


# def test_SP_View_StratImp():
#     Common.GlobFilterClick()
#     SP_Page.segPipe_View_StratImp()
#     SP_Page.segPipe_RevType()
#     Common.GlobFilterXiconClick()
#     bread = SP_Page.segPipe_breadcrumb()
#     assert bread == "Segmented Pipeline / SOLUTIONS - STRATEGIC IMPERATIVES VIEW /"
#
# def test_SP_Chart_Titles_StratImp():
#     # ---- to verify if VP Penetration % chart is present in place of Sales Stage chart -----------
#     actualtiles = SP_Page.segPipe_All_Chart_Titles_StratImp()
#     print(actualtiles)
#     assert actualtiles == Constants.SP_SI_ChartTitles or actualtiles == Constants.SP_SI_ChartTitlesPPV, "One or more of the titles does not match the expected"
#
# def test_SP_KPI_Labels_StratImp():
#     # ------ to verify if all Strategic Imperatives-related KPI are present -----------
#     actualKPIlabels = SP_Page.segPipe_KPI_Labels()
#     print(actualKPIlabels)
#     assert actualKPIlabels == Constants.SP_SI_KPI_Labels, "One or more of the labels does not match the expected"
#
# def test_SP_KPI_Tiles_StratImp():
#     # ---- to verify that none of the KPI tiles are clickable (VP, VP Penentration %, Won) -----------
#     SP_Page.segPipe_KPI_Tiles_VP_Onwards_StratImp()
#
# def test_SP_View_IndSol():
#     Common.GlobFilterClick()
#     SP_Page.segPipe_View_IndSol()
#     SP_Page.segPipe_RevType()
#     Common.GlobFilterXiconClick()
#     bread = SP_Page.segPipe_breadcrumb()
#     assert bread == "Segmented Pipeline / INDUSTRY SOLUTIONS VIEW /"
#
# def test_SP_KPI_Labels_IndSol():
#     # ------ to verify if all Industry Solutions-related KPI are present -----------
#     actualKPIlabels = SP_Page.segPipe_KPI_Labels()
#     print(actualKPIlabels)
#     assert actualKPIlabels == Constants.SP_IndSol_KPI_Labels, "One or more of the labels does not match the expected"
#
#
# def test_SP_KPI_Tiles_IndSol():
#     # -------- to fetch IndSol KPI and verify if the values are different from that of Summary KPI --------------
# #    SP_Page.segPipe_View_IndSol()
# #    SP_Page.segPipe_RevType()
#     test_SP_KPI_Labels_IndSol()
#     KPI_Val_Indsol = SP_Page.segPipe_KPI_ValFetch()
#     print(KPI_Val_Indsol)
#     # assert KPI_Val_Def != KPI_Val_Indsol, "There is no change in value in KPI Default View vs KPI Industry Client View. Please analyze further manually."

def test_SP_View_Buyer():
    Common.GlobFilterClick()
    DS_COMM.segPipe_View_Buyer()
    #SP_Page.segPipe_RevType()  #No All Rev Type for Digital Salges
    Common.GlobFilterXiconClick()
    bread = SP_Page.segPipe_breadcrumb()
    assert bread == "Segmented Pipeline / BUYER GROUP VIEW /"

def test_SP_Chart_Titles_Buyer():
    # ---- to verify if VP Penetration % chart is present in place of Sales Stage chart -----------
    actualtiles = SP_Page.segPipe_All_Chart_Titles_StratImp()
    print(actualtiles)
    assert actualtiles == Constants.SP_SI_ChartTitles_Buyer or actualtiles == Constants.SP_SI_ChartTitlesPPV, "One or more of the titles does not match the expected"

def test_SP_KPI_Labels_Buyer():
    # ------ to verify if all Strategic Imperatives-related KPI are present -----------
    actualKPIlabels = SP_Page.segPipe_KPI_Labels()
    print(actualKPIlabels)
    assert actualKPIlabels == Constants.SP_SI_KPI_Labels_Buyer, "One or more of the labels does not match the expected"

def test_SP_KPI_Tiles_Buyer():
    # ---- to verify that none of the KPI tiles are clickable (VP, VP Penentration %, Won) -----------
    SP_Page.segPipe_KPI_Tiles_VP_Onwards_StratImp()

def test_SP_expand_showhide_colapase():
    # Expand graph show table get first row the hide table then close expand
    Common.sp_expand_showhide_colapase()

def test_SP_Graphs():
    # Checks all graphs are coming or not
    Common.GlobFilterRestoreDefaults()
    Common.GlobFilterXiconClick()
    graph = Common.Graphs1()
    assert graph == ['DEAL SIZE PPA (Adj.) vs Prior Week PPA (Adj.)', 'CHANNEL PPA (Adj.) vs Prior Week PPA (Adj.)', 'BUYER GROUP PPA (Adj.) vs Prior Week PPA (Adj.)', 'OI GROUP PPA (Adj.) vs Prior Week PPA (Adj.)'], "SP Graph Missing"

def test_SP_loop_view():
    DS_COMM.buyer_loop()
    time.sleep(2)
    Common.GlobFilterRestoreDefaults()
    Common.GlobFilterXiconClick()
    # view=SP_Page.loop_view()
    # assert ((view[0]!="Budget or PPV not matching for Graph1")&(view[1]!="VP Graph2 or QP Graph3 not matching")&(view[2]!="VP not matching for Graph4")),"One of the View in SP failed"

def test_SP_loop_Buyer_view_VP():
    DS_COMM.buyer_loop_VP()
    time.sleep(2)

def test_SP_loop_Buyer_view_QP():
    DS_COMM.buyer_loop_QP()
    time.sleep(2)

def test_sptopnav():
    Common.GlobFilterRestoreDefaults()
    Common.GlobFilterXiconClick()
    listLegend=DS_COMM.SPtop_nav()
    # assert listLegend == [['NQ'], ['Signings', 'Signings-ACV'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'Systems Hardware', 'Systems Software', 'GBS', 'GTS', 'C&DP', 'Security', 'Acoustic', 'WCE Mkt&Comm Legacy', 'Watson Health', 'Cognitive Apps', 'Watson Education', 'Indus Platforms Unit'], ['CLIENT SET', 'DEAL SIZE', 'CHANNEL', 'SOLUTIONS - Strategic Imperatives', 'INDUSTRY SOLUTIONS']], "Not expected"

def test_spdate1():
    SP_Page.SPGraphDate1()

def test_spdate2():
    SP_Page.SPGraphDate2()

def test_spdate3():
    SP_Page.SPGraphDate3()

# def test_spdate4():
#     SP_Page.SPGraphDate4()

def test_SP_VP_KPI_DF_Grp():
    SP_Page.SP_VP_KPI_DF_Grp()

def test_SP_VP_KPI_vs_Summary_DealList():
    SP_Page.SP_VP_KPI_vs_Summary_DealList()

def test_SP_VP_KPI_Summary_DealList_vs_Sum_Detailed_List():
    SP_Page.SP_VP_KPI_Summary_DealList_vs_Sum_Detailed_List()

def test_SP_QP_KPI_DF_Grp():
    SP_Page.SP_QP_KPI_DF_Grp()

def test_SP_QP_KPI_vs_Summary_DealList():
    SP_Page.SP_QP_KPI_vs_Summary_DealList()

def test_SP_QP_KPI_Summary_DealList_vs_Sum_Detailed_List():
    SP_Page.SP_QP_KPI_Summary_DealList_vs_Sum_Detailed_List()

def test_SP_WON_KPI_DF_Grp():
    SP_Page.SP_WON_KPI_DF_Grp()

def test_SP_WON_KPI_vs_Summary_DealList():
    SP_Page.SP_WON_KPI_vs_Summary_DealList()

def test_SP_WON_KPI_Summary_DealList_vs_Sum_Detailed_List():
    SP_Page.SP_WON_KPI_Summary_DealList_vs_Sum_Detailed_List()


### Roadmap ####
def test_Roadmap():
    # Check in Page
    rd_op=RD_Page.Roadmap()
    assert rd_op.text == "Roadmap / GEO VIEW /", "Not in Roadmap Tab"

def test_RDKPI():
    global rd_KPI
    rd_KPI=RD_Page.RD_KPI()
    assert ((rd_KPI[0] != "Budget locator not found") & (rd_KPI[2] != "RD WSR locator not found") & (rd_KPI[1] != "Cov locator not found") & (rd_KPI[3] != "RD DTB locator not found") & (rd_KPI[4] != "RD WON locator not found") & (rd_KPI[5] != "RD STR locator not found") & (rd_KPI[6] != "RD WKS locator not found") & (rd_KPI[7] != "RD WKS Strech locator not found")), "Roadmap KPI Failed"


def test_RD_expand_showhide_colapase():
    # Expand graph show table get first row the hide table then close expand
    Common.expand_showhide_colapase()

def test_Roadmap_Graphs():
    # Checks all graphs are coming or not
    graph=RD_Page.RD_Graphs()
    assert graph==['ROADMAP TO BUDGET', 'GEO COV% (WSR)', 'WSR TRACK', 'WEEKLY BUILD - WSR'],"Roadmap Graph Missing"

def test_RM_Track_Title_Legend():
    RD_Page.rM_Track_Chart_Title_Legend()

def test_RM_Track():
    RD_Page.rM_VPTrack_Inline_Clicks()

def test_RMTopnav():
    listLegend=DS_COMM.RMtop_nav()
    # assert listLegend == [['NQ'], ['Signings', 'Signings-ACV'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'Systems Hardware', 'Systems Software', 'C&DP', 'Security', 'Acoustic', 'WCE Supply Chain', 'WCE Mkt&Comm Legacy', 'Collaboration Solns', 'Talent Solns', 'Watson Health', 'Watson IoT', 'Watson Education', 'Wtsn Media & Weather', 'Indus Platforms Unit'], ['LIO'], ['BU', 'CLIENT SEGMENT']], "not expected"
    time.sleep(2)

def test_RMbudgetcomparison():
    RD_Page.RMBudgetcomparison()
    time.sleep(2)

def test_Wkly_Build_WSR_KPI():
    RD_Page.Wkly_Build_WSR_KPI()
    time.sleep(2)

def test_Wkly_Build_Inline_Clicks():
    RD_Page.Wkly_Build_Inline_Clicks()
    time.sleep(2)

def test_RMAllviews():
    RD_Page.RoadmapAllView()
    time.sleep(2)

# def test_RM_TrendLegends1():
#     listLegends=RD_Page.RM_TrendLegends1()
#     # assert listLegends == ['Act/WON', 'SOLID', 'AT RISK'], "Not as expected"
#
# def test_RM_TrendLegends2() :
#     listLegend=RD_Page.RM_TrendLegends2()
#     # assert listLegend == ['Act/WON', 'SOLID', 'AT RISK', 'KEY STRETCH'], "Not as expected"
#
# def test_RM_TrendLegends3():
#     listLegend1=RD_Page.RM_TrendLegends3()
#     # assert listLegend1 == ['Act/WON', 'SOLID', 'AT RISK', 'KEY STRETCH', 'STRETCH'], "Not as expected"
#     time.sleep(2)

def test_RMdate1():
    RD_Page.RMDateGraph1()
    time.sleep(2)

def test_RMdate2():
    RD_Page.RMDateGraph2()
    time.sleep(2)

def test_RMdate3():
    RD_Page.RMDateGraph3()
    time.sleep(2)

def test_RMdate4():
    RD_Page.RMDateGraph4()
    time.sleep(2)



def test_RD_WON_KPI_DF_Grp():
    RD_Page.RD_WON_KPI_DF_Grp()

def test_RD_WON_KPI_vs_Summary_DealList():
    RD_Page.RD_WON_KPI_vs_Summary_DealList()

def test_RD_WON_KPI_Summary_DealList_vs_Sum_Detailed_List():
    RD_Page.RD_WON_KPI_Summary_DealList_vs_Sum_Detailed_List()

def test_RD_STR_KPI_DF_Grp():
    RD_Page.RD_STR_KPI_DF_Grp()

def test_RD_STR_KPI_vs_Summary_DealList():
    RD_Page.RD_STR_KPI_vs_Summary_DealList()

def test_RD_STR_KPI_Summary_DealList_vs_Sum_Detailed_List():
    RD_Page.RD_STR_KPI_Summary_DealList_vs_Sum_Detailed_List()

def test_RD_WKS_KPI_DF_Grp():
    RD_Page.RD_WKS_KPI_DF_Grp()

def test_RD_WKS_KPI_vs_Summary_DealList():
    RD_Page.RD_WKS_KPI_vs_Summary_DealList()

def test_RD_WKS_KPI_Summary_DealList_vs_Sum_Detailed_List():
    RD_Page.RD_WKS_KPI_Summary_DealList_vs_Sum_Detailed_List()

# ### Keydeals ####

def test_KD_Open():
    KD_Page.KD_tab_Click()
    bread_Tooltip_KD = SP_Page.segPipe_breadcrumb()
    print(bread_Tooltip_KD)
    assert bread_Tooltip_KD == "Deal Management / DEALS LIST / DEFAULT VIEW /", "Not in Key Deals Page"

def test_DEFAULTRMSTATUS():
    Defview=KD_Page.DEFAULTRMSTATUS()
    assert Defview=="By Roadmap Status","Default view is not - By Roadmap Status"

def test_KD1ROW():
    KD_Page.KD1ROW()

def test_KD_Modal_Cancel():
    Common.common_Gear()
    Common.common_Gear_NewFiltersViews()
    time.sleep(3)
    KD_Page.KD_Modal_Cancel_btn()

def test_kdtopnav():
    listLegend=DS_COMM.kdtop_nav()
    # assert listLegend ==[['NQ'], ['Signings', 'Signings-ACV'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'Systems Hardware', 'Systems Software', 'C&DP', 'Security', 'Acoustic', 'WCE Mkt&Comm Legacy', 'Watson Health', 'Cognitive Apps', 'Watson Education', 'Indus Platforms Unit'], ['LIO'], ['CLIENT AGGREGATION', 'ALL LINE ITEMS'], ['By BU group', 'By BU Sub group', 'By Level 17', 'By WSR', 'By Dealsize', 'By SAQ', 'By SAQ Quadrant', 'By Market', 'By Branch Group (EBR)', 'By Branch (EBU)', 'By Branch Unit (ESU)', 'By Client Type', 'By Client Sub Type', 'By Client Set', 'By Channel', 'By Reporting Country', 'By Roadmap Status', 'By Close/Bill Week', 'By Close/Bill Month', 'By OI Source', 'By ISU Group', 'By ISU', 'By Geo']], "not expected"
    time.sleep(2)

def test_kddate():
    KD_Page.keydealsTimestamp()
    time.sleep(2)

def test_pagination():
    KD_Page.pagination()
    time.sleep(2)
# #Commenting as issue in Branch Unit(ESU)
# def test_KD_SummvsDeatail():
#     KD_Page.KD_SummvsDeatail()

# Commented to testing others
#---
# @pytest.mark.xfail
# def test_KD_NewFilterViews():
#     Common.common_Gear()
#     Common.common_Gear_NewFiltersViews()
#     time.sleep(3)
#     assert KD_Page.KD_Modal_Text().text == "Customize Deal List - Modify Columns / Define Filters", "Not in Modal Window"
#     btn_propDup = KD_Page.KD_Modal_Duplicate_btn()
#     assert btn_propDup == True, "Button is enabled while it should be disabled"
#     btn_propDel = KD_Page.KD_Modal_Delete_btn()
#     assert btn_propDel == True, "Button is enabled while it should be disabled"
#     KD_Page.KD_Modal_CheckBoxes()
#     test_KD_CustomView_Save()
#     test_KD_Delete_Custom_View()
#
# @pytest.mark.xfail
# def test_KD_CustomView_Save():
#     KD_Page.KD_Modal_Input_Name()
#     KD_Page.KD_Modal_Save_btn()
# #    assert driver.find_element_by_xpath(locators.KD_Refresh_Icon).is_displayed(), "Oops! Looks like Modal Window did not close. Please check"
#
# @pytest.mark.xfail
# def test_KD_Delete_Custom_View():
#     Common.common_Gear()
#
# #    Common.common_Gear_ModifyView()
#     KD_Page.KD_Gear_Delete_TestName()
#     btn_propDup = KD_Page.KD_Modal_Duplicate_btn()
#     assert btn_propDup == False, "Button is disabled while it should be enabled"
#     btn_propDel = KD_Page.KD_Modal_Delete_btn()
#     assert btn_propDel == False, "Button is disabled while it should be enabled"
#     KD_Page.KD_Modal_Delete_btn_Click()
#---

# ===============================
### Milestone ####
def test_MI_Open():
    MI_Page.MI_tab_Click()
    bread_Tooltip_MI = SP_Page.segPipe_breadcrumb()
    print(bread_Tooltip_MI)
    assert bread_Tooltip_MI == "Deal Management / CUSTOMER JOURNEY / DEFAULT VIEW /", "Not in Milestone Page"

def test_TIMESTAMPREFRESH():
    Ref_DT=MI_Page.TIMESTAMPREFRESH()
    assert "Data as of" in Ref_DT,"Date Time not showing"

def test_mitopnav():
    listLegend= DS_COMM.Mitop_nav()
    # assert listLegend == [['NQ'], ['Signings', 'Signings-ACV'], ['All', 'North America', 'Europe', 'Japan', 'Asia Pacific', 'Greater China Group', 'Latin America', 'Middle East & Africa', 'UNASSIGNED'], ['All', 'Systems Hardware', 'Systems Software', 'C&DP', 'Security', 'Acoustic', 'WCE Mkt&Comm Legacy', 'Watson Health', 'Cognitive Apps', 'Watson Education', 'Indus Platforms Unit'], ['LIO'], ['ALL LINE ITEMS'], ['Identifying (1)', 'Validated (4)', 'Qualifying (7)', 'Gaining Agreement (6)']], "is not expected"
    time.sleep(2)

def test_MI_pagenation():
    MI_Page.pagenation()
#---
# @pytest.mark.xfail
# def test_MI_NewFilterViews():
#     test_KD_NewFilterViews()
#
# @pytest.mark.xfail
# def test_MI_CustomView_Save():
#     KD_Page.KD_Modal_Input_Name()
#     KD_Page.KD_Modal_Save_btn()
#
# @pytest.mark.xfail
# def test_MI_CustomView_Delete():
#     test_KD_Delete_Custom_View()
#---

### Comparision KPI aganist Tabs####
def test_AP_SP_KPI():
    #Check All KPI's for AP and SP tab
    AP_Page.Aggregated()
    time.sleep(10)
    ap_KPI = AP_Page.AP_KPI()
    SP_Page.Segmented_tab()
    time.sleep(10)
    sp_KPI = SP_Page.SP_KPI()
    assert ap_KPI==sp_KPI,"Mis-Match between AP and SP KPI's"

def test_ES_AP_SP_KPI():
    # Checked Budget, PPV, Cov, Bw_Obj, VP, WON KPI's for ES,AP and SP tabs
    ES_Page.es()
    time.sleep(10)
    es_KPI = ES_Page.ES_KPI()
    del es_KPI[1:3]
    print(es_KPI)
    # del es_KPI[1:2]
    AP_Page.Aggregated()
    time.sleep(10)
    ap_KPI = AP_Page.AP_KPI()
    del ap_KPI[3]
    print(ap_KPI)
    SP_Page.Segmented_tab()
    sp_KPI = SP_Page.SP_KPI()
    del sp_KPI[3]
    print(sp_KPI)
    assert es_KPI==ap_KPI==sp_KPI,"Mis-Match between ES, AP and SP KPI's"

def test_ES_RD_KPI():
    # Checked Budget and WSR KPI's
    RD_Page.Roadmap()
    time.sleep(10)
    rd_KPI = RD_Page.RD_KPI()
    # del rd_KPI[1]
    del rd_KPI[2:len(rd_KPI)]
    ES_Page.es()
    time.sleep(10)
    es_KPI = ES_Page.ES_KPI()
    del es_KPI[1]
    del es_KPI[2:len(es_KPI)]

    assert es_KPI==rd_KPI,"Mis-Match between ES and RD KPI's"
#

### Closing ####
def test_close():
    driver.close()

