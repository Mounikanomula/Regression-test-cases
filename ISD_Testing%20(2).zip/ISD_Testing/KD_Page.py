import time
import re
import Login_Page
import ES_Page
import Constants
import locators
import Common
import Login_Page
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
import random

driver = Login_Page.driver

def Deal_mangmnt():
    time.sleep(2)
    driver.find_element_by_xpath(locators.Deal_list_manmnt).click()

def KD_tab_Click():
    #driver.find_element_by_xpath(locators.tp).click()
    #driver.find_element_by_xpath(locators.Tasactioal_pipe).click()
    time.sleep(2)
    driver.find_element_by_xpath(locators.Deal_list_manmnt).click()
    time.sleep(4)
    driver.find_element_by_xpath(locators.KD_tab).click()
    driver.implicitly_wait(20)
    time.sleep(2)

def DEFAULTRMSTATUS():
    print("DEFAULT RM STATUS:")
    driver.find_element_by_xpath(locators.filter_icon).click()
    sx=driver.find_element_by_xpath(locators.KD_Default_View)
    def_view=sx.text
    print(def_view)
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    return def_view

def KD1ROW():
    print("FIRST ROW IN KD:")
    time.sleep(2)
    driver.find_element_by_xpath(locators.Left_Expand).click()
    time.sleep(10)
    driver.find_element_by_xpath(locators.KD_Expand_collapse).click()
    time.sleep(5)
    KD1=driver.find_element_by_xpath(locators.KD_First_Row)
    time.sleep(5)
    print(KD1.text)
    driver.find_element_by_xpath(locators.KD_Expand_collapse2).click()
    driver.find_element_by_xpath(locators.Left_Expand).click()

def KD_Modal_Text():
    KDModalTxt = driver.find_element_by_xpath(locators.KD_Modal_Txt)
    return KDModalTxt

def KD_Modal_Duplicate_btn():
    btn_prop = driver.find_element_by_xpath(locators.KD_Modal_Duplicate_btn).get_property('disabled')
    print("Button Disabled?", btn_prop)
    return btn_prop


def KD_Modal_Delete_btn():
    btn_prop = driver.find_element_by_xpath(locators.KD_Modal_Delete_btn).get_property('disabled')
    print("Button Disabled?", btn_prop)
    return btn_prop

def KD_Modal_Delete_btn_Click():
    driver.find_element_by_xpath(locators.KD_Modal_Delete_btn).click()
    DelAlert = driver.find_element_by_xpath(locators.KD_Delete_Alert)
    print(DelAlert.text)
    driver.find_element_by_xpath(locators.KD_Delete).click()
    time.sleep(5)


def KD_Modal_Cancel_btn():
    btn_Cancel = driver.find_element_by_xpath(locators.KD_Modal_Cancel_btn)
    print(btn_Cancel.text)
    btn_Cancel.click()
    time.sleep(2)
    assert driver.find_element_by_xpath(locators.KD_Refresh_Icon).is_displayed(), "Oops! Looks like Modal Window did not close. Please check"

def KD_Modal_Save_btn():
    btn_Save = driver.find_element_by_xpath(locators.KD_Modal_Save_btn)
    print(btn_Save.text)
    btn_Save.click()
    driver.implicitly_wait(30)
    time.sleep(4)

def KD_Modal_Input_Name():
    driver.find_element_by_xpath(locators.KD_Modal_Input_Name).send_keys("Test_KD")

def KD_Gear_Delete_TestName():
    TestName = driver.find_element_by_xpath(locators.KDTest_Edit)
    time.sleep(1)
    TestName.click()
    time.sleep(3)
    KD_Modal_Delete_btn()

def KD_Modal_CheckBoxes():
    global varFilterPlaceholder
    KDchkBx = driver.find_elements_by_xpath(locators.KD_Modal_ChkBox)
    print(len(KDchkBx))
    for i in range(len(KDchkBx)):
        chkBx = driver.find_element_by_xpath("("+locators.KD_Modal_ChkBox+")"+"["+str(i+1)+"]")
        chkBxClick = driver.find_element_by_xpath("("+locators.KD_Modal_ChkBox_Clicks+")"+"["+str(i+1)+"]")
        chkBxAttribute = chkBx.get_attribute('aria-checked')
        chkBxLabels = driver.find_element_by_xpath("("+locators.KD_Modal_ChkBox_Labels+")"+"["+str(i+1)+"]")
        varLabels = chkBxLabels.text
        filterIcons = driver.find_element_by_xpath("("+locators.KD_Modal_Filter_icons+")"+"["+str(i+1)+"]")

        if chkBxAttribute == 'true':
            print(chkBxLabels.text)
            if chkBxLabels.text in Constants.KD_LongLists:
                filterIcons.click()
                time.sleep(30)
            else:
                filterIcons.click()
                time.sleep(4)

            driver.implicitly_wait(100)

            if chkBxLabels.text in Constants.KD_Modal_filter_Sliders:
                print(driver.find_element_by_xpath(locators.KD_Modal_Fitler_SliderPlaceholder).text)
                varFilterPlaceholder = driver.find_element_by_xpath(locators.KD_Modal_Fitler_SliderPlaceholder).text
                abc = re.sub('Select', "", varFilterPlaceholder)
                print("Stripped:", abc)
                assert varLabels == abc.strip(), "Filter Label and Filter Placeholder text does not match"
                ActionChains(driver).click_and_hold(driver.find_element_by_xpath(locators.KD_Modal_Filter_Slider_Min)).move_by_offset(20, 0).release().perform()
                time.sleep(1)
                ActionChains(driver).click_and_hold(driver.find_element_by_xpath(locators.KD_Modal_Filter_Slider_Max)).move_by_offset(-20, 0).release().perform()
                time.sleep(1)
            else:
                print(driver.find_element_by_xpath(locators.KD_Modal_Filter_Placeholder).text)
                varFilterPlaceholder = driver.find_element_by_xpath(locators.KD_Modal_Filter_Placeholder).text
                abc = re.sub('Select', "", varFilterPlaceholder)
                print("Stripped:", abc)
                assert varLabels == abc.strip(), "Filter Label and Filter Placeholder text does not match"
                driver.find_element_by_xpath(locators.KD_Modal_Filter_Arrow).click()
                driver.find_element_by_id(locators.KD_Modal_Filter_ListItemClick).click()
                time.sleep(2)
                driver.find_element_by_id(locators.KD_Modal_Filter_ListItemClick).click()

        else:
            chkBxClick.click()
            print(chkBxLabels.text)

            if chkBxLabels.text in Constants.KD_LongLists:
                filterIcons.click()
                time.sleep(30)
            else:
                filterIcons.click()
                time.sleep(4)

            driver.implicitly_wait(100)
            if chkBxLabels.text in Constants.KD_Modal_filter_Sliders:
                print(driver.find_element_by_xpath(locators.KD_Modal_Fitler_SliderPlaceholder).text)
                varFilterPlaceholder = driver.find_element_by_xpath(locators.KD_Modal_Fitler_SliderPlaceholder).text
                abc = re.sub('Select', "", varFilterPlaceholder)
                print("Stripped:", abc)
                assert varLabels == abc.strip(), "Filter Label and Filter Placeholder text does not match"
                ActionChains(driver).click_and_hold(driver.find_element_by_xpath(locators.KD_Modal_Filter_Slider_Min)).move_by_offset(20, 0).release().perform()
                time.sleep(1)
                ActionChains(driver).click_and_hold(driver.find_element_by_xpath(locators.KD_Modal_Filter_Slider_Max)).move_by_offset(-20, 0).release().perform()
                time.sleep(1)
            else:
                print(driver.find_element_by_xpath(locators.KD_Modal_Filter_Placeholder).text)
                varFilterPlaceholder = driver.find_element_by_xpath(locators.KD_Modal_Filter_Placeholder).text
                abc = re.sub('Select', "", varFilterPlaceholder)
                print("Stripped:", abc)
                assert varLabels == abc.strip(), "Filter Label and Filter Placeholder text does not match"
                driver.find_element_by_xpath(locators.KD_Modal_Filter_Arrow).click()
                driver.find_element_by_id(locators.KD_Modal_Filter_ListItemClick).click()
                time.sleep(2)
                driver.find_element_by_id(locators.KD_Modal_Filter_ListItemClick).click()

def kdtop_nav():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle = driver.find_element_by_xpath(locators.MoveElementkd)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :" + str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-8):
        time.sleep(2)
        GH1[i].click()
        time.sleep(2)
        Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
        print(Topnav.text)
        listLegend1.append(Topnav.text)
        driver.find_element_by_xpath(locators.dropdown_wrapper).click()
    for i in listLegend1:
        listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    time.sleep(5)
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    assert listLegend2 == [['NQ'], ['Signings', 'Signings-ACV'], ['All', 'Americas', 'EMEA', 'Japan', 'APAC', 'INVALID', 'UNASSIGNED'], ['All', 'Systems w/TPS', 'Cloud & Data Platform', 'Security', 'Cognitive Applications','Watson Health'], ['LIO'], ['CLIENT AGGREGATION', 'ALL LINE ITEMS'], ['By BU group', 'By BU Sub group', 'By Level 17', 'By WSR', 'By Dealsize', 'By SAQ', 'By SAQ Quadrant', 'By Market', 'By Branch Group (EBR)', 'By Branch (EBU)', 'By Branch Unit (ESU)', 'By Client Type', 'By Client Sub Type', 'By Client Set', 'By Channel', 'By Reporting Country', 'By Roadmap Status', 'By Close/Bill Week', 'By Close/Bill Month', 'By OI Source', 'By ISU Group', 'By ISU', 'By Geo']],"not expected"
    return listLegend2

def keydealsTimestamp():
    time.sleep(2)
    kd=driver.find_element_by_xpath(locators.KDDate).text
    KD=str(kd).replace("Data as of ", "").replace("(", "").replace(")", "")
    print("keydeals date :" +KD)

def pagination():
    ES_Page.LEXPANDICON()
    time.sleep(5)
    caret_clk = driver.find_element_by_xpath(locators.KD_page_caret_clk)
    caret_clk.click()

    Pages_right_clk = driver.find_element_by_xpath(locators.Kd_right_arrowclk)

    try:
        if (Pages_right_clk.is_enabled()):
            time.sleep(2)
            Pages_right_clk.click()
            # caret_clk.click()

            time.sleep(2)
            Data_enabled = driver.find_element_by_xpath(locators.Kd_data_list)
            print("Data is enabled +\n",  Data_enabled.text)
            assert True

        elif(Pages_right_clk.is_enabled()) :
            print("Right click is not enabled  +\n")
            assert False
        else:
            print("There is only single page as per the selections \n")

    except(TypeError):
        pass

    time.sleep(4)
    Minus_button = driver.find_element_by_xpath(locators.KD_Minus_btn)
    Minus_button.click()
    time.sleep(3)
    Pages_back_clk = driver.find_element_by_xpath(locators.KD_left_arrowclk)
    Pages_back_clk.click()
    opportunity_val = driver.find_element_by_css_selector(locators.Opp_val_txt)
    print(opportunity_val.text)
    opportunity_val = str(opportunity_val.text)
    opportunity_val = opportunity_val.split(" ")

    print("opp val is " , opportunity_val[0])
    opportunity_val = opportunity_val[0].replace(",", "")
    print("Replace val is ", opportunity_val)
    opportunity_val = int(opportunity_val)
    # print(opportunity_val)


    divide = 0
    div =0


    if(opportunity_val%10>0):
        divide = opportunity_val/10
        divide = int(divide)
        divide= divide+1
        div = round(divide)
        print(div)

    else:
        divide = opportunity_val/10
        div = round(divide)
        print(div)

    time.sleep(2)
    Arrow_clk = driver.find_element_by_xpath(locators.KD_arrow_dpdwn_clk)

    try:
        if Pages_right_clk.is_enabled():
            time.sleep(3)
            Arrow_clk.click()
            time.sleep(5)
            input_text = driver.find_element_by_xpath(locators.KD_input_txt_val)
            enter_num = input_text.send_keys(div)
            time.sleep(5)
            enter_key_val = input_text.send_keys(Keys.ENTER)


        elif Pages_right_clk.is_enabled():

            print("Right click is not enabled  +\n")

            assert False

        else:

            print("There is only single page as per the selections \n")

    except(TypeError):
        pass

    try:
        if (Pages_right_clk.is_enabled()):
            time.sleep(2)
            print("Arrow is able to click even when scroll down to last page and the result is :  False")
            assert False

        else:
            print("Arrow is not clickable at the end point and the result is ::   True")
            assert True

    except(TypeError):
        pass


#  This will compare Summary vs detailed list in keydeals section --- Group

def KD_SummvsDeatail():
    # ES_Page.es()
    # KD_tab_Click()
    # ES_Page.LEXPANDICON()
    time.sleep(3)
    driver.find_element_by_xpath(locators.filter_icon).click()
    # print(driver.find_element_by_xpath("//*[@id='bread_GROUP']").text)
    Group_clk = driver.find_element_by_xpath(locators.KD_Default_View).click()
    KD_Len = driver.find_elements_by_xpath(locators.KD_Group_options)
    print('length of followed view is', len(KD_Len))
    time.sleep(5)
    driver.find_element_by_xpath("("+locators.filter_icon_close+")"+ "[" + str(2) + "]").click()
    time.sleep(5)

    for i in range(len(KD_Len) - 1):
        filter_icon = driver.find_element_by_xpath(locators.filter_icon).click()
        print("**************************************************************************************************************** \n")
        Group_clk = driver.find_element_by_xpath(locators.KD_Default_View).click()
        global All_Groups
        All_Groups = driver.find_element_by_xpath(locators.KD_All_Groups + "[" + str(i + 1) + "]")
        All_Groups.click()
        print("followed groupd is :: " + str(driver.find_element_by_xpath(locators.KD_Default_View).text))

        # print(All_Groups.text)
        driver.find_element_by_xpath("("+locators.filter_icon_close+")"+ "[" + str(2) + "]").click()
        time.sleep(5)

        # ----------------------------------------------- To check data is populating for expand collapse----------------------------------------------------

        expand_collapse = driver.find_element_by_xpath(locators.KD_Expand_collapse)
        expand_collapse.click()
        time.sleep(3)
        try:
            Data_enable = driver.find_element_by_xpath(locators.Kd_data_list)
            if (Data_enable.is_displayed()):
                print("Data is available", Data_enable.text)
                time.sleep(3)
                Minus_button = driver.find_element_by_xpath(locators.KD_Minus_btn)
                Minus_button.click()
                assert True
            else:
                print("Data is not enabled and NULL", Data_enable.text)
                assert False

        except(TypeError):
            pass

        KD_list = driver.find_elements_by_css_selector(locators.KD_Li_table_list_txt)
        print("size of KD_list_Lival is " + str(len(KD_list)))
        summary = []
        for i in range(len(KD_list)):
            Detailed_list_value = KD_list[i].text
            Detailed_list_value = Detailed_list_value.replace(",", "")
            Detailed_list_value = re.findall(r'[0-9]+[.]?[0-9]+', Detailed_list_value)
            time.sleep(2)
            driver.execute_script("scrollBy(0,10000);")
            print("Detailed value is " + str(Detailed_list_value))
            Detailed_list_value = Detailed_list_value[0]
            print(Detailed_list_value)
            summary.append(float(Detailed_list_value))

        # print(summary)
        sum_summary = sum(summary)
        print("All Deal list sum is " + str(sum_summary))
        driver.execute_script("scrollBy(0,-10000);")
        KD_Summary_header = driver.find_element_by_xpath(locators.KD_Li_Summary_Lival)

        KD_Deal_value_2 = KD_Summary_header.text.replace(",", "")
        KD_Deal_value_2 = re.findall(r'[0-9]+[.]?[0-9]+', KD_Deal_value_2)
        print("KD header LI value is " + str(KD_Deal_value_2))
        KD_Deal_value_2 = KD_Deal_value_2[0]

        print("Summary header lineitem is " + str(KD_Deal_value_2))

        diff = abs(float(sum_summary) - float(KD_Deal_value_2))
        print("Difference of Deal listsum vs Deallist line item value is " + format(diff, '.2f'))

        time.sleep(3)
        try:
            if diff < 1:
                print("Deal list sum(" + str(sum_summary) + ") is matching with Summary LI Values(" + str(KD_Deal_value_2) + " ) :::  " + " " + format(diff, '.2f'))
                assert True

            else:
                print(" Deal list sum(" + str(sum_summary) + ") is not matching with Summary LI Values(" + str(KD_Deal_value_2) + " ) :::  " + " " + format(diff, '.2f'))
                assert False

        except(TypeError):
            pass
        print("\n")
        print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
        time.sleep(2)




##---------------------------call code below-------------------------##
# Login_Page.open_ISD()
# KD_tab_Click()
# # DEFAULTRMSTATUS()
# # KD1ROW()
# Common.common_Gear()
# # Common.common_Gear_NewFiltersViews()
# Common.common_Gear_NewFiltersViews()
# KD_Modal_CheckBoxes()
# KD_Modal_Cancel_btn()
# kdtop_nav()
# keydealsTimestamp()
# pagination()
## KD_SummvsDeatail()  #(ingore for now)