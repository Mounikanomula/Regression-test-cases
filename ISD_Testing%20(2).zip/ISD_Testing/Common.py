from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
import re
import time
import  Login_Page
import locators

driver = Login_Page.driver

def es_kpi1(element):
    element = element.text
    element = element.split('\n')
    # print(element)
    element_2 = element[1]
    element_2 = element_2.replace(",", "")
    element_2 = re.findall(r'\d+\.?\d*', element_2)
    # print(element_2)
    element_2 = element_2[0]
    element_2 = float(element_2)
    return element_2

def es_kpi1_1(element):
    element = element.text
    element = element.split('\n')
    element_2 = element[2]
    element_2 = element_2.replace(",", "")
    element_2 = re.findall(r'\d+\.?\d*', element_2)
    element_2 = element_2[0]
    element_2 = float(element_2)
    return element_2

def es_kpi2(element2):
    element2 = element2.text
    element2 = element2.split('\n')
    element2_1 = element2[1]
    element2_1 = element2_1.replace("%", "")
    element2_1 = element2_1.replace("$", "")
    element2_1 = element2_1.replace("M", "")
    element2_1 = element2_1.replace(",", "")
    element2_1 = float(element2_1)
    return element2_1

def KPI():
    try:
        Budget = es_kpi1(driver.find_element_by_xpath(locators.Budget))
        print("Budget: "+str(Budget))
    except (RuntimeError, TypeError, NameError, Exception):
        Budget = "Budget locator not found"
        pass
    try:
        PPV = es_kpi1(driver.find_element_by_xpath(locators.PPV))
        print("PPV: "+str(PPV))
    except (RuntimeError, TypeError, NameError, Exception):
        PPV = "PPV locator not found"
        pass
    try:
        Cov = es_kpi2(driver.find_element_by_xpath(locators.Cov))
        print("Cov: "+str(Cov))
    except (RuntimeError, TypeError, NameError, Exception):
        Cov = "Cov locator not found"
        pass
    try:
        Bw_Obj = es_kpi2(driver.find_element_by_xpath(locators.BW_OBJ))
        print("BW_OBJ: "+str(Bw_Obj))
    except (RuntimeError, TypeError, NameError, Exception):
        Bw_Obj = "Bw_Obj locator not found"
        pass
    try:
        VP = es_kpi1(driver.find_element_by_xpath(locators.VP))
        print("VP: "+str(VP))
    except (RuntimeError, TypeError, NameError, Exception):
        VP = "VP locator not found"
        pass
    try:
        WSR = es_kpi1(driver.find_element_by_xpath(locators.WSR))
        print("WSR: "+str(WSR))
    except (RuntimeError, TypeError, NameError, Exception):
        WSR = "WSR locator not found"
        pass
    try:
        QP = es_kpi1(driver.find_element_by_xpath(locators.QP))
        print("QP: "+str(QP))
    except (RuntimeError, TypeError, NameError, Exception):
        QP = "QP locator not found"
        pass
    try:
        WON = es_kpi1(driver.find_element_by_xpath(locators.WON))
        print("WON: "+str(WON))
    except (RuntimeError, TypeError, NameError, Exception):
        WON = "WON locator not found"
        pass
    try:
        RD_WSR = es_kpi1(driver.find_element_by_xpath(locators.rd_WSR))
        print("RD WSR: "+str(RD_WSR))
    except (RuntimeError, TypeError, NameError, Exception):
        RD_WSR = "RD WSR locator not found"
        pass
    try:
        RD_DTB = es_kpi1(driver.find_element_by_xpath(locators.rd_DTB))
        print("RD DTB: "+str(RD_DTB))
    except (RuntimeError, TypeError, NameError, Exception):
        RD_DTB = "RD DTB locator not found"
        pass
    try:
        RD_WON = es_kpi1(driver.find_element_by_xpath(locators.rd_WON))
        print("RD WON: "+str(RD_WON))
    except (RuntimeError, TypeError, NameError, Exception):
        RD_WON = "RD WON locator not found"
        pass
    try:
        RD_STR = es_kpi1(driver.find_element_by_xpath(locators.rd_STR))
        print("RD STR: "+str(RD_STR))
    except (RuntimeError, TypeError, NameError, Exception):
        RD_STR = "RD STR locator not found"
        pass
    try:
        RD_WKS = es_kpi1(driver.find_element_by_xpath(locators.rd_WKS))
        print("RD WKS: "+str(RD_WKS))
    except (RuntimeError, TypeError, NameError, Exception):
        RD_WKS = "RD WKS locator not found"
        pass
    try:
        RD_WKS_ST = es_kpi1(driver.find_element_by_xpath(locators.RD_WKS_ST))
        print("RD WKS: "+str(RD_WKS_ST))
    except (RuntimeError, TypeError, NameError, Exception):
        RD_WKS_ST = "RD WKS Strech locator not found"
        pass
    try:
        QTD = es_kpi1(driver.find_element_by_xpath(locators.QTD))
        print("QTD Actuals: "+str(QTD))
    except (RuntimeError, TypeError, NameError, Exception):
        QTD = "QTD Actuals locator not found"
        pass
    try:
        PPV2 = es_kpi1(driver.find_element_by_xpath(locators.PPV2))
        print("PPV: "+str(PPV2))
    except (RuntimeError, TypeError, NameError, Exception):
        PPV2 = "PPV locator not found"
        pass
    try:
        Cov2 = es_kpi2(driver.find_element_by_xpath(locators.Cov2))
        print("Cov: "+str(Cov2))
    except (RuntimeError, TypeError, NameError, Exception):
        Cov2 = "Cov locator not found"
        pass
    try:
        VP2 = es_kpi1(driver.find_element_by_xpath(locators.VP2))
        print("VP: " + str(VP2))
    except (RuntimeError, TypeError, NameError, Exception):
        VP2 = "VP locator not found"
        pass
    try:
        QP2 = es_kpi1(driver.find_element_by_xpath(locators.QP2))
        print("QP: " + str(QP2))
    except (RuntimeError, TypeError, NameError, Exception):
        QP2 = "QP locator not found"
        pass
    try:
        WON2 = es_kpi1(driver.find_element_by_xpath(locators.WON2))
        print("WON: " + str(WON2))
    except (RuntimeError, TypeError, NameError, Exception):
        WON2 = "WON locator not found"
        pass
    return [Budget, PPV, Cov, Bw_Obj, VP, QP, WON, RD_WSR, RD_DTB, RD_WON, RD_STR, RD_WKS,RD_WKS_ST,QTD,WSR,PPV2,Cov2,VP2,QP2,WON2]


def expand_showhide_colapase():
    # Expand graph show table get first row the hide table then close expand
    time.sleep(5)
    max2=driver.find_elements_by_xpath(locators.max1)
    for i in range(len(max2)):
        driver.find_element_by_xpath(locators.max1+str([i+1])).click()
        driver.find_element_by_xpath(locators.showhide).click()
    #     time.sleep(5)
        val=driver.find_element_by_xpath(locators.firstrow).text
    #     print(val)
        assert type(val)==str,"No Values"
        driver.find_element_by_xpath(locators.showhide).click()
        driver.find_element_by_xpath(locators.min1).click()

def sp_expand_showhide_colapase():
    # Expand graph show table get first row the hide table then close expand
    time.sleep(5)
    max2=driver.find_elements_by_xpath(locators.max1)
    print(max2)
    for i in range(len(max2)):
        try:
            driver.find_element_by_xpath(locators.max1+str([i+1])).click()
            driver.find_element_by_xpath(locators.sp_showhide).click()
        #     time.sleep(5)
            val=driver.find_element_by_xpath(locators.firstrow).text
        #     print(val)
            assert type(val)==str,"No Values"
            driver.find_element_by_xpath(locators.sp_showhide).click()
            driver.find_element_by_xpath(locators.min1).click()
        except(RuntimeError, TypeError, NameError, ValueError, Exception):
            print("No Data Available")
            driver.find_element_by_xpath(locators.min1).click()

def sp_expand_showhide_colapase2():
    # Expand graph show table get first row the hide table then close expand
    time.sleep(5)
    max2=driver.find_elements_by_xpath(locators.max1)
    for i in range(len(max2)):
        driver.find_element_by_xpath(locators.max1+str([i+1])).click()
        time.sleep(3)
        driver.find_element_by_xpath(locators.sp_showhide2).click()
        val=driver.find_element_by_xpath(locators.firstrow).text
        assert type(val)==str,"No Values"
        driver.find_element_by_xpath(locators.sp_showhide2).click()
        driver.find_element_by_xpath(locators.min1).click()

def sp_expand_showhide_colapase3():
    # Expand graph show table get first row the hide table then close expand
    time.sleep(5)
    max2=driver.find_elements_by_xpath(locators.max1)
    for i in [1]:
        driver.find_element_by_xpath(locators.max1+str([i])).click()
        driver.find_element_by_xpath(locators.sp_showhide3).click()
    #     time.sleep(5)
        val=driver.find_element_by_xpath(locators.firstrow).text
    #     print(val)
        assert type(val)==str,"No Values"
        driver.find_element_by_xpath(locators.sp_showhide3).click()
        driver.find_element_by_xpath(locators.min1).click()
    for i in [2,3,4]:
        driver.find_element_by_xpath(locators.max1+str([i])).click()
        driver.find_element_by_xpath(locators.sp_showhide2).click()
    #     time.sleep(5)
        val=driver.find_element_by_xpath(locators.firstrow).text
    #     print(val)
        assert type(val)==str,"No Values"
        driver.find_element_by_xpath(locators.sp_showhide2).click()
        driver.find_element_by_xpath(locators.min1).click()



def Graphs():
    # Get the graphs title in each section
    gh = driver.find_elements_by_xpath(locators.Graphs)
    len(gh)
    g1 = []
    for i in range(len(gh)):
        g = driver.find_element_by_xpath('('+locators.Graphs+')' + '[' + str(i + 1) + ']').text
        g1.append(g)
    print(g1)
    return g1

def Graphs1():
    # Get the graphs title in each section
    gh = driver.find_elements_by_xpath(locators.Graphs1)
    len(gh)
    g1 = []
    for i in range(len(gh)):
        g = driver.find_element_by_xpath('('+locators.Graphs1+')' + '[' + str(i + 1) + ']').text
        g1.append(g)
    print(g1)
    return g1

def getlist():
    P=[]
    P_ok=[]
    P_nok=[]
    driver.find_element_by_xpath(locators.max1).click()
    driver.find_element_by_xpath(locators.showhide).click()
    tx=driver.find_elements_by_xpath(locators.firstrow)
    for ik in range(len(tx)):
        tx=driver.find_element_by_xpath('('+locators.firstrow+')'+'['+str(ik+1)+']').text
        tx=tx.split('\n')
        try:
            float(tx[0])
            tx1="N/A"
        except(RuntimeError, TypeError, NameError, ValueError, Exception):
            tx1=tx[0]
            tx1
        P.append(tx1)
    driver.find_element_by_xpath(locators.showhide).click()
    driver.find_element_by_xpath(locators.min1).click()
    for k in range(len(P)):
        if P[k]=="N/A" or P[k]=="UNASSIGNED":
            P_nok.append(P.index(P[k]))
        else:
            P_ok.append(P.index(P[k]))
    return P_ok,P_nok

def GlobFilterHover():
    globFilterIcon = driver.find_element_by_xpath(locators.filter_icon)
    ActionChains(driver).move_to_element(globFilterIcon).perform()
    time.sleep(1)

def GlobFilterClick():
#    GlobFilterHover()
    driver.find_element_by_xpath(locators.filter_icon).click()

def GlobalFilterChevron2():
    driver.find_element_by_xpath(locators.common_GlobalFilterChevron2).click()

def GlobFilterXiconClick():
    GlobalFiltercloseIcon = driver.find_element_by_xpath(locators.common_GlobalFilterXicon)
    GlobalFilterChevron2()
    GlobalFilterChevron2()
    ActionChains(driver).move_to_element(GlobalFiltercloseIcon).perform()
    time.sleep(1)
    GlobalFiltercloseIcon.click()
    time.sleep(2)

def GlobFilterRestoreDefaults():
    GlobFilterClick()
    GlobalFilterChevron2()
    GlobalFilterChevron2()
    driver.find_element_by_xpath(locators.common_GlobalFilterRestore).click()
    time.sleep(2)

def common_TopNav_DefView():
    defView = driver.find_element_by_xpath(locators.topnav_View)
    print("Clicked View:", defView.text)
    time.sleep(1)

def common_TopNav_AltView():
    altView = driver.find_element_by_xpath(locators.topnav_View).click()
    driver.find_element_by_xpath(locators.topnav_altView).click()
    time.sleep(3)
    common_TopNav_DefView()

#### we need to run these separetly ###############3
def common_Gear():
    driver.find_element_by_xpath(locators.common_gear).click()
    time.sleep(3)

def common_Gear_NewFiltersViews():
    driver.find_element_by_xpath(locators.common_gear_NewFilters).click()

def common_Gear_Saved_layouts_Deletion():
    Saved_views_check = driver.find_element_by_xpath("//div[@class='savedViews']")
    if Saved_views_check.is_displayed():
        print("There are saved views")
        Saved_layouts = driver.find_element_by_xpath(locators.common_gear_deleted_layouts)
        action = ActionChains(driver)
        action.move_to_element(Saved_layouts).perform()
        if Saved_layouts.is_displayed():
            Saved_layouts.click()
            time.sleep(5)
            Delete_pop = driver.find_element_by_xpath(locators.common_delete_popup)
            action.move_to_element(Delete_pop).perform()
            Delete_pop.click()
            time.sleep(10)
            print("Selected layout got deleted")
        else:
            print("There are No saved layouts")

    else:
        print("There are no Saved views")

###########################################################################

def Expand_sidebar():
    action = ActionChains(driver)
    Chevron = driver.find_element_by_xpath("//div[@class='expand-icon']")
    action.move_to_element(Chevron).perform()
    tooltip = driver.find_element_by_class_name('tooltip').text
    try:
        assert tooltip == "Expand Sidebar"
        assert True
        print(tooltip)
    except (RuntimeError, TypeError, NameError, Exception):
        print("Issue with text", tooltip)
        assert False
        pass
    Chevron.click()

def common_Close_dealList():
    driver.find_element_by_xpath(locators.Detailed_list_close).click()
    time.sleep(2)


def revenue_Signings():
    time.sleep(3)
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle=driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    time.sleep(3)
    driver.find_element_by_xpath(locators.rev_dd).click()
    rev = driver.find_elements_by_xpath(locators.rev_sub_dd)
    driver.find_element_by_xpath(locators.rev_sub_dd + "[" + str(1) + "]").click()
    rtext = driver.find_element_by_xpath(locators.rev_txt).text
    time.sleep(3)
    print(rtext)
    time.sleep(3)
    driver.find_element_by_xpath(locators.rev_dd).click()
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    return rtext

def revenue_Signings_Acv():
    time.sleep(3)
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle=driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    time.sleep(3)
    driver.find_element_by_xpath(locators.rev_dd).click()
    rev = driver.find_elements_by_xpath(locators.rev_sub_dd)
    driver.find_element_by_xpath(locators.rev_sub_dd + "[" + str(2) + "]").click()
    rtext = driver.find_element_by_xpath(locators.rev_txt).text
    time.sleep(3)
    print(rtext)
    time.sleep(3)
    driver.find_element_by_xpath(locators.rev_dd).click()
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    return rtext
#
#
def revenue():
    time.sleep(3)
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle=driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    time.sleep(3)
    driver.find_element_by_xpath(locators.rev_dd).click()
    rev=driver.find_elements_by_xpath(locators.rev_sub_dd)
    # driver.find_element_by_xpath(locators.rev_dd).click()
    print(len(rev))
    rtext=""
    for i in range(len(rev)):
        print(i)
        driver.find_element_by_xpath(locators.rev_sub_dd+"["+str(i+1)+"]").click()
        time.sleep(3)
        rtext=driver.find_element_by_xpath(locators.rev_txt).text
        time.sleep(3)
        print(rtext)
        time.sleep(3)
        driver.find_element_by_xpath(locators.rev_dd).click()
    driver.find_element_by_xpath(locators.filter_icon_close).click()
    return rtext

