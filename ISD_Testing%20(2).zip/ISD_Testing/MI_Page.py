import time
import Login_Page
import locators
import ES_Page
from selenium.webdriver import ActionChains
from selenium.webdriver.common.keys import Keys

driver = Login_Page.driver

def MI_tab_Click():
    time.sleep(2)
    # driver.find_element_by_xpath(locators.tp).click()
    driver.find_element_by_xpath(locators.Customer_jrny).click()
    driver.implicitly_wait(20)
    time.sleep(2)

def TIMESTAMPREFRESH():
    print("Milestone Timestamp Refresh:")
    driver.find_element_by_class_name(locators.Refresh_icon).click()
    time.sleep(5)
    T1=driver.find_element_by_xpath(locators.Refresh_datetime)
    Ref_DT=T1.text
    print(Ref_DT)
    return Ref_DT

def Mitop_nav():
    driver.find_element_by_xpath(locators.filter_icon).click()
    MoveEle = driver.find_element_by_xpath(locators.MoveElementSomewhere)
    action = ActionChains(driver)
    action.move_to_element(MoveEle).perform()
    GH1 = driver.find_elements_by_xpath(locators.topnav_dropdown)
    topnavlength = len(GH1)
    print("Total Topnav :" + str(topnavlength))
    listLegend1 = []
    listLegend2 = []
    for i in range(len(GH1)-4):
        time.sleep(2)
        GH1[i].click()
        time.sleep(2)
        Topnav = (driver.find_element_by_xpath(locators.topnav_dropdownElements))
        print(Topnav.text)
        listLegend1.append(Topnav.text)
        driver.find_element_by_xpath(locators.dropdown_wrapper).click()
    for i in listLegend1:
        listLegend2.append(i.split('\n'))
    print("Topnav Elements :" + str(listLegend2))
    time.sleep(3)
    driver.find_element_by_xpath(locators.common_GlobalFilterXicon).click()
    assert listLegend2 == [['NQ'], ['Signings', 'Signings-ACV'], ['All', 'Americas', 'EMEA', 'Japan', 'APAC', 'INVALID', 'UNASSIGNED'], ['All', 'Systems w/TPS', 'Cloud & Data Platform', 'Security', 'Cognitive Applications', 'Watson Health'], ['LIO'], ['ALL LINE ITEMS'], ['Identifying (1)', 'Validated (4)', 'Qualifying (7)', 'Gaining Agreement (6)']], "is not expected"
    return listLegend2

def pagenation():
    time.sleep(3)
    # ES_Page.LEXPANDICON()
    Pages_right_clk = driver.find_element_by_xpath(locators.Kd_right_arrowclk)

    try:
        if (Pages_right_clk.is_enabled()):
            time.sleep(2)
            Pages_right_clk.click()
            # caret_clk.click()

            time.sleep(2)
            Data_enabled = driver.find_element_by_xpath(locators.Kd_data_list)
            print("Data is enabled +\n", Data_enabled.text)
            assert True

        elif (Pages_right_clk.is_enabled()):
            print("Right click is not enabled  +\n")
            assert False
        else:
            print("There is only single page as per the selections \n")

    except(TypeError):
        pass

    time.sleep(4)

    Pages_back_clk = driver.find_element_by_xpath(locators.KD_left_arrowclk)
    Pages_back_clk.click()
    opportunity_val = driver.find_element_by_xpath(locators.MI_opp_val)
    print(opportunity_val.text)
    opportunity_val = str(opportunity_val.text)
    opportunity_val = opportunity_val.split(" ")

    print("opp val is ", opportunity_val[0])
    opportunity_val = opportunity_val[0].replace(",", "")
    print("Replace val is ", opportunity_val)
    opportunity_val = int(opportunity_val)
    # print(opportunity_val)


    divide = 0
    div = 0

    if (opportunity_val % 10 > 0):
        divide = opportunity_val / 10
        divide = int(divide)
        divide = divide + 1
        div = round(divide)
        print(div)

    else:
        divide = opportunity_val / 10
        div = round(divide)
        print(div)

    time.sleep(2)
    Arrow_clk = driver.find_element_by_xpath(locators.KD_arrow_dpdwn_clk)

    try:
        if (Pages_right_clk.is_enabled()):
            Arrow_clk.click()
            time.sleep(5)
            input_text = driver.find_element_by_xpath(locators.KD_input_txt_val)
            enter_num = input_text.send_keys(div)
            time.sleep(5)
            enter_key_val = input_text.send_keys(Keys.ENTER)


        elif (Pages_right_clk.is_enabled()):

            print("Right click is not enabled  +\n")

            assert False

        else:

            print("There is only single page as per the selections \n")

    except(TypeError):
        pass

    try:
        if (Pages_right_clk.is_enabled()):
            time.sleep(2)
            print("Arrow is able to click even when scroll down to last page and the result is :  False")
            assert False

        else:
            print("Arrow is not clickable at the end point and the result is ::   True")
            assert True

    except(TypeError):
        pass



##---------------------------call code below-------------------------##
# Login_Page.open_ISD()
# MI_tab_Click()
# TIMESTAMPREFRESH()
# Mitop_nav()
# pagenation()
